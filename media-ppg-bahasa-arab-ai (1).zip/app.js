// Entry point for DirectAdmin / cPanel / CloudLinux NodeJS Passenger Selector
// Loads the compiled production server from dist/server.cjs or starts development

import path from 'path';
import fs from 'fs';

const distServer = path.join(process.cwd(), 'dist', 'server.cjs');

if (fs.existsSync(distServer)) {
  import('./dist/server.cjs');
} else {
  console.log('Building project or running dev server...');
  import('./server.ts');
}
