# PANDUAN LENGKAP PENYEBARAN (DEPLOYMENT)
# MEDIA PPG BAHASA ARAB AI KE GOOGLE APPS SCRIPT & GOOGLE SPREADSHEET

Panduan ini berisi langkah-langkah praktis untuk mempublikasikan website **Media PPG Bahasa Arab AI** ke **Google Apps Script (GAS)**, menghubungkannya ke **Google Spreadsheet** sebagai basis data (*database*) otomatis, dan mengaktifkan AI Generatif Google Gemini.

---

## 📁 File yang Telah Disiapkan

Dalam project ini, file untuk Google Apps Script telah disiapkan rapi:
1. `Code.gs` (atau di folder `gas/Code.gs`): Kode backend Google Apps Script.
2. `gas/Index.html` (atau `Index_GAS.html`): Tampilan antarmuka (*frontend*) tunggal siap pakai berbasis Tailwind CSS & Lucide Icons.
3. API Key Gemini Anda (`AQ.Ab8RN6LaOuGBqis4Q9FD67cqCKRN2JlcEwY03aTz01y-f2AtxA`) sudah terintegrasi secara bawaan (*default*).

---

## 🚀 Langkah 1: Buka Google Apps Script

1. Buka browser dan kunjungi: **[https://script.google.com](https://script.google.com)**
2. Pastikan Anda telah login menggunakan akun Google Anda (`muhammad.ahsan.2502319@students.um.ac.id` atau akun Google aktif Anda).
3. Klik tombol **Proyek Baru** (*New Project*) di pojok kiri atas.
4. Ubah nama proyek di kiri atas (default: *Untitled project*) menjadi:
   ```text
   Media PPG Bahasa Arab AI
   ```

---

## 📝 Langkah 2: Salin File `Code.gs`

1. Di editor Google Apps Script, secara default sudah ada file bernama `Code.gs`.
2. Hapus seluruh baris kode default yang ada di dalam `Code.gs`.
3. Buka file **`Code.gs`** dari repositori ini, lalu salin (**Copy**) seluruh isinya.
4. Tempelkan (**Paste**) ke dalam file `Code.gs` di editor Google Apps Script.
5. Tekan tombol **Simpan** (ikon disket atau `Ctrl + S` / `Cmd + S`).

---

## 🌐 Langkah 3: Tambahkan File `Index.html`

1. Di panel kiri Google Apps Script (bagian **File**), klik ikon **+** (Tambah file).
2. Pilih opsi **HTML**.
3. Ketikkan nama file:
   ```text
   Index
   ```
   *(Catatan: Cukup ketik "Index", Google Apps Script akan otomatis menjadikannya `Index.html`)*.
4. Hapus seluruh kode bawaan yang muncul di `Index.html`.
5. Buka file **`gas/Index.html`** dari repositori ini, lalu salin (**Copy**) seluruh isinya.
6. Tempelkan (**Paste**) ke dalam file `Index.html` di editor Google Apps Script.
7. Tekan tombol **Simpan** (`Ctrl + S` / `Cmd + S`).

---

## 🗄️ Langkah 4: Jalankan `setupDatabase()` (Otomatisasi Spreadsheet)

Langkah ini akan **secara otomatis membuat file Google Spreadsheet baru di Google Drive Anda** lengkap dengan tabel-tabel dan format warna resmi PPG Kemenag:

1. Di bilah menu atas Google Apps Script editor, cari menu dropdown fungsi (di sebelah tombol *Debug* dan *Run/Jalankan*).
2. Pilih fungsi: **`setupDatabase`**.
3. Klik tombol **Jalankan** (*Run*).
4. Dialog **Otorisasi Diperlukan** (*Authorization Required*) akan muncul:
   - Klik **Tinjau Izin** (*Review Permissions*).
   - Pilih akun Google Anda.
   - Jika muncul peringatan *"Google hasn't verified this app"* / *"Google belum memverifikasi aplikasi ini"*, klik tautan **Lanjutan** (*Advanced*) di kiri bawah.
   - Klik **Buka Media PPG Bahasa Arab AI (tidak aman)** / *Go to Media PPG Bahasa Arab AI (unsafe)*.
   - Klik **Izinkan** (*Allow*).
5. Tunggu proses berjalan hingga selesai (sekitar 3-5 detik).
6. Buka **Log Eksekusi** (*Execution Log*) di bagian bawah editor. Anda akan melihat pesan:
   ```text
   Spreadsheet baru berhasil dibuat: https://docs.google.com/spreadsheets/d/.../edit
   ```
7. Database Google Spreadsheet Anda kini telah aktif dengan 6 lembar kerja (*sheet*):
   - **`Users`**: Menyimpan profil mahasiswa & dosen.
   - **`Simulasi_Kasus`**: Menyimpan jawaban kasus pedagogik, skor, dan feedback AI.
   - **`RPP_Modul_Ajar`**: Menyimpan dokumen RPP/Modul Ajar yang disusun mahasiswa.
   - **`Pretest_Quiz`**: Menyimpan nilai kuis dan kelulusan mahasiswa.
   - **`Tutor_Chat`**: Menyimpan riwayat tanya jawab dengan Al-Ustadz AI.
   - **`Penilaian_Dosen`**: Rekapitulasi nilai akhir dan catatan dosen penguji.

---

## 🔑 Langkah 5: Pengaturan Properti Skrip (Opsional)

Jika Anda ingin memeriksa atau memperbarui API Key Gemini Anda di kemudian hari:
1. Klik ikon **Setelan Proyek** (ikon gerigi ⚙️ di menu bilah sebelah kiri).
2. Gulir ke bawah ke bagian **Properti Skrip** (*Script Properties*).
3. Anda akan melihat properti yang sudah diatur otomatis:
   - `GEMINI_API_KEY` : `AQ.Ab8RN6LaOuGBqis4Q9FD67cqCKRN2JlcEwY03aTz01y-f2AtxA`
   - `SPREADSHEET_ID` : *(ID spreadsheet yang dibuat otomatis pada Langkah 4)*.

---

## 🚀 Langkah 6: Publikasikan sebagai Web App (Publish / Deploy)

1. Di pojok kanan atas editor Apps Script, klik tombol biru **Terapkan** (*Deploy*) > pilih **Penerapan Baru** (*New deployment*).
2. Klik ikon gerigi ⚙️ di samping teks *"Pilih jenis"* (*Select type*), lalu pilih **Aplikasi Web** (*Web app*).
3. Isi konfigurasi sebagai berikut:
   - **Deskripsi** (*Description*): `Media Pembelajaran PPG Bahasa Arab AI v1.0`
   - **Jalankan sebagai** (*Execute as*): **Saya (`email Anda`)**
   - **Yang memiliki akses** (*Who has access*): **Siapa saja** (*Anyone*) atau *Siapa saja yang memiliki akun Google*.
4. Klik tombol **Terapkan** (*Deploy*).
5. Salin tautan pada bagian **URL Aplikasi Web** (*Web App URL*). Tautan ini berformat:
   ```text
   https://script.google.com/macros/s/AKfycb.../exec
   ```
6. Buka URL tersebut di browser baru. Website Media PPG Bahasa Arab AI Anda sekarang sudah resmi **ONLINE** dan aktif! 🎉

---

## 🌟 Fitur Utama dalam Versi Google Apps Script

1. **Modul 01: Simulasi Kasus Pedagogik**:
   - Studi kasus kelas Bahasa Arab HOTS dengan integrasi AI Gemini.
   - Mahasiswa dapat memilih opsi atau menuliskan esai tindakan pedagogik mandiri.
   - Hasil evaluasi dan skor langsung terkirim dan tercatat di sheet `Simulasi_Kasus`.
2. **Modul 02: Penyusunan RPP & Modul Ajar Kurikulum Merdeka**:
   - Parameter jenjang, alokasi waktu, pendekatan komunikatif, dan capaian pembelajaran.
   - Menghasilkan dokumen RPP berstandar nasional lengkap dengan teks Arab berharakat, rubrik asesmen otentik, serta tombol salin dan cetak PDF.
   - Otomatis tersimpan ke sheet `RPP_Modul_Ajar`.
3. **Modul 03: Asisten Al-Ustadz AI**:
   - Dialog interaktif mengenai Nahwu (I'rab), Saraf, Balaghah, dan metodologi pengajaran.
   - Percakapan terekam di sheet `Tutor_Chat`.
4. **Modul 04: Pre-Test & Uji Mandiri HOTS UKMPPG**:
   - Bank soal HOTS pilihan ganda dilengkapi timer hitung mundur.
   - Pembahasan mendalam atas setiap butir soal.
   - Nilai akhir otomatis tersimpan di sheet `Pretest_Quiz`.
5. **Modul 05: Progres Belajar & Sertifikat Kelulusan Digital**:
   - Pelacakan kompetensi 4 pilar.
   - Sertifikat digital resmi kelulusan berpredikat Mumtaz lengkap dengan nomor registrasi, identitas mahasiswa dinamis, dan tombol cetak/unduh PDF.
6. **Panel Dosen Penguji**:
   - Dosen dapat mengklik tab **Panel Dosen** untuk meninjau seluruh pekerjaan mahasiswa yang ditarik langsung dari sheet `Penilaian_Dosen`.
   - Dosen dapat menginput nilai huruf (A/B/C) dan catatan rekomendasi yang langsung mengupdate Google Spreadsheet secara real-time.
7. **Tombol Pintas Google Spreadsheet**:
   - Pada bilah navigasi atas web app terdapat tombol **"Spreadsheet Database"** untuk membuka langsung spreadsheet data mahasiswa hanya dengan satu kali klik.

---

*Selamat menggunakan Media PPG Bahasa Arab AI! Jika ada pembaruan kode di kemudian hari, cukup edit di editor Apps Script lalu lakukan Deploy > Manage deployments > Edit > New version > Deploy.*
