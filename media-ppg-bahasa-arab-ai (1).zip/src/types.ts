export interface CaseOption {
  key: string;
  text: string;
  justification: string;
}

export interface PedagogicalCase {
  title: string;
  category: string;
  difficulty: string;
  description: string;
  question: string;
  hints: string[];
  multipleChoiceOptions: CaseOption[];
  correctOptionKey: string;
}

export interface EvaluationResult {
  score: number;
  strength: string;
  weakness: string;
  pedagogicalAnalysis: string;
  professionalAnalysis: string;
  recommendations: string[];
}

export interface ArabicExample {
  arabic: string;
  meaning: string;
}

export interface RppActivity {
  duration: string;
  steps: string[];
}

export interface RppRubric {
  aspect: string;
  criteria: string;
}

export interface LessonPlan {
  metadata: {
    title: string;
    grade: string;
    method: string;
    duration: string;
  };
  objectives: string[];
  materials: {
    mainPoints: string;
    arabicExamples: ArabicExample[];
  };
  activities: {
    preActivity: RppActivity;
    coreActivity: RppActivity & { description?: string };
    postActivity: RppActivity;
  };
  assessment: {
    technique: string;
    rubrics: RppRubric[];
  };
  pedagogicalInsigths: string;
}

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

export interface QuizQuestion {
  id: number;
  questionText: string;
  options: { key: string; text: string }[];
  correctKey: string;
  discussion: string;
}

export interface QuizSet {
  topic: string;
  quizTitle: string;
  questions: QuizQuestion[];
}
