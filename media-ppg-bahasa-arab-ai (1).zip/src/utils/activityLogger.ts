export interface UserActivity {
  id: string;
  timestamp: string;
  type: "kasus" | "rpp" | "chat" | "quiz";
  title: string;
  description: string;
  details?: string;
  score?: number;
  adminGrade?: string; // e.g. "A", "B+", "A-" or numeric
  adminNotes?: string;
  userName?: string;
}

export function logUserActivity(activity: {
  type: "kasus" | "rpp" | "chat" | "quiz";
  title: string;
  description: string;
  details?: string;
  score?: number;
}) {
  try {
    const saved = localStorage.getItem("ppg_activities");
    const list: UserActivity[] = saved ? JSON.parse(saved) : [];
    
    // Resolve current user name
    let currentUserName = "Mahasiswa PPG";
    try {
      const userStr = localStorage.getItem("ppg_user");
      if (userStr) {
        const parsed = JSON.parse(userStr);
        if (parsed && parsed.name) {
          currentUserName = parsed.name;
        }
      }
    } catch (err) {
      console.error("Failed to parse user in logger:", err);
    }

    const newActivity: UserActivity = {
      id: "act_" + Date.now() + "_" + Math.floor(Math.random() * 1000),
      timestamp: new Date().toLocaleString("id-ID", {
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      }) + " WIB",
      ...activity,
      userName: currentUserName,
      adminGrade: "",
      adminNotes: ""
    };
    
    list.unshift(newActivity);
    localStorage.setItem("ppg_activities", JSON.stringify(list));
    
    // Notify listeners
    window.dispatchEvent(new CustomEvent("ppg_activities_updated"));
  } catch (e) {
    console.error("Failed to log activity:", e);
  }
}

export function getActivities(): UserActivity[] {
  try {
    const saved = localStorage.getItem("ppg_activities");
    if (!saved) {
      return [];
    }
    return JSON.parse(saved);
  } catch (e) {
    console.error("Failed to get activities:", e);
    return [];
  }
}

export function updateActivityGrade(id: string, grade: string, notes: string) {
  try {
    const list = getActivities();
    const updated = list.map(act => {
      if (act.id === id) {
        return { ...act, adminGrade: grade, adminNotes: notes };
      }
      return act;
    });
    localStorage.setItem("ppg_activities", JSON.stringify(updated));
    window.dispatchEvent(new CustomEvent("ppg_activities_updated"));
  } catch (e) {
    console.error("Failed to update activity grade:", e);
  }
}
