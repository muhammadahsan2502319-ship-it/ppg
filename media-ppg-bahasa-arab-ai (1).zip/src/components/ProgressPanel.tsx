import { useState, useEffect } from "react";
import { 
  getActivities, 
  UserActivity 
} from "../utils/activityLogger";
import { 
  Trophy, 
  Clock, 
  Calendar, 
  Award, 
  ChevronRight, 
  Flame, 
  TrendingUp, 
  AlertCircle,
  HelpCircle,
  Sparkles,
  BookOpen,
  ArrowRight,
  ShieldAlert
} from "lucide-react";
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer,
  CartesianGrid
} from "recharts";

export default function ProgressPanel() {
  const [activities, setActivities] = useState<UserActivity[]>([]);
  const [filterDays, setFilterDays] = useState<"7" | "28" | "all">("7");
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);
  const [user, setUser] = useState<{name: string, role: string} | null>(null);
  const [certificateActionStatus, setCertificateActionStatus] = useState<string>("");

  const loadActivities = () => {
    setActivities(getActivities());
  };

  useEffect(() => {
    loadActivities();
    window.addEventListener("ppg_activities_updated", loadActivities);
    
    // Load current user from local storage
    try {
      const savedUser = localStorage.getItem("ppg_user");
      if (savedUser) {
        setUser(JSON.parse(savedUser));
      }
    } catch (err) {
      console.error("Failed to parse user in ProgressPanel:", err);
    }

    return () => {
      window.removeEventListener("ppg_activities_updated", loadActivities);
    };
  }, []);

  // Helper to map grade to numeric score
  const gradeToScore = (grade: string): number => {
    switch (grade) {
      case "A": return 95;
      case "A-": return 88;
      case "B+": return 83;
      case "B": return 78;
      case "C": return 70;
      case "D": return 55;
      default: return 70; // Default when graded but no score
    }
  };

  // Calculate average scores for gamified certificate
  const getAverageScores = () => {
    let pedSum = 0;
    let pedCount = 0;
    let profSum = 0;
    let profCount = 0;

    activities.forEach(act => {
      let score = act.score;
      if (act.adminGrade) {
        score = gradeToScore(act.adminGrade);
      }

      if (score === undefined || score === null || score === 0) return;

      const isProfessional = 
        act.title.toLowerCase().includes("nahwu") || 
        act.title.toLowerCase().includes("saraf") || 
        act.title.toLowerCase().includes("balaghah") || 
        act.description.toLowerCase().includes("nahwu") || 
        act.description.toLowerCase().includes("saraf") || 
        act.description.toLowerCase().includes("balaghah") ||
        act.type === "chat";

      if (isProfessional) {
        profSum += score;
        profCount++;
      } else {
        pedSum += score;
        pedCount++;
      }
    });

    const pScore = pedCount > 0 ? Math.round(pedSum / pedCount) : 0;
    const prScore = profCount > 0 ? Math.round(profSum / profCount) : 0;
    const computedAvg = (pScore > 0 && prScore > 0) ? Math.round((pScore + prScore) / 2) : (pScore || prScore || 0);

    return {
      pedScore: pScore,
      profScore: prScore,
      avgScore: computedAvg
    };
  };

  const { pedScore, profScore, avgScore } = getAverageScores();
  const isEligibleForCertificate = avgScore >= 85;

  const handleDownloadCertificate = () => {
    setCertificateActionStatus("Mengunduh sertifikat digital...");
    setTimeout(() => {
      setCertificateActionStatus("Sertifikat berhasil diunduh sebagai PDF!");
      setTimeout(() => setCertificateActionStatus(""), 3000);
    }, 1500);
  };

  const handlePrintCertificate = () => {
    window.print();
  };

  // 1. Calculate stats based on activities
  const totalActivities = activities.length;
  
  // Calculate total practice time (minutes)
  // Kasus: 10m, RPP: 20m, Quiz: 15m, Chat: 5m
  const totalPracticeTime = activities.reduce((sum, act) => {
    if (act.type === "kasus") return sum + 10;
    if (act.type === "rpp") return sum + 20;
    if (act.type === "quiz") return sum + 15;
    if (act.type === "chat") return sum + 5;
    return sum + 5;
  }, 0);

  // Calculate Streak
  // We can analyze activities dates to find the streak.
  // Standard simple streak calculator based on local dates
  const calculateStreak = () => {
    if (activities.length === 0) return { current: 0, longest: 0 };
    
    // Extract unique dates of activities formatted as YYYY-MM-DD
    const dates: string[] = activities.map(act => {
      // In activityLogger, timestamp is "12 Jul 2026, 09.00 WIB" or similar
      // We can parse or estimate a simple date
      const match = act.timestamp.match(/(\d+)\s([a-zA-Z]+)\s(\d{4})/);
      if (match) {
        const day = match[1];
        const monthStr = match[2];
        const year = match[3];
        const months: Record<string, string> = {
          "Jan": "01", "Feb": "02", "Mar": "03", "Apr": "04", "Mei": "05", "Jun": "06",
          "Jul": "07", "Ags": "08", "Sep": "09", "Okt": "10", "Nov": "11", "Des": "12"
        };
        const month = months[monthStr] || "01";
        return `${year}-${month}-${day.padStart(2, "0")}`;
      }
      return new Date().toISOString().split("T")[0]; // fallback
    });

    const uniqueDates: string[] = Array.from(new Set(dates)).sort((a, b) => b.localeCompare(a)); // desc sorted
    
    let currentStreak = 0;
    let longestStreak = 0;
    let tempStreak = 0;
    
    const todayStr = new Date().toISOString().split("T")[0];
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split("T")[0];

    // Check if user has practiced today or yesterday to continue streak
    const hasPracticedRecently = uniqueDates.includes(todayStr) || uniqueDates.includes(yesterdayStr);
    
    if (hasPracticedRecently) {
      let checkDate = new Date();
      // If didn't practice today but practiced yesterday, start checking from yesterday
      if (!uniqueDates.includes(todayStr) && uniqueDates.includes(yesterdayStr)) {
        checkDate = yesterday;
      }
      
      while (true) {
        const checkStr = checkDate.toISOString().split("T")[0];
        if (uniqueDates.includes(checkStr)) {
          currentStreak++;
          checkDate.setDate(checkDate.getDate() - 1);
        } else {
          break;
        }
      }
    }

    // Longest streak calculation
    if (uniqueDates.length > 0) {
      let prevDate = new Date(uniqueDates[0] as string);
      tempStreak = 1;
      longestStreak = 1;
      
      for (let i = 1; i < uniqueDates.length; i++) {
        const currentDate = new Date(uniqueDates[i] as string);
        const diffTime = Math.abs(prevDate.getTime() - currentDate.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays === 1) {
          tempStreak++;
          longestStreak = Math.max(longestStreak, tempStreak);
        } else if (diffDays > 1) {
          tempStreak = 1;
        }
        prevDate = currentDate;
      }
      longestStreak = Math.max(longestStreak, currentStreak);
    }

    return { current: currentStreak, longest: longestStreak };
  };

  const streak = calculateStreak();

  // 2. Generate weekly streak calendar highlights
  const getWeeklyCalendar = () => {
    const daysName = ["Se", "Se", "Ra", "Ka", "Ju", "Sa", "Mi"]; // Mo, Tu, We, Th, Fr, Sa, Su in Ind
    const daysLetter = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];
    const result = [];
    const today = new Date();
    const dayOfWeek = today.getDay(); // 0 is Sun, 1 is Mon, etc.
    const startOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek; // Monday offset

    // Get activities dates
    const activeDates = activities.map(act => {
      const match = act.timestamp.match(/(\d+)\s([a-zA-Z]+)\s(\d{4})/);
      if (match) {
        return parseInt(match[1]); // returns day of month
      }
      return new Date().getDate();
    });

    for (let i = 0; i < 7; i++) {
      const targetDate = new Date(today);
      targetDate.setDate(today.getDate() + startOffset + i);
      const dayNum = targetDate.getDate();
      const isToday = targetDate.toDateString() === today.toDateString();
      const hasActivity = activeDates.includes(dayNum);
      
      result.push({
        name: daysLetter[i],
        label: daysName[i],
        dateNum: dayNum,
        isToday,
        hasActivity
      });
    }
    return result;
  };

  const weeklyCalendar = getWeeklyCalendar();

  // 3. Level computation (XP = 50 XP per completed activity, plus extra based on scores)
  const totalXp = activities.reduce((sum, act) => {
    let xp = 50; // base xp
    if (act.score) xp += Math.round(act.score * 0.5); // score weight
    if (act.adminGrade) xp += 40; // extra grade points
    return sum + xp;
  }, 0);

  // Level thresholds: Lvl 1: < 150, Lvl 2: 150-350, Lvl 3: 350-700, Lvl 4: 700+
  const getLevelInfo = () => {
    if (totalXp < 150) {
      return { level: 1, xpCurrent: totalXp, xpTarget: 150, minutesLeft: Math.max(1, Math.round((150 - totalXp) / 10)) };
    } else if (totalXp < 400) {
      return { level: 2, xpCurrent: totalXp - 150, xpTarget: 250, minutesLeft: Math.max(1, Math.round((400 - totalXp) / 10)) };
    } else if (totalXp < 800) {
      return { level: 3, xpCurrent: totalXp - 400, xpTarget: 400, minutesLeft: Math.max(1, Math.round((800 - totalXp) / 10)) };
    } else {
      return { level: 4, xpCurrent: 1, xpTarget: 1, minutesLeft: 0 };
    }
  };

  const levelInfo = getLevelInfo();

  // 4. Latest Dosen Feedback
  const latestGrades = activities.filter(act => !!act.adminGrade);
  const latestFeedback = latestGrades[0]; // newest feedback is first

  // 5. Chart data: Accumulative Practice Time trend
  // We plot chronologically
  const getChartData = () => {
    if (activities.length === 0) return [];
    
    const sorted = [...activities].reverse();
    let accumulatedMinutes = 0;
    
    const rawData = sorted.map((act, idx) => {
      let duration = 5;
      if (act.type === "kasus") duration = 10;
      else if (act.type === "rpp") duration = 20;
      else if (act.type === "quiz") duration = 15;
      
      accumulatedMinutes += duration;
      
      // label
      const dateLabel = act.timestamp.split(",")[0] || act.timestamp.substring(0, 6);
      return {
        label: dateLabel,
        "Waktu Belajar (Menit)": accumulatedMinutes,
        "Skor": act.score || (act.adminGrade ? gradeToScore(act.adminGrade) : 70)
      };
    });

    // Filter based on selected filterDays
    if (filterDays === "7") {
      return rawData.slice(-7);
    } else if (filterDays === "28") {
      return rawData.slice(-28);
    }
    return rawData;
  };

  const chartData = getChartData();

  // 6. Achievements Unlocked
  const achievements = [
    {
      id: "rpp_init",
      title: "Arsitek Kurikulum",
      desc: "Menyusun RPP Bahasa Arab perdana.",
      unlocked: activities.some(act => act.type === "rpp"),
      badge: "🎓"
    },
    {
      id: "case_solver",
      title: "Analis Tindakan Kelas",
      desc: "Menyelesaikan simulasi kasus pedagogi.",
      unlocked: activities.some(act => act.type === "kasus"),
      badge: "📝"
    },
    {
      id: "hots_champ",
      title: "Kampiun HOTS",
      desc: "Skor di atas 80 pada Pre-test Mandiri.",
      unlocked: activities.some(act => act.type === "quiz" && (act.score || 0) >= 80),
      badge: "⚡"
    },
    {
      id: "ustadz_consult",
      title: "Linguis Aktif",
      desc: "Konsultasi kebahasaan dengan Al-Ustadz.",
      unlocked: activities.some(act => act.type === "chat"),
      badge: "💬"
    },
    {
      id: "certified_a",
      title: "Kompeten Unggul",
      desc: "Mendapat Predikat 'A' dari Dosen Penguji.",
      unlocked: activities.some(act => act.adminGrade === "A" || act.adminGrade === "A-"),
      badge: "🌟"
    }
  ];

  const unlockedCount = achievements.filter(a => a.unlocked).length;

  if (activities.length === 0) {
    return (
      <div id="progress-panel-empty" className="p-6 bg-slate-50/50 rounded-2xl border border-dashed border-slate-200 text-center flex flex-col items-center justify-center min-h-[450px]">
        <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4">
          <TrendingUp className="h-8 w-8 text-slate-400" />
        </div>
        <h3 className="text-base font-extrabold text-slate-800 font-sans">Belum Ada Aktivitas Terekam</h3>
        <p className="text-xs text-slate-500 mt-2 max-w-md leading-relaxed">
          Statistik grafik latihan, rentetan streak kalender, level kompetensi belajar, serta medali prestasi Anda akan langsung tersinkronisasi di sini setelah Anda menyimpan aktivitas belajar pertama.
        </p>
        <p className="text-xs text-emerald-700 font-bold mt-4 bg-emerald-50 border border-emerald-100 px-3 py-1.5 rounded-lg flex items-center gap-1.5">
          <Sparkles className="h-3.5 w-3.5" />
          <span>Silakan selesaikan Simulasi Kasus atau Penyusunan RPP terlebih dahulu!</span>
        </p>
      </div>
    );
  }

  return (
    <div id="progress-panel-content" className="space-y-6">
      
      {/* Intro Header */}
      <div className="bg-slate-50 border border-slate-100 p-4 rounded-xl flex items-center justify-between flex-wrap gap-4">
        <div>
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">DASHBOARD PERKEMBANGAN MANDIRI</h4>
          <p className="text-sm font-semibold text-slate-800 mt-1">
            Pantau seluruh statistik performa kependidikan Bahasa Arab Anda secara real-time.
          </p>
        </div>
        <div className="bg-emerald-50 border border-emerald-100 px-3 py-1 rounded-lg text-xs font-bold text-emerald-800 flex items-center gap-1.5 font-mono">
          <span>Rerata Kompetensi:</span>
          <span className="text-sm font-extrabold bg-emerald-600 text-white px-2 py-0.5 rounded">{avgScore}/100</span>
        </div>
      </div>

      {/* MODUL GAMIFIKASI: SERTIFIKAT PENCAPAIAN */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-md p-6 relative overflow-hidden" id="sertifikat-komponen">
        <div className="absolute right-0 top-0 translate-x-8 -translate-y-8 w-24 h-24 bg-amber-500/10 rounded-full blur-xl pointer-events-none" />
        
        <div className="flex items-center gap-3 border-b border-slate-100 pb-4 mb-5">
          <div className="p-2.5 bg-amber-50 text-amber-600 rounded-xl">
            <Award className="h-6 w-6" />
          </div>
          <div>
            <h4 className="text-sm font-black text-slate-800 font-sans tracking-tight">Sertifikat Kelulusan & Kompetensi Digital</h4>
            <p className="text-xs text-slate-500">Gamifikasi pencapaian unggul bagi Mahasiswa PPG Pendidikan Bahasa Arab.</p>
          </div>
        </div>

        {isEligibleForCertificate ? (
          /* ACTIVE / UNLOCKED CERTIFICATE */
          <div className="space-y-6">
            <div className="bg-[#faf9f5] border-8 border-double border-amber-600/40 rounded-xl p-6 sm:p-10 relative overflow-hidden shadow-xs select-none max-w-4xl mx-auto text-center" id="printable-certificate-frame">
              {/* Corner Ornaments */}
              <div className="absolute top-3 left-3 w-8 h-8 border-t-2 border-l-2 border-amber-600/60" />
              <div className="absolute top-3 right-3 w-8 h-8 border-t-2 border-r-2 border-amber-600/60" />
              <div className="absolute bottom-3 left-3 w-8 h-8 border-b-2 border-l-2 border-amber-600/60" />
              <div className="absolute bottom-3 right-3 w-8 h-8 border-b-2 border-r-2 border-amber-600/60" />

              {/* Watermark Logo */}
              <div className="absolute inset-0 flex items-center justify-center opacity-3 pointer-events-none select-none">
                <span className="text-[140px] font-bold text-amber-900/10 font-display">ع</span>
              </div>

              {/* Certificate Header */}
              <div className="space-y-2 relative z-10">
                <p className="text-[10px] sm:text-xs font-bold text-amber-800 uppercase tracking-widest font-mono">LPTK KEMENTERIAN AGAMA REPUBLIK INDONESIA</p>
                <h3 className="text-lg sm:text-2xl font-black text-slate-850 font-sans uppercase tracking-tight">SERTIFIKAT KOMPETENSI KOMPREHENSIF</h3>
                <div className="h-0.5 w-32 bg-amber-600/60 mx-auto my-3" />
                <p className="text-[10px] font-mono text-slate-400">Nomor Verifikasi Digital: PPG-CERT-ARAB-{avgScore}-{pedScore}{profScore}</p>
              </div>

              {/* Certificate Recipient */}
              <div className="my-8 relative z-10 space-y-2">
                <p className="text-xs text-slate-500 italic">Sertifikat ini dianugerahkan dengan hormat kepada:</p>
                <h2 className="text-xl sm:text-3xl font-black text-slate-900 border-b border-dashed border-slate-300 pb-2 max-w-lg mx-auto leading-normal">
                  {user?.name || "Mahasiswa PPG Arab"}
                </h2>
                <p className="text-xs font-semibold text-slate-600">Mahasiswa Pendidikan Profesi Guru (PPG) Bahasa Arab</p>
              </div>

              {/* Achievement Body */}
              <div className="max-w-2xl mx-auto my-6 relative z-10 text-xs text-slate-600 leading-relaxed font-serif">
                Telah dinyatakan <span className="text-emerald-700 font-bold uppercase">SANGAT KOMPETEN</span> dengan predikat <span className="text-amber-800 font-extrabold uppercase">MUMTAZ (UNGGUL)</span> dalam menyelesaikan rangkaian simulasi kependidikan mandiri, perancangan modul ajar Kurikulum Merdeka, interaksi tatap bahasa Arab Nahwu, Saraf, Balaghah, serta ujian komparatif kognitif berbasis HOTS dengan perolehan hasil:
                
                <div className="grid grid-cols-3 gap-2 max-w-sm mx-auto my-4 text-center font-sans text-[11px] bg-white/80 p-2 rounded-lg border border-amber-600/20 shadow-3xs">
                  <div className="border-r border-slate-100">
                    <span className="block text-slate-400 font-bold text-[9px] uppercase">PEDAGOGIK</span>
                    <span className="font-extrabold text-slate-850 font-mono text-xs">{pedScore} / 100</span>
                  </div>
                  <div className="border-r border-slate-100">
                    <span className="block text-slate-400 font-bold text-[9px] uppercase">PROFESIONAL</span>
                    <span className="font-extrabold text-slate-850 font-mono text-xs">{profScore} / 100</span>
                  </div>
                  <div>
                    <span className="block text-amber-800 font-bold text-[9px] uppercase">RATA-RATA</span>
                    <span className="font-black text-emerald-700 font-mono text-xs">{avgScore} / 100</span>
                  </div>
                </div>
              </div>

              {/* Signatures & Seal */}
              <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-6 relative z-10">
                <div className="text-left text-[10px] text-slate-400">
                  <p>Diterbitkan tanggal:</p>
                  <p className="font-bold text-slate-700">{new Date().toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" })}</p>
                  <p className="mt-1 font-mono text-[9px]">Sistem Verifikasi: @google/ai-studio</p>
                </div>

                {/* Decorative Official Seal */}
                <div className="relative flex items-center justify-center h-20 w-20">
                  <div className="absolute inset-0 bg-amber-500 rounded-full animate-spin duration-10000 opacity-20 border-2 border-dashed border-amber-600" />
                  <div className="h-16 w-16 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full flex flex-col items-center justify-center text-white border-2 border-amber-200 shadow-sm relative">
                    <Award className="h-7 w-7 text-white" />
                    <span className="text-[7px] font-black uppercase font-mono tracking-wider mt-0.5">PPG ARABIC</span>
                  </div>
                </div>

                <div className="text-right text-[10px] text-slate-500">
                  <p className="italic mb-4">Divalidasi secara digital oleh:</p>
                  <p className="font-bold text-slate-800 uppercase underline">Sistem LPTK PPG AI</p>
                  <p className="text-slate-400">Direktorat Pendidikan Islam</p>
                </div>
              </div>
            </div>

            {/* Print & Action Controls */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                onClick={handlePrintCertificate}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
              >
                Cetak Sertifikasi (Print)
              </button>
              <button
                onClick={handleDownloadCertificate}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
              >
                Unduh Sertifikat Digital
              </button>
              {certificateActionStatus && (
                <p className="text-xs text-emerald-700 font-bold font-sans animate-bounce w-full text-center mt-2">
                  ✨ {certificateActionStatus}
                </p>
              )}
            </div>
          </div>
        ) : (
          /* LOCKED CERTIFICATE (Gamification incentive) */
          <div className="bg-slate-50 rounded-xl border border-dashed border-slate-200 p-6 flex flex-col items-center text-center max-w-xl mx-auto">
            <div className="w-14 h-14 bg-indigo-50 border border-indigo-150 rounded-full flex items-center justify-center mb-3 text-indigo-600">
              🔒
            </div>
            <h5 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider font-mono">Sertifikat Kelulusan Belum Terbuka</h5>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Dapatkan Sertifikat Kompetensi Profesional resmi dari LPTK Digital! Anda harus memperoleh nilai rata-rata dari subjek <strong>Pedagogik</strong> dan <strong>Profesional</strong> minimal sebesar <strong>85</strong> untuk melahirkan sertifikat kehormatan berpredikat Mumtaz.
            </p>

            {/* Progress metric bars */}
            <div className="w-full mt-5 space-y-3.5 bg-white p-4 rounded-xl border border-slate-150 shadow-3xs text-left">
              <div>
                <div className="flex justify-between items-baseline text-[10px] font-bold text-slate-600 mb-1">
                  <span>Progres Skor Rata-rata:</span>
                  <span className="font-mono text-indigo-700 font-black">{avgScore} / 85</span>
                </div>
                <div className="h-2.5 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-indigo-600 rounded-full transition-all duration-500" 
                    style={{ width: `${Math.min(100, (avgScore / 85) * 100)}%` }}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2 text-[10px] text-slate-500 font-semibold border-t border-slate-100">
                <div>
                  <span className="block text-[8px] text-slate-400 font-bold font-mono">SKOR PEDAGOGIK:</span>
                  <span className={`font-mono font-bold text-xs ${pedScore >= 85 ? 'text-emerald-600' : 'text-slate-600'}`}>
                    {pedScore || 0} / 100 {pedScore >= 85 ? '✅' : ''}
                  </span>
                </div>
                <div>
                  <span className="block text-[8px] text-slate-400 font-bold font-mono">SKOR PROFESIONAL:</span>
                  <span className={`font-mono font-bold text-xs ${profScore >= 85 ? 'text-emerald-600' : 'text-slate-600'}`}>
                    {profScore || 0} / 100 {profScore >= 85 ? '✅' : ''}
                  </span>
                </div>
              </div>
            </div>

            <p className="text-[10px] font-bold text-emerald-800 bg-emerald-50 border border-emerald-100 px-3 py-1.5 rounded-lg mt-4 flex items-center gap-1.5">
              <Sparkles className="h-3 w-3 shrink-0" />
              <span>Selesaikan modul latihan kelas atau minta penilaian Dosen Penguji di Panel Admin untuk menaikkan skor Anda!</span>
            </p>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN: Feedbacks & Core Stats */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Yellow Daily Feedback Card */}
          <div 
            onClick={() => setShowFeedbackModal(true)}
            className="bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 p-5 rounded-2xl text-amber-950 flex justify-between items-center cursor-pointer shadow-sm transition-all duration-200"
          >
            <div className="space-y-1">
              <h4 className="text-base font-black font-sans leading-tight">Umpan Balik Dosen</h4>
              <p className="text-xs font-medium opacity-90 leading-snug">
                {latestFeedback 
                  ? `Catatan terbaru: "${latestFeedback.adminNotes || 'Dosen memberikan grade ' + latestFeedback.adminGrade}"`
                  : "Belhat umpan balik bimbingan harian Anda di sini."
                }
              </p>
            </div>
            <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center shrink-0 shadow-sm ml-4">
              <ChevronRight className="h-4 w-4 text-amber-600" />
            </div>
          </div>

          {/* Stats Card: Total Time */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-slate-50 text-slate-500 rounded-lg">
                <Clock className="h-5 w-5" />
              </div>
              <div>
                <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">STATISTIK BELAJAR</h5>
                <p className="text-xs text-slate-500 font-semibold">Akumulasi durasi pelatihan Anda.</p>
              </div>
            </div>

            <div className="border-t border-slate-100 pt-3">
              <span className="text-3xl font-black text-slate-800 font-mono tracking-tight">{totalPracticeTime}</span>
              <span className="text-xs text-slate-500 font-bold ml-1.5">menit</span>
              <p className="text-[10px] text-slate-400 mt-1">Total estimasi durasi penuntasan studi kasus & modul.</p>
            </div>
          </div>

          {/* Current Streak & Calendar Card */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div>
              <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">RENTETAN STREAK HARIAN</h5>
              <p className="text-[10px] text-slate-400 leading-normal mt-0.5">Jaga konsistensi belajar Anda minimal 3 menit setiap hari.</p>
            </div>

            <div className="grid grid-cols-2 gap-3 border-y border-slate-100 py-3">
              <div className="text-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase block font-mono">Streak Aktif:</span>
                <span className="text-2xl font-black text-emerald-600 font-mono flex items-center justify-center gap-1 mt-1">
                  <Flame className="h-5 w-5 fill-emerald-500 text-emerald-500" />
                  {streak.current} hari
                </span>
              </div>
              <div className="text-center border-l border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase block font-mono">Terpanjang:</span>
                <span className="text-2xl font-black text-slate-700 font-mono block mt-1">{streak.longest} hari</span>
              </div>
            </div>

            {/* Streak Calendar Grid */}
            <div className="space-y-2">
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono text-center">Kalender Latihan Minggu Ini:</p>
              <div className="grid grid-cols-7 gap-2 text-center">
                {weeklyCalendar.map((day, idx) => (
                  <div key={idx} className="space-y-1">
                    <span className="text-[9px] text-slate-400 font-bold block uppercase">{day.label}</span>
                    <div className={`h-8 w-8 rounded-full mx-auto flex items-center justify-center text-xs font-bold font-mono transition-all border ${
                      day.hasActivity 
                        ? "bg-emerald-600 border-emerald-600 text-white shadow-3xs" 
                        : day.isToday 
                          ? "bg-amber-50 border-amber-300 text-amber-800 font-extrabold ring-1 ring-amber-200" 
                          : "bg-slate-50 border-slate-150 text-slate-600"
                    }`}>
                      {day.dateNum}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: Level, Chart & Achievements */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Level Progress Banner */}
          <div className="bg-gradient-to-br from-indigo-700 to-indigo-900 p-6 rounded-2xl text-white shadow-md space-y-4">
            <div>
              <span className="text-[10px] bg-indigo-600 text-indigo-100 font-bold px-2 py-0.5 rounded-full tracking-wider uppercase font-mono">LEVEL KOMPETENSI</span>
              <h4 className="text-lg font-extrabold font-sans mt-1">Level {levelInfo.level} • {
                levelInfo.level === 1 ? "Mubtadi' (Pemula)" : 
                levelInfo.level === 2 ? "Mutawassit (Baik)" : 
                levelInfo.level === 3 ? "Mutaqaddim (Sangat Baik)" : "Mumtaz (Ahli / Master)"
              }</h4>
              <p className="text-xs text-indigo-200 leading-normal mt-0.5">Semakin banyak latihan yang diselesaikan, semakin matang keahlian pedagogik Anda.</p>
            </div>

            {levelInfo.level < 4 ? (
              <div className="space-y-1.5">
                <div className="flex justify-between items-baseline text-xs text-indigo-200">
                  <span>Estimasi waktu ke Level berikutnya: <strong className="text-white font-extrabold">{levelInfo.minutesLeft} menit</strong></span>
                  <span className="font-mono text-[11px] font-bold">{levelInfo.xpCurrent} / {levelInfo.xpTarget} XP</span>
                </div>
                {/* Progress bar slider representation */}
                <div className="h-3 w-full bg-indigo-950/40 border border-indigo-500/20 rounded-full overflow-hidden p-0.5">
                  <div 
                    className="h-full bg-gradient-to-r from-emerald-400 to-teal-400 rounded-full transition-all duration-700" 
                    style={{ width: `${Math.min(100, (levelInfo.xpCurrent / levelInfo.xpTarget) * 100)}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-indigo-300 font-bold font-mono">
                  <span>Lvl {levelInfo.level}</span>
                  <span>Lvl {levelInfo.level + 1}</span>
                </div>
              </div>
            ) : (
              <div className="p-3 bg-white/10 rounded-xl border border-white/10 text-xs font-bold text-emerald-200 flex items-center gap-1.5">
                <Trophy className="h-4 w-4" />
                <span>Selamat! Anda telah mencapai level kompetensi tertinggi (Mumtaz).</span>
              </div>
            )}
          </div>

          {/* Area Chart: Practice Progression */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div>
                <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">KEMAJUAN BELAJAR AKUMULATIF</h5>
                <p className="text-[10px] text-slate-400">Representasi perkembangan waktu latihan terakumulasi.</p>
              </div>

              {/* Day filter buttons */}
              <div className="flex bg-slate-100 p-1 rounded-lg self-start sm:self-auto">
                {(["7", "28", "all"] as const).map(day => (
                  <button
                    key={day}
                    onClick={() => setFilterDays(day)}
                    className={`px-2.5 py-1 text-[10px] font-bold rounded-md transition-colors cursor-pointer ${
                      filterDays === day
                        ? "bg-white text-indigo-900 shadow-3xs"
                        : "text-slate-500 hover:text-slate-800"
                    }`}
                  >
                    {day === "all" ? "Semua" : `${day} Hari`}
                  </button>
                ))}
              </div>
            </div>

            <div className="h-56 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                  <defs>
                    <linearGradient id="practiceGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.25}/>
                      <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="label" stroke="#94a3b8" fontSize={10} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} />
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <Tooltip 
                    contentStyle={{ fontSize: 11, borderRadius: 8, borderColor: "#e2e8f0" }}
                    labelClassName="font-bold text-slate-700"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="Waktu Belajar (Menit)" 
                    stroke="#4f46e5" 
                    strokeWidth={2}
                    fillOpacity={1} 
                    fill="url(#practiceGrad)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            
            <p className="text-[10px] text-center text-slate-400 font-mono">
              Periode Aktif: {chartData[0]?.label || "N/A"} - {chartData[chartData.length-1]?.label || "N/A"}
            </p>
          </div>

          {/* Achievements Card Grid */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">MEDALI PRESTASI</h5>
                <p className="text-[10px] text-slate-400">Buka lencana keahlian berdasarkan aktivitas pembelajaran.</p>
              </div>
              <span className="text-xs bg-slate-100 text-slate-700 font-mono font-bold px-2 py-1 rounded-lg">
                {unlockedCount} / {achievements.length} Terbuka
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-1">
              {achievements.map((ach) => (
                <div 
                  key={ach.id} 
                  className={`p-3 rounded-xl border flex items-start gap-3 transition-colors ${
                    ach.unlocked 
                      ? "bg-emerald-50/20 border-emerald-100" 
                      : "bg-slate-50/50 border-slate-150 opacity-60"
                  }`}
                >
                  <span className={`text-2xl shrink-0 p-1 rounded-lg ${ach.unlocked ? "bg-emerald-50" : "bg-slate-100"}`}>
                    {ach.unlocked ? ach.badge : "🔒"}
                  </span>
                  <div className="space-y-0.5">
                    <h6 className={`text-xs font-bold ${ach.unlocked ? "text-slate-800 font-extrabold" : "text-slate-500"}`}>{ach.title}</h6>
                    <p className="text-[10px] text-slate-400 leading-snug">{ach.desc}</p>
                    {ach.unlocked && (
                      <span className="text-[8px] bg-emerald-100 text-emerald-800 font-bold font-mono px-1.5 py-0.5 rounded uppercase inline-block mt-1">UNLOCKED</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

      {/* FEEDBACK MODAL ACCESSIBILITY */}
      {showFeedbackModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-xl overflow-hidden flex flex-col">
            <div className="bg-gradient-to-r from-amber-500 to-amber-600 p-5 text-white flex justify-between items-center">
              <h4 className="font-bold text-base flex items-center gap-1.5">
                <Award className="h-5 w-5" />
                Catatan Penilaian & Umpan Balik Dosen
              </h4>
              <button 
                onClick={() => setShowFeedbackModal(false)}
                className="text-white hover:text-amber-100 text-sm font-bold bg-white/10 w-7 h-7 rounded-full flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4">
              {latestGrades.length === 0 ? (
                <div className="text-center py-6 space-y-2">
                  <ShieldAlert className="h-10 w-10 text-amber-500 mx-auto" />
                  <p className="text-xs font-bold text-slate-700">Belum Ada Penilaian Resmi</p>
                  <p className="text-[11px] text-slate-500 leading-relaxed max-w-sm mx-auto">
                    Aktivitas Anda belum dinilai secara formal oleh Dosen Penguji. Lakukan simulasi tindakan kelas atau buat RPP, lalu beri tahu Dosen untuk memberikan sertifikasi/predikat di Panel Admin.
                  </p>
                </div>
              ) : (
                <div className="space-y-4 max-h-96 overflow-y-auto pr-1">
                  <p className="text-xs text-slate-500">Berikut adalah daftar lengkap aktivitas Anda yang telah dinilai oleh Dosen Penguji:</p>
                  <div className="space-y-3">
                    {latestGrades.map((act) => (
                      <div key={act.id} className="p-4 bg-amber-50/40 rounded-xl border border-amber-150 space-y-2">
                        <div className="flex justify-between items-start gap-2">
                          <div>
                            <span className="text-[9px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded uppercase font-mono">
                              {act.type === "kasus" ? "Simulasi" : "RPP"}
                            </span>
                            <h5 className="text-xs font-bold text-slate-800 mt-1">{act.title}</h5>
                          </div>
                          <span className="text-sm font-black font-mono bg-emerald-600 text-white px-2 py-0.5 rounded">
                            {act.adminGrade}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-600 italic bg-white p-2.5 rounded border border-amber-100 leading-relaxed">
                          &ldquo;{act.adminNotes || "Dosen memberikan predikat nilai tanpa ulasan."}&rdquo;
                        </p>
                        <span className="text-[9px] text-slate-400 block font-mono">Dinilai pada: {act.timestamp}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-100 text-right">
              <button 
                onClick={() => setShowFeedbackModal(false)}
                className="bg-slate-700 hover:bg-slate-800 text-white text-xs font-bold py-2 px-5 rounded-lg cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
