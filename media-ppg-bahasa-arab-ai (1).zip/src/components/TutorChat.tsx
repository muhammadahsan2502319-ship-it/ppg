import { useState, useRef, useEffect, useId, KeyboardEvent } from "react";
import { MessageSquare, Send, Cpu, GraduationCap, ArrowRight, CornerDownLeft } from "lucide-react";
import { ChatMessage } from "../types";
import { logUserActivity } from "../utils/activityLogger";

export default function TutorChat() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      content: "Ahlan wa sahlan! Saya **Al-Ustadz**, dosen pembimbing virtual Anda dalam PPG Bahasa Arab. \n\nSaya di sini untuk membantu Anda menguasai **Kompetensi Pedagogik** (strategi ajar, modul, PTK, asesmen) dan **Kompetensi Profesional** (kaidah Nahwu, Saraf, Balaghah, serta sastra Arab). Silakan tanyakan kesulitan belajar Anda, atau pilih topik rekomendasi di bawah ini!"
    }
  ]);
  const [input, setInput] = useState<string>("" );
  const [loading, setLoading] = useState<boolean>(false);
  
  const bottomRef = useRef<HTMLDivElement>(null);
  const textboxId = useId();

  const quickQuestions = [
    { text: "Tanya Metode", prompt: "Ustadz, bagaimana langkah-langkah konkret guru dalam mengaplikasikan Thariqah Mubasyarah (Metode Langsung) untuk melatih maharah kalam?" },
    { text: "Kaidah I'rab", prompt: "Ustadz, jelaskan perbedaan mendasar antara I'rab Lafdzi dan I'rab Taqdiri dalam ilmu Nahwu serta berikan contoh kalimat bersandangnya yang berharakat lengkap!" },
    { text: "Tips UKMPPG", prompt: "Ustadz, tolong bagikan strategi ampuh mempersiapkan Uji Kompetensi Mahasiswa Pendidikan Profesi Guru (UKMPPG) Bahasa Arab, terutama bagian ujian tertulis & UP!" },
    { text: "Soal HOTS", prompt: "Bagaimanakah penyusunan indikator soal bertaraf HOTS (Higher Order Thinking Skills) untuk menguji kompetensi membaca (maharah al-qira'ah)?" }
  ];

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async (customPrompt?: string) => {
    const textToSend = customPrompt || input;
    if (!textToSend.trim() || loading) return;

    // Check if user is typing admin command
    const trimmedInput = textToSend.trim().toLowerCase();
    if (trimmedInput === "admin" || trimmedInput === "admin login" || trimmedInput === "/admin" || trimmedInput === "login admin") {
      const adminUser = {
        name: "Dosen Penguji (Admin)",
        email: "dosen.penguji@ppg.id",
        avatarUrl: "",
        role: "admin"
      };
      localStorage.setItem("ppg_user", JSON.stringify(adminUser));
      setInput("");
      
      const userMsg: ChatMessage = { role: "user", content: textToSend };
      const systemReply: ChatMessage = { 
        role: "assistant", 
        content: "🔓 **Akses Penguji Terbuka!** Selamat datang, Bapak/Ibu Dosen Pembimbing. Anda sekarang masuk dengan akun **Admin (Dosen Penguji)**.\n\nSemua riwayat aktivitas peserta kini dapat Anda pantau dan nilai secara formal di tab **Evaluasi Admin** yang muncul di menu pelatihan!" 
      };
      
      setMessages(prev => [...prev, userMsg, systemReply]);
      
      // Dispatch events to notify App.tsx
      window.dispatchEvent(new CustomEvent("ppg_user_updated"));
      return;
    }

    const userMsg: ChatMessage = { role: "user", content: textToSend };
    setMessages(prev => [...prev, userMsg]);
    if (!customPrompt) setInput("");
    setLoading(true);

    try {
      // Build conversation sequence
      const sequence = [...messages, userMsg];
      
      const response = await fetch("/api/gemini/tutor-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: sequence })
      });

      if (!response.ok) {
        throw new Error("Gagal menerima respons tutor.");
      }

      const data = await response.json();
      setMessages(prev => [...prev, { role: "assistant", content: data.text }]);

      // Log student activity
      logUserActivity({
        type: "chat",
        title: "Konsultasi Al-Ustadz",
        description: `Bertanya seputar kaidah bahasa atau materi kependidikan.`,
        details: `Pertanyaan Guru: "${textToSend}"\n\nJawaban Al-Ustadz:\n${data.text}`
      });
    } catch (e) {
      console.error(e);
      setMessages(prev => [...prev, { role: "assistant", content: "Mohon maaf Ustadz/Ustadzah sekalian, terjadi gangguan sistem. Silakan ulangi pertanyaan Anda setelah ini." }]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Safe renderer for markdown bullet lists inside dialogs without complex libraries
  const renderMessageContent = (text: string) => {
    // Basic Markdown transformations (bold and linebreaks)
    return text.split("\n").map((line, idx) => {
      let trimmed = line.trim();
      let isBullet = trimmed.startsWith("- ") || trimmed.startsWith("* ");
      let processedLine = trimmed;
      if (isBullet) {
        processedLine = trimmed.substring(2);
      }

      // Simple **bold** detection
      const parts = processedLine.split("**");
      const element = parts.map((part, pIdx) => {
        if (pIdx % 2 === 1) {
          return <strong key={pIdx} className="font-bold text-slate-900">{part}</strong>;
        }
        return part;
      });

      if (isBullet) {
        return (
          <li key={idx} className="ml-5 list-disc text-xs text-slate-705 leading-relaxed mt-1">
            {element}
          </li>
        );
      }

      return (
        <p key={idx} className={`text-xs text-slate-700 leading-relaxed ${trimmed === "" ? "h-2" : "mt-1.5"}`}>
          {element}
        </p>
      );
    });
  };

  return (
    <div id="tutor-chat" className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden flex flex-col h-[600px]">
      
      {/* Chat Header */}
      <div className="bg-gradient-to-r from-emerald-800 to-teal-800 p-4 shrink-0 text-white flex items-center gap-3">
        <div className="h-10 w-10 rounded-full bg-emerald-600/50 flex items-center justify-center border border-emerald-500/30">
          <GraduationCap className="h-6 w-6 text-emerald-100" />
        </div>
        <div>
          <h3 className="text-sm font-bold font-sans">Al-Ustadz: Forum Konsultasi PPG</h3>
          <p className="text-[10px] text-emerald-100/80">Tanyakan Problematika Guru & Teori Linguistik Kapan Saja</p>
        </div>
      </div>

      {/* Suggested quick items */}
      <div className="bg-slate-50 p-2.5 shrink-0 border-b border-slate-100 flex items-center gap-2 overflow-x-auto whitespace-nowrap scrollbar-thin">
        <span className="text-[9px] font-bold text-slate-400 font-mono tracking-wider shrink-0 mr-1">TANTANGAN:</span>
        {quickQuestions.map((qq, index) => (
          <button
            key={index}
            id={`btn-qq-${index}`}
            onClick={() => handleSend(qq.prompt)}
            className="bg-white hover:bg-emerald-50 text-slate-700 hover:text-emerald-950 font-medium text-[10px] px-2.5 py-1.5 rounded-lg border border-slate-150 cursor-pointer shadow-2xs transition-colors shrink-0 flex items-center gap-1"
          >
            <span>{qq.text}</span>
            <ArrowRight className="h-2.5 w-2.5 text-slate-400" />
          </button>
        ))}
      </div>

      {/* Chat Messages scroll area */}
      <div className="flex-1 p-4 overflow-y-auto bg-slate-50/20 space-y-4">
        {messages.map((msg, index) => {
          const isAi = msg.role === "assistant";
          return (
            <div key={index} className={`flex ${isAi ? "justify-start" : "justify-end"}`}>
              <div className={`max-w-[82%] p-3.5 rounded-2xl ${
                isAi 
                  ? "bg-white border border-slate-150 text-slate-800 rounded-tl-none" 
                  : "bg-emerald-700 text-white rounded-tr-none"
              }`}>
                {isAi && (
                  <div className="flex items-center gap-1.5 mb-1 bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded text-[8px] font-bold tracking-wider font-mono w-max">
                    <Cpu className="h-2.5 w-2.5" />
                    <span>AL-USTADZ</span>
                  </div>
                )}
                
                <div className="space-y-1">
                  {isAi ? renderMessageContent(msg.content) : (
                    <p className="text-xs text-white leading-relaxed font-medium">{msg.content}</p>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {loading && (
          <div className="flex justify-start">
            <div className="bg-white border border-slate-100 p-3.5 rounded-2xl rounded-tl-none flex items-center gap-2">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span className="text-[10px] font-bold text-emerald-800 tracking-wider font-mono">Ustadz sedang mengetik mutiara ilmu...</span>
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input area */}
      <div className="p-3 border-t border-slate-100 shrink-0 bg-white">
        <div className="relative flex items-center">
          <textarea
            id={textboxId}
            rows={1}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ketik pertanyaan kompetensi Anda di sini (misal: 'jelaskan thariqah sam'iyah' atau 'contoh soal I'rab')..."
            className="w-full pr-12 pl-3 py-3 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-emerald-600 resize-none max-h-24 scrollbar-none"
          />
          <button
            id="btn-send-message"
            onClick={() => handleSend()}
            disabled={loading || !input.trim()}
            className="absolute right-2 p-2 bg-emerald-700 hover:bg-emerald-800 disabled:bg-slate-150 text-white hover:text-white rounded-lg cursor-pointer transition-colors"
          >
            <Send className="h-3.5 w-3.5" />
          </button>
        </div>
        <div className="flex justify-between items-center text-[9px] text-slate-400 mt-1 px-1">
          <span>Harakat dan format penulisan Arab didukung sepenuhnya.</span>
          <span className="flex items-center gap-1">Shift + Enter untuk baris baru <CornerDownLeft className="h-2 w-2" /></span>
        </div>
      </div>

    </div>
  );
}
