import { useState, useId } from "react";
import { 
  BookOpen, 
  HelpCircle, 
  CheckCircle, 
  XCircle, 
  Flame, 
  Cpu, 
  ChevronRight, 
  PenTool, 
  Compass, 
  Sparkles, 
  RotateCcw,
  BookMarked
} from "lucide-react";
import { PedagogicalCase, EvaluationResult } from "../types";
import { logUserActivity } from "../utils/activityLogger";

interface PedagogicSimulatorProps {
  onScoreEarned: (category: string, score: number) => void;
}

export default function PedagogicSimulator({ onScoreEarned }: PedagogicSimulatorProps) {
  const [category, setCategory] = useState<string>("NahwuSaraf");
  const [difficulty, setDifficulty] = useState<string>("Sedang");
  const [loading, setLoading] = useState<boolean>(false);
  const [currentCase, setCurrentCase] = useState<PedagogicalCase | null>(null);
  
  // MCQ state
  const [selectedMcqOption, setSelectedMcqOption] = useState<string | null>(null);
  const [mcqSubmitted, setMcqSubmitted] = useState<boolean>(false);

  // Essay state
  const [essayAnswer, setEssayAnswer] = useState<string>("");
  const [essayLoading, setEssayLoading] = useState<boolean>(false);
  const [evalResult, setEvalResult] = useState<EvaluationResult | null>(null);
  
  const [answerMode, setAnswerMode] = useState<"mcq" | "essay">("mcq");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showHint, setShowHint] = useState<boolean>(false);

  const categories = [
    { id: "NahwuSaraf", label: "Nahwu & Saraf", desc: "Konsep Kaidah & Tata Bahasa", icon: BookMarked },
    { id: "Mufrodat", label: "Kosa Kata (Mufrodāt)", desc: "Metode Retensi & Kontekstual", icon: BookOpen },
    { id: "Makharij", label: "Makhārijul Hurūf", desc: "Artikulasi Fisik & Tajwid", icon: Compass },
    { id: "Hiwar", label: "Percakapan (Kalam)", desc: "Kepercayaan Diri & Keaktifan", icon: Sparkles },
    { id: "QiraahKitabah", label: "Membaca & Menulis", desc: "Literasi Arab & Struktur Kreatif", icon: PenTool },
  ];

  const handleGenerateCase = async () => {
    setLoading(true);
    setErrorMsg(null);
    setCurrentCase(null);
    setSelectedMcqOption(null);
    setMcqSubmitted(false);
    setEssayAnswer("");
    setEvalResult(null);
    setShowHint(false);

    try {
      const response = await fetch("/api/gemini/case-generator", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ category, difficulty }),
      });
      if (!response.ok) {
        throw new Error("Gagal memuat skenario dari AI. Silakan coba lagi.");
      }
      const data = await response.json();
      setCurrentCase(data);
    } catch (err: any) {
      setErrorMsg(err.message || "Gagal menghubungkan ke server.");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitMcq = () => {
    if (!selectedMcqOption || !currentCase) return;
    setMcqSubmitted(true);
    const isCorrect = selectedMcqOption === currentCase.correctOptionKey;
    onScoreEarned(category, isCorrect ? 100 : 40);
    
    // Log user activity
    logUserActivity({
      type: "kasus",
      title: `Simulasi Kasus: ${currentCase.title}`,
      description: `Menyelesaikan kasus pilihan ganda kategori ${category} (${difficulty}).`,
      details: `Skenario: ${currentCase.description}\n\nPertanyaan: ${currentCase.question}\n\nJawaban Anda: (${selectedMcqOption}) ${currentCase.multipleChoiceOptions.find(o => o.key === selectedMcqOption)?.text || ""}\n\nHasil: ${isCorrect ? "BENAR (+100)" : "KURANG TEPAT (+40)"}`,
      score: isCorrect ? 100 : 40
    });
  };

  const handleEvaluateEssay = async () => {
    if (!essayAnswer.trim() || !currentCase) return;
    setEssayLoading(true);
    setErrorMsg(null);
    setEvalResult(null);

    try {
      const response = await fetch("/api/gemini/case-evaluate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          caseDetail: currentCase,
          userAnswer: essayAnswer
        }),
      });
      if (!response.ok) {
        throw new Error("Gagal menguji jawaban melalui AI.");
      }
      const data: EvaluationResult = await response.json();
      setEvalResult(data);
      onScoreEarned(category, data.score);

      // Log user activity
      logUserActivity({
        type: "kasus",
        title: `Simulasi Kasus Esai: ${currentCase.title}`,
        description: `Menjawab kasus kependidikan kategori ${category} (${difficulty}).`,
        details: `Skenario: ${currentCase.description}\n\nPertanyaan: ${currentCase.question}\n\nJawaban Anda: "${essayAnswer}"\n\nEvaluasi Sistem (Skor ${data.score}/100):\nKekuatan: ${data.strength}\nKelemahan: ${data.weakness}\nAnalisis Pedagogik: ${data.pedagogicalAnalysis}\nAnalisis Profesional: ${data.professionalAnalysis}`,
        score: data.score
      });
    } catch (err: any) {
      setErrorMsg(err.message || "Koneksi server bermasalah.");
    } finally {
      setEssayLoading(false);
    }
  };

  const handleReset = () => {
    setCurrentCase(null);
    setSelectedMcqOption(null);
    setMcqSubmitted(false);
    setEssayAnswer("");
    setEvalResult(null);
    setShowHint(false);
  };

  return (
    <div id="simulasi-pedagogik" className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
      <div className="bg-gradient-to-r from-emerald-800 to-teal-800 p-6 text-white">
        <h3 className="text-xl font-bold font-sans">Simulasi Kasus Tindakan Kelas PPG</h3>
        <p className="text-emerald-100/90 text-sm mt-1 max-w-3xl">
          Hadapi tantangan belajar-mengajar Bahasa Arab riil yang dinamis. Terapkan kompetensi pedagogik dan pengetahuan profesional Anda, lalu dapatkan evaluasi bimbingan instan berbasis kecerdasan buatan.
        </p>
      </div>

      <div className="p-6">
        {!currentCase ? (
          <div>
            <h4 className="text-sm font-semibold text-slate-700 mb-3">1. Pilih Area Kompetensi Fokus:</h4>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3 mb-6">
              {categories.map((cat) => {
                const Icon = cat.icon;
                const isSelected = category === cat.id;
                return (
                  <button
                    key={cat.id}
                    id={`btn-cat-${cat.id}`}
                    onClick={() => setCategory(cat.id)}
                    className={`flex flex-col items-center justify-center p-4 rounded-xl border text-center transition-all duration-200 cursor-pointer ${
                      isSelected 
                        ? "border-emerald-600 bg-emerald-50/50 text-emerald-800 ring-2 ring-emerald-600/10" 
                        : "border-slate-200 hover:border-slate-300 bg-white text-slate-600"
                    }`}
                  >
                    <Icon className={`h-6 w-6 mb-2 ${isSelected ? 'text-emerald-700' : 'text-slate-400'}`} />
                    <span className="text-xs font-bold font-sans tracking-tight">{cat.label}</span>
                    <span className="text-[10px] text-slate-400 mt-1 leading-tight">{cat.desc}</span>
                  </button>
                );
              })}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-50 p-4 rounded-xl border border-slate-100 mb-6">
              <div className="flex items-center gap-3">
                <span className="text-xs font-bold text-slate-600">Tingkat Kesulitan Kasus:</span>
                <div className="flex gap-1">
                  {["Mudah", "Sedang", "Sukar"].map((lvl) => (
                    <button
                      key={lvl}
                      id={`btn-diff-${lvl}`}
                      onClick={() => setDifficulty(lvl)}
                      className={`px-3 py-1 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                        difficulty === lvl
                          ? "bg-slate-800 text-white font-bold"
                          : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-100"
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>

              <button
                id="btn-generate-case"
                disabled={loading}
                onClick={handleGenerateCase}
                className="bg-emerald-700 hover:bg-emerald-800 disabled:bg-slate-300 text-white px-5 py-2.5 rounded-lg text-sm font-semibold flex items-center gap-2 cursor-pointer transition-colors shadow-sm ml-auto"
              >
                {loading ? (
                  <>
                    <Cpu className="h-4 w-4 animate-spin" />
                    <span>Sistem sedang menyusun kasus...</span>
                  </>
                ) : (
                  <>
                    <Flame className="h-4 w-4" />
                    <span>Mulai Simulasi Kasus</span>
                  </>
                )}
              </button>
            </div>
            
            {errorMsg && (
              <div className="p-4 bg-amber-50 rounded-xl border border-amber-200 text-amber-800 text-xs flex items-center gap-2">
                <XCircle className="h-4 w-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-6">
            {/* Case Display Card */}
            <div className="p-6 bg-slate-50 rounded-xl border border-slate-150 relative">
              <div className="flex items-center gap-2 mb-3">
                <span className="bg-emerald-100 text-emerald-800 font-bold px-2.5 py-0.5 rounded text-[10px] uppercase font-mono">
                  {categories.find(c => c.id === currentCase.category)?.label || currentCase.category}
                </span>
                <span className={`font-mono text-[10px] px-2 py-0.5 rounded font-bold ${
                  currentCase.difficulty === "Sukar" ? "bg-rose-100 text-rose-800" :
                  currentCase.difficulty === "Sedang" ? "bg-amber-100 text-amber-800" : "bg-blue-100 text-blue-800"
                }`}>
                  {currentCase.difficulty}
                </span>
                
                <button
                  id="btn-reload-simulation"
                  onClick={handleReset}
                  className="ml-auto text-xs text-slate-500 hover:text-emerald-700 flex items-center gap-1 cursor-pointer font-medium"
                >
                  <RotateCcw className="h-3 w-3" />
                  <span>Ulangi Seleksi</span>
                </button>
              </div>

              <h4 className="text-lg font-bold text-slate-800 font-sans mb-3">{currentCase.title}</h4>
              
              <div className="text-slate-600 text-sm leading-relaxed whitespace-pre-wrap mb-4 bg-white p-4 rounded-lg border border-slate-100">
                {currentCase.description}
              </div>

              <div className="border-t border-slate-200/60 pt-4 mt-4">
                <p className="text-xs font-bold text-slate-400 font-mono tracking-wider uppercase mb-1">Pertanyaan Analisi Guru:</p>
                <p className="text-sm font-semibold text-slate-800 leading-relaxed font-sans">{currentCase.question}</p>
              </div>

              <div className="flex items-center gap-2 mt-4">
                <button
                  id="btn-toggle-hint"
                  onClick={() => setShowHint(!showHint)}
                  className="text-xs text-emerald-700 hover:text-emerald-800 font-bold flex items-center gap-1 cursor-pointer bg-emerald-50 px-2.5 py-1.5 rounded"
                >
                  <HelpCircle className="h-3w w-3" />
                  {showHint ? "Sembunyikan Petunjuk" : "Lihat Petunjuk Teori (Hints)"}
                </button>
              </div>

              {showHint && (
                <div className="mt-3 bg-emerald-50/50 p-4 rounded-lg border border-emerald-100">
                  <span className="text-[10px] font-bold text-emerald-800 tracking-wider font-mono">PETUNJUK ANALISIS PPG:</span>
                  <ul className="list-disc pl-5 mt-1.5 text-xs text-slate-705 space-y-1">
                    {currentCase.hints.map((hint, idx) => (
                      <li key={idx}>{hint}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Mode Selector for Answering */}
            <div className="flex items-center gap-1 border-b border-slate-100 pb-1">
              <button
                id="tab-answer-mcq"
                type="button"
                onClick={() => setAnswerMode("mcq")}
                className={`px-4 py-2 text-xs font-bold cursor-pointer border-b-2 transition-all ${
                  answerMode === "mcq" 
                    ? "border-emerald-700 text-emerald-800" 
                    : "border-transparent text-slate-400 hover:text-slate-600"
                }`}
              >
                Opsi Pilihan Ganda (Taktis)
              </button>
              <button
                id="tab-answer-essay"
                type="button"
                onClick={() => setAnswerMode("essay")}
                className={`px-4 py-2 text-xs font-bold cursor-pointer border-b-2 transition-all ${
                  answerMode === "essay" 
                    ? "border-emerald-700 text-emerald-800" 
                    : "border-transparent text-slate-400 hover:text-slate-600"
                }`}
              >
                Tindakan Guru Esai (Umpan Balik Kritis AI)
              </button>
            </div>

            {/* Answer Content */}
            {answerMode === "mcq" ? (
              <div className="space-y-4">
                <div className="grid grid-cols-1 gap-3">
                  {currentCase.multipleChoiceOptions.map((opt) => {
                    const isSelected = selectedMcqOption === opt.key;
                    const isCorrect = opt.key === currentCase.correctOptionKey;
                    
                    let cardBorder = "border-slate-200 hover:border-slate-300";
                    let cardBg = "bg-white";
                    
                    if (mcqSubmitted) {
                      if (isCorrect) {
                        cardBorder = "border-emerald-600 ring-1 ring-emerald-600/30";
                        cardBg = "bg-emerald-50/35";
                      } else if (isSelected) {
                        cardBorder = "border-rose-300";
                        cardBg = "bg-rose-50/20";
                      }
                    } else if (isSelected) {
                      cardBorder = "border-emerald-600 ring-1 ring-emerald-500/20";
                      cardBg = "bg-emerald-50/10";
                    }

                    return (
                      <button
                        key={opt.key}
                        id={`mcq-opt-${opt.key}`}
                        disabled={mcqSubmitted}
                        onClick={() => setSelectedMcqOption(opt.key)}
                        className={`w-full text-left p-4 rounded-xl border flex items-start gap-3 transition-all ${cardBorder} ${cardBg} ${!mcqSubmitted && 'cursor-pointer'}`}
                      >
                        <span className={`h-6 w-6 shrink-0 rounded-full flex items-center justify-center text-xs font-bold font-mono border mt-0.5 ${
                          isSelected 
                            ? "bg-slate-800 text-white border-slate-800" 
                            : "bg-slate-50 text-slate-600 border-slate-200"
                        }`}>
                          {opt.key}
                        </span>
                        
                        <div className="space-y-1">
                          <p className="text-sm font-medium text-slate-700">{opt.text}</p>
                          
                          {mcqSubmitted && (
                            <div className="mt-2 text-xs pt-1.5 border-t border-slate-100">
                              <span className={`font-bold uppercase tracking-wider text-[9px] ${isCorrect ? 'text-emerald-700' : 'text-slate-400'}`}>
                                {isCorrect ? "Kunci Jawaban yang Benar" : "Komentar Analisis:"}
                              </span>
                              <p className="text-slate-500 mt-0.5 leading-relaxed italic">{opt.justification}</p>
                            </div>
                          )}
                        </div>

                        {mcqSubmitted && isCorrect && (
                          <CheckCircle className="h-5 w-5 text-emerald-600 shrink-0 ml-auto mt-0.5" />
                        )}
                        {mcqSubmitted && !isCorrect && isSelected && (
                          <XCircle className="h-5 w-5 text-rose-500 shrink-0 ml-auto mt-0.5" />
                        )}
                      </button>
                    );
                  })}
                </div>

                {!mcqSubmitted ? (
                  <button
                    id="btn-submit-mcq"
                    disabled={!selectedMcqOption}
                    onClick={handleSubmitMcq}
                    className="w-full sm:w-auto bg-emerald-700 hover:bg-emerald-800 disabled:bg-slate-200 disabled:text-slate-400 text-white font-bold py-2 px-6 rounded-lg text-sm cursor-pointer shadow-sm ml-auto mt-4"
                  >
                    Kirim Kunci Jawaban
                  </button>
                ) : (
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      {selectedMcqOption === currentCase.correctOptionKey ? (
                        <span className="text-emerald-700 font-bold text-sm flex items-center gap-1">
                          <CheckCircle className="h-4 w-4" /> Jawaban Anda Tepat! +100 Poin Kompetensi
                        </span>
                      ) : (
                        <span className="text-rose-700 font-semibold text-sm flex items-center gap-1">
                          <XCircle className="h-4 w-4" /> Jawaban Kurang Tepat. Pelajari penjelasannya.
                        </span>
                      )}
                    </div>
                    
                    <button
                      id="btn-next-mcq"
                      onClick={handleGenerateCase}
                      className="ml-auto bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold py-2 px-4 rounded-lg cursor-pointer"
                    >
                      Dapatkan Kasus Lainnya
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <label htmlFor="essay-input" className="text-xs font-bold text-slate-500">
                    Tuliskan Tindakan / Solusi Anda:
                  </label>
                  <textarea
                    id="essay-input"
                    rows={4}
                    value={essayAnswer}
                    disabled={essayLoading || !!evalResult}
                    onChange={(e) => setEssayAnswer(e.target.value)}
                    placeholder="Sebagai guru, jelaskan langkah taktis dan beralasan yang Anda lakukan (contoh: memfasilitasi media papan kantong dhomir, menerapkan strategi menyimak kontekstual, atau metode mubasyarah) untuk memecahkan problematika ini..."
                    className="w-full p-4 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-emerald-600 disabled:bg-slate-50 leading-relaxed"
                  />
                  <div className="flex justify-between items-center text-[11px] text-slate-400">
                    <span>Tulislah dengan detail berlandaskan teori pengajaran Bahasa Arab</span>
                    <span>Minimal direkomendasikan 30 kata</span>
                  </div>
                </div>

                {!evalResult ? (
                  <button
                    id="btn-submit-essay"
                    disabled={essayLoading || !essayAnswer.trim()}
                    onClick={handleEvaluateEssay}
                    className="bg-emerald-700 hover:bg-emerald-800 disabled:bg-slate-200 disabled:text-slate-400 text-white px-5 py-2.5 rounded-lg text-xs font-bold flex items-center gap-2 cursor-pointer ml-auto"
                  >
                    {essayLoading ? (
                      <>
                        <Cpu className="h-3.5 w-3.5 animate-spin" />
                        <span>Sistem sedang menguji jawaban medis akademis...</span>
                      </>
                    ) : (
                      <>
                        <Cpu className="h-3.5 w-3.5" />
                        <span>Kirim Ke Dosen Pembimbing Untuk Evaluasi</span>
                      </>
                    )}
                  </button>
                ) : (
                  <div className="space-y-6 pt-2">
                    {/* Score Ribbon */}
                    <div className="p-4 rounded-xl border flex items-center justify-between gap-4 bg-gradient-to-r from-emerald-50/40 to-teal-50/40 border-emerald-150">
                      <div>
                        <span className="text-[10px] font-bold text-emerald-800 tracking-wider font-mono">SKOR HASIL ANALISIS</span>
                        <div className="flex items-baseline gap-1 mt-0.5">
                          <span className="text-3xl font-extrabold text-emerald-900 leading-none">{evalResult.score}</span>
                          <span className="text-slate-400 text-sm font-medium">/100</span>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <span className="text-[10px] bg-emerald-600 text-white px-2 py-0.5 rounded font-mono font-bold">
                          {evalResult.score >= 80 ? "KOMPETEN" : evalResult.score >= 60 ? "PRESTASI SEDANG" : "PERLU BIMBINGAN"}
                        </span>
                        <p className="text-[10px] text-slate-400 mt-1">Metode: Generative Evaluator</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-emerald-50/20 p-4 rounded-xl border border-emerald-100">
                        <span className="font-bold text-emerald-800 text-xs flex items-center gap-1.5">
                          <CheckCircle className="h-3.5 w-3.5" /> Kekuatan Solusi Anda:
                        </span>
                        <p className="text-xs text-slate-600 mt-2 font-medium leading-relaxed">{evalResult.strength}</p>
                      </div>

                      <div className="bg-rose-50/10 p-4 rounded-xl border border-rose-100">
                        <span className="font-bold text-rose-800 text-xs flex items-center gap-1.5">
                          <XCircle className="h-3.5 w-3.5" /> Kelemahan / Hal Terlewat:
                        </span>
                        <p className="text-xs text-slate-600 mt-2 font-medium leading-relaxed">{evalResult.weakness}</p>
                      </div>
                    </div>

                    {/* Deeper Analysis */}
                    <div className="p-5 bg-slate-50 rounded-xl border border-slate-100 space-y-4">
                      <div>
                        <span className="text-xs font-bold text-slate-700 block">Analisis Pedagogis (Kependidikan):</span>
                        <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">{evalResult.pedagogicalAnalysis}</p>
                      </div>

                      <div className="border-t border-slate-200/50 pt-3">
                        <span className="text-xs font-bold text-slate-700 block">Analisis Profesional (Materi Bahasa Arab):</span>
                        <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">{evalResult.professionalAnalysis}</p>
                      </div>

                      <div className="border-t border-slate-200/50 pt-3">
                        <span className="text-xs font-bold text-slate-700 block mb-2">Rekomendasi Tindak Lanjut Guru:</span>
                        <ul className="space-y-1.5">
                          {evalResult.recommendations.map((rec, rIdx) => (
                            <li key={rIdx} className="text-xs text-slate-600 flex items-start gap-1.5">
                              <span className="bg-emerald-100 text-emerald-800 h-4 w-4 shrink-0 rounded-full flex items-center justify-center text-[10px] font-bold mt-0.5">
                                {rIdx + 1}
                              </span>
                              <span className="flex-1">{rec}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="flex justify-end gap-3 pt-2">
                      <button
                        id="btn-essay-retry"
                        onClick={() => {
                          setEvalResult(null);
                          setEssayAnswer("");
                        }}
                        className="border border-slate-200 hover:border-slate-300 text-slate-600 text-xs font-semibold py-2 px-4 rounded-lg cursor-pointer"
                      >
                        Revisi Jawaban
                      </button>
                      <button
                        id="btn-essay-next"
                        onClick={handleGenerateCase}
                        className="bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold py-2 px-4 rounded-lg cursor-pointer flex items-center gap-1"
                      >
                        <span>Kasus Berikutnya</span>
                        <ChevronRight className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
