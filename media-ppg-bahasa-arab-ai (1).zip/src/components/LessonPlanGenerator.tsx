import { useState } from "react";
import { 
  FileText, 
  Cpu, 
  Copy, 
  Check, 
  BookOpen, 
  Compass, 
  Heart,
  Grid,
  TrendingUp,
  Download
} from "lucide-react";
import { LessonPlan } from "../types";
import { logUserActivity } from "../utils/activityLogger";

export default function LessonPlanGenerator() {
  const [topic, setTopic] = useState<string>("Hiwar Percakapan tentang Profesi (Mihnah)");
  const [gradeLevel, setGradeLevel] = useState<string>("MTs Kelas VII");
  const [method, setMethod] = useState<string>("Pendekatan Komunikatif (al-Madkhal al-Ittishali)");
  const [duration, setDuration] = useState<string>("2 x 40 Menit");
  const [learningObjectives, setLearningObjectives] = useState<string>("Meningkatkan maharah kalam (bicara) dan keaktifan siswa mempraktikkan tanya jawab.");
  
  const [loading, setLoading] = useState<boolean>(false);
  const [rpp, setRpp] = useState<LessonPlan | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  const methodsList = [
    { label: "Metode Komunikatif (al-Madkhal al-Ittishali)", val: "Pendekatan Komunikatif (al-Madkhal al-Ittishali)" },
    { label: "Metode Langsung (al-Thariqah al-Mubasyarah)", val: "Metode Langsung (al-Thariqah al-Mubasyarah)" },
    { label: "Membaca Pemahaman (Thariqah al-Qira'ah)", val: "Metode Membaca (Thariqah al-Qira'ah)" },
    { label: "Tata Bahasa & Terjemah (al-Qawa'id wa al-Tarjamah)", val: "Metode Qawa'id wa Tarjamah" },
    { label: "Metode Audio-Lingual (al-Thariqah al-Sam'iyyah al-Syafahiyyah)", val: "Metode Audio-Lingual" }
  ];

  const suggestedTopics = [
    { title: "Hiwar Profesi (al-Mihnah)", grade: "MTs Kelas VII", method: "Pendekatan Komunikatif (al-Madkhal al-Ittishali)" },
    { title: "Isim Dhamir & Isim Isyarah", grade: "MI Kelas V", method: "Metode Langsung (al-Thariqah al-Mubasyarah)" },
    { title: "Qira'ah tentang Kebun Sekolah", grade: "MTs Kelas VIII", method: "Metode Membaca (Thariqah al-Qira'ah)" },
    { title: "Kitabah Ta'rif Nafs (Perkenalan Diri)", grade: "MA Kelas X", method: "Metode Qawa'id wa Tarjamah" }
  ];

  const handleApplySuggestion = (sug: typeof suggestedTopics[0]) => {
    setTopic(sug.title);
    setGradeLevel(sug.grade);
    setMethod(sug.method);
  };

  const handleGenerateRpp = async () => {
    setLoading(true);
    setRpp(null);
    setCopied(false);

    try {
      const response = await fetch("/api/gemini/lesson-plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          topic,
          gradeLevel,
          method,
          duration,
          learningObjectives
        })
      });
      if (!response.ok) {
        throw new Error("Gagal menyusun rpp.");
      }
      const data = await response.json();
      setRpp(data);

      // Log user activity
      logUserActivity({
        type: "rpp",
        title: `Penyusunan RPP: ${data.metadata.title}`,
        description: `Menyusun modul rencana pelaksanaan pembelajaran Bahasa Arab kelas ${data.metadata.grade}.`,
        details: `Tema Utama: ${data.metadata.title}\nJenjang/Kelas: ${data.metadata.grade}\nAlokasi: ${data.metadata.duration}\nMetodologi: ${data.metadata.method}\n\nPokok Materi:\n${data.materials.mainPoints}\n\nTujuan Pembelajaran:\n${data.objectives.join("\n")}`
      });
    } catch (e) {
      console.error(e);
      alert("Terjadi kesalahan saat memproses RPP dengan sistem.");
    } finally {
      setLoading(false);
    }
  };

  const handleCopyText = () => {
    if (!rpp) return;
    
    // Construct simple copyable markdown string
    let textStr = `=== RPP / RENCANA PELAKSANAAN PEMBELAJARAN ===\n\n`;
    textStr += `Judul: ${rpp.metadata.title}\n`;
    textStr += `Kelas: ${rpp.metadata.grade}\n`;
    textStr += `Metode: ${rpp.metadata.method}\n`;
    textStr += `Durasi: ${rpp.metadata.duration}\n\n`;
    
    textStr += `--- TUJUAN PEMBELAJARAN ---\n`;
    rpp.objectives.forEach(obj => textStr += `- ${obj}\n`);
    
    textStr += `\n--- MATERI & STRUKTUR BAHASA ARAB ---\n`;
    textStr += `Konsep Pokok:\n${rpp.materials.mainPoints}\n\n`;
    textStr += `Contoh Tulisan:\n`;
    rpp.materials.arabicExamples.forEach(ex => {
      textStr += `👉 Arab: ${ex.arabic}\n   Artinya: ${ex.meaning}\n`;
    });
    
    textStr += `\n--- LANGKAH-LANGKAH AKTIVITAS ---\n`;
    textStr += `1. Pendahuluan (${rpp.activities.preActivity.duration}):\n`;
    rpp.activities.preActivity.steps.forEach(st => textStr += `   - ${st}\n`);
    textStr += `2. Kegiatan Inti (${rpp.activities.coreActivity.duration}):\n`;
    if (rpp.activities.coreActivity.description) {
      textStr += `   Gambaran: ${rpp.activities.coreActivity.description}\n`;
    }
    rpp.activities.coreActivity.steps.forEach(st => textStr += `   - ${st}\n`);
    textStr += `3. Penutup (${rpp.activities.postActivity.duration}):\n`;
    rpp.activities.postActivity.steps.forEach(st => textStr += `   - ${st}\n`);
    
    textStr += `\n--- TEKNIK ASESMEN & RUANG PENILAIAN ---\n`;
    textStr += `Teknik: ${rpp.assessment.technique}\n`;
    rpp.assessment.rubrics.forEach(rub => {
      textStr += `- Aspek: ${rub.aspect}\n  Kriteria Penilaian: ${rub.criteria}\n`;
    });
    
    textStr += `\n--- ANALISIS PEDAGOGIS SEBAGAI REFLEKSI GURU ---\n`;
    textStr += rpp.pedagogicalInsigths;

    navigator.clipboard.writeText(textStr);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExportToPDF = () => {
    if (!rpp) return;

    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      alert("Mohon ijinkan pop-up browser Anda untuk melakukan ekspor dokumen formal.");
      return;
    }

    // Prepare content for print
    const content = `
      <!DOCTYPE html>
      <html lang="id">
      <head>
        <meta charset="utf-8">
        <title>RENCANA PELAKSANAAN PEMBELAJARAN - ${rpp.metadata.title}</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&family=Amiri&display=swap');
          
          body {
            font-family: 'Inter', 'Helvetica Neue', Arial, sans-serif;
            color: #1e293b;
            line-height: 1.6;
            padding: 40px;
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
          }
          
          .no-print-btn-container {
            margin-bottom: 30px;
            text-align: right;
          }
          
          .btn-print {
            background-color: #059669;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 14px;
            font-weight: bold;
            border-radius: 6px;
            cursor: pointer;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
          }
          
          .btn-print:hover {
            background-color: #047857;
          }

          .header {
            text-align: center;
            border-bottom: 3px double #94a3b8;
            padding-bottom: 15px;
            margin-bottom: 25px;
          }

          .header h1 {
            font-size: 18px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin: 0;
            color: #0f172a;
            font-weight: 800;
          }

          .header p {
            font-size: 12px;
            margin: 4px 0 0 0;
            color: #475569;
            font-weight: 600;
          }
          
          .header .sub {
            font-size: 11px;
            color: #059669;
            text-transform: uppercase;
            letter-spacing: 2px;
            font-weight: bold;
            margin-top: 5px;
          }

          .meta-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 25px;
            background-color: #f8fafc;
          }

          .meta-table td {
            padding: 8px 12px;
            border: 1px solid #cbd5e1;
            font-size: 12px;
          }

          .meta-table td.label {
            font-weight: bold;
            color: #475569;
            width: 25%;
            background-color: #f1f5f9;
          }

          .section-title {
            font-size: 13px;
            font-weight: bold;
            text-transform: uppercase;
            border-bottom: 1.5px solid #cbd5e1;
            padding-bottom: 4px;
            margin-top: 25px;
            margin-bottom: 10px;
            color: #0f172a;
            letter-spacing: 0.5px;
          }

          ul, ol {
            padding-left: 20px;
            margin-top: 5px;
            margin-bottom: 15px;
          }

          li {
            font-size: 12px;
            margin-bottom: 6px;
            color: #334155;
          }

          .materi-box {
            border: 1px solid #e2e8f0;
            background-color: #fafafa;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 15px;
          }

          .materi-box p {
            font-size: 12px;
            margin: 0 0 10px 0;
          }

          .arabic-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #fff;
            padding: 8px 12px;
            border: 1px solid #e2e8f0;
            border-radius: 4px;
            margin-bottom: 6px;
          }

          .arabic-text {
            font-family: 'Amiri', 'Traditional Arabic', serif;
            font-size: 18px;
            color: #065f46;
            direction: rtl;
            text-align: right;
          }

          .meaning-text {
            font-size: 11px;
            color: #64748b;
            font-style: italic;
          }

          .activity-step {
            margin-bottom: 15px;
          }

          .activity-step h4 {
            font-size: 12px;
            margin: 0 0 5px 0;
            color: #0f172a;
          }

          .rubric-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
          }

          .rubric-table th, .rubric-table td {
            border: 1px solid #cbd5e1;
            padding: 8px 10px;
            font-size: 11px;
            text-align: left;
          }

          .rubric-table th {
            background-color: #f1f5f9;
            color: #475569;
            font-weight: bold;
          }

          .reflection {
            background-color: #f0fdf4;
            border-left: 4px solid #10b981;
            padding: 12px 15px;
            font-size: 11.5px;
            color: #1e3a1e;
            border-radius: 0 6px 6px 0;
            margin-top: 15px;
            line-height: 1.5;
          }

          .signatures {
            margin-top: 50px;
            width: 100%;
            display: flex;
            justify-content: space-between;
          }

          .sig-box {
            text-align: center;
            width: 40%;
            font-size: 12px;
          }

          .sig-space {
            height: 70px;
          }

          @media print {
            .no-print {
              display: none !important;
            }
            body {
              padding: 0;
              color: #000;
            }
            .btn-print {
              display: none !important;
            }
          }
        </style>
      </head>
      <body>
        <div class="no-print-btn-container no-print">
          <button class="btn-print" onclick="window.print()">Cetak Dokumen / Simpan PDF</button>
        </div>

        <div class="header">
          <p class="sub">Pilot Project Pendidikan Profesi Guru (PPG)</p>
          <h1>RENCANA PELAKSANAAN PEMBELAJARAN (RPP)</h1>
          <p>Mata Pelajaran: Bahasa Arab &bull; Kurikulum Merdeka Belajar</p>
        </div>

        <table class="meta-table">
          <tr>
            <td class="label">Materi / Tema</td>
            <td>${rpp.metadata.title}</td>
            <td class="label">Jenjang / Kelas</td>
            <td>${rpp.metadata.grade}</td>
          </tr>
          <tr>
            <td class="label">Alokasi Waktu</td>
            <td>${rpp.metadata.duration}</td>
            <td class="label">Metodologi</td>
            <td>${rpp.metadata.method}</td>
          </tr>
        </table>

        <div class="section-title">I. Tujuan Pembelajaran</div>
        <ul>
          ${rpp.objectives.map(obj => `<li>${obj}</li>`).join("")}
        </ul>

        <div class="section-title">II. Materi Dan Contoh Kebahasaan</div>
        <div class="materi-box">
          <p><strong>Pokok Bahasan:</strong> ${rpp.materials.mainPoints}</p>
          <div style="margin-top: 10px;">
            <p style="font-weight: 600; font-size: 11px; text-transform: uppercase; color: #047857;">Kosakata & Ungkapan Model:</p>
            ${rpp.materials.arabicExamples.map(ex => `
              <div class="arabic-item">
                <span class="meaning-text">Artinya: "${ex.meaning}"</span>
                <span class="arabic-text">${ex.arabic}</span>
              </div>
            `).join("")}
          </div>
        </div>

        <div class="section-title">III. Langkah-Langkah Kegiatan Pembelajaran</div>
        
        <div class="activity-step">
          <h4>A. Kegiatan Pendahuluan (${rpp.activities.preActivity.duration})</h4>
          <ul>
            ${rpp.activities.preActivity.steps.map(step => `<li>${step}</li>`).join("")}
          </ul>
        </div>

        <div class="activity-step">
          <h4>B. Kegiatan Inti (${rpp.activities.coreActivity.duration})</h4>
          ${rpp.activities.coreActivity.description ? `<p style="font-size: 11px; font-style: italic; color: #059669; margin: 0 0 8px 0;">Fokus Metode: ${rpp.activities.coreActivity.description}</p>` : ""}
          <ul>
            ${rpp.activities.coreActivity.steps.map(step => `<li>${step}</li>`).join("")}
          </ul>
        </div>

        <div class="activity-step">
          <h4>C. Kegiatan Penutup (${rpp.activities.postActivity.duration})</h4>
          <ul>
            ${rpp.activities.postActivity.steps.map(step => `<li>${step}</li>`).join("")}
          </ul>
        </div>

        <div class="section-title">IV. Penilaian (Asesmen) Pembelajaran</div>
        <p style="font-size: 12px;"><strong>Teknik Penilaian:</strong> ${rpp.assessment.technique}</p>
        
        <table class="rubric-table">
          <thead>
            <tr>
              <th style="width: 30%">Aspek Penilaian</th>
              <th>Kriteria & Pedoman Penskoran</th>
            </tr>
          </thead>
          <tbody>
            ${rpp.assessment.rubrics.map(rub => `
              <tr>
                <td><strong>${rub.aspect}</strong></td>
                <td>${rub.criteria}</td>
              </tr>
            `).join("")}
          </tbody>
        </table>

        <div class="section-title">V. Catatan Refleksi Guru</div>
        <div class="reflection">
          <strong>Refleksi & Rekomendasi Pedagogis:</strong><br/>
          ${rpp.pedagogicalInsigths.replace(/\n/g, "<br/>")}
        </div>

        <div class="signatures">
          <div class="sig-box">
            Mengetahui,<br/>
            <strong>Kepala Madrasah</strong>
            <div class="sig-space"></div>
            __________________________<br/>
            NIP. ................................
          </div>
          <div class="sig-box">
            Malang, ${new Date().toLocaleDateString("id-ID", { day: 'numeric', month: 'long', year: 'numeric' })}<br/>
            <strong>Guru Mata Pelajaran</strong>
            <div class="sig-space"></div>
            <strong>Muhammad Ahsan</strong><br/>
            NIP. ................................
          </div>
        </div>

        <script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 500);
          }
        </script>
      </body>
      </html>
    `;

    printWindow.document.write(content);
    printWindow.document.close();
  };

  return (
    <div id="lesson-plan-generator" className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
      <div className="bg-gradient-to-r from-emerald-800 to-teal-800 p-6 text-white">
        <h3 className="text-xl font-bold font-sans">Penyusun RPP & Modul Ajar (Kombinasi Bilingual)</h3>
        <p className="text-emerald-100/90 text-sm mt-1 max-w-3xl">
          Rancang RPP adaptif dan komprehensif yang memadukan teori kependidikan modern dengan keakuratan penulisan materi Arab (lengkap harakat). Solusi praktis tugas lokakarya PPG Anda.
        </p>
      </div>

      <div className="p-6 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Input Section */}
        <div className="lg:col-span-5 space-y-5">
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
            <span className="text-xs font-bold text-slate-400 font-mono tracking-wider block mb-2 uppercase">REKOMENDASI TOPIK PILIHAN CEPAT:</span>
            <div className="flex flex-wrap gap-2">
              {suggestedTopics.map((sug, sIdx) => (
                <button
                  key={sIdx}
                  type="button"
                  id={`btn-sug-${sIdx}`}
                  onClick={() => handleApplySuggestion(sug)}
                  className="bg-white hover:bg-slate-100 text-[10px] text-emerald-800 font-semibold px-2.5 py-1.5 rounded border border-slate-150 cursor-pointer"
                >
                  📍 {sug.title} ({sug.grade})
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-1">
              <label htmlFor="input-topic" className="text-xs font-bold text-slate-700 block">Tema Pembelajaran / Topik Utama:</label>
              <input
                id="input-topic"
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="w-full text-xs font-medium p-3 border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-600 bg-white"
                placeholder="Misal: Al-Madrasah (Fasilitas Madrasah), Al-Usroh (Keluarga)..."
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label id="lbl-grade" className="text-xs font-bold text-slate-700 block">Jenjang / Kelas:</label>
                <input
                  aria-labelledby="lbl-grade"
                  type="text"
                  value={gradeLevel}
                  onChange={(e) => setGradeLevel(e.target.value)}
                  className="w-full text-xs font-medium p-3 border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-600 bg-white"
                  placeholder="Misal: MTs Kelas VII, MA Kelas XI"
                />
              </div>

              <div className="space-y-1">
                <label id="lbl-dur" className="text-xs font-bold text-slate-700 block">Alokasi Waktu:</label>
                <input
                  aria-labelledby="lbl-dur"
                  type="text"
                  value={duration}
                  onChange={(e) => setDuration(e.target.value)}
                  className="w-full text-xs font-medium p-3 border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-600 bg-white"
                  placeholder="Misal: 2 x 40 Menit"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label htmlFor="select-method" className="text-xs font-bold text-slate-700 block">Metode Pengajaran Utama:</label>
              <select
                id="select-method"
                value={method}
                onChange={(e) => setMethod(e.target.value)}
                className="w-full text-xs font-medium p-3 border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-600 bg-white"
              >
                {methodsList.map((m, mIdx) => (
                  <option key={mIdx} value={m.val}>{m.label}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label htmlFor="area-objectives" className="text-xs font-bold text-slate-700 block">Fokus Asesmen / Target Capaian Siswa:</label>
              <textarea
                id="area-objectives"
                rows={3}
                value={learningObjectives}
                onChange={(e) => setLearningObjectives(e.target.value)}
                className="w-full text-xs font-medium p-3 border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-600 bg-white leading-relaxed"
                placeholder="Tuliskan tujuan spesifik misal meningkatkan kelancaran pelafalan makhorij, pemahaman materi i'rab secara utuh, dll."
              />
            </div>
            
            <button
              id="btn-trigger-rpp"
              disabled={loading || !topic.trim()}
              onClick={handleGenerateRpp}
              className="w-full bg-emerald-700 hover:bg-emerald-800 disabled:bg-slate-300 text-white py-3 rounded-lg text-xs font-bold flex items-center justify-center gap-2 cursor-pointer shadow-sm"
            >
              {loading ? (
                <>
                  <Cpu className="h-4 w-4 animate-spin" />
                  <span>Sistem sedang merancang RPP... (10-15 dtk)</span>
                </>
              ) : (
                <>
                  <FileText className="h-4 w-4" />
                  <span>Buat RPP Terstruktur</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Output Document Panel */}
        <div className="lg:col-span-7 border-l border-slate-100 lg:pl-6">
          {!rpp ? (
            <div className="h-full min-h-[350px] flex flex-col items-center justify-center text-center p-8 bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
              <BookOpen className="h-10 w-10 text-slate-300 mb-3" />
              <p className="text-sm font-semibold text-slate-500">Belum ada RPP yang dirancang</p>
              <p className="text-xs text-slate-400 mt-1 max-w-sm leading-relaxed">
                Tentukan parameter di panel kiri, lalu klik tombol untuk mengutus sistem menyusun Rencana Pembelajaran berkualitas tinggi secara otomatis.
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              
              {/* Output Actions */}
              <div className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-100">
                <span className="text-[10px] text-emerald-800 font-bold flex items-center gap-1 font-mono">
                  ✨ RPP GENERATED SUCCESSFULLY
                </span>
                
                <div className="flex gap-2">
                  <button
                    id="btn-copy-rpp"
                    onClick={handleCopyText}
                    className="bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-bold py-1.5 px-3 rounded flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    {copied ? (
                      <>
                        <Check className="h-3.5 w-3.5 text-emerald-600" />
                        <span className="text-emerald-700 font-bold">Tersalin</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5 text-slate-400" />
                        <span>Salin Markdown</span>
                      </>
                    )}
                  </button>

                  <button
                    id="btn-export-pdf"
                    onClick={handleExportToPDF}
                    className="bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold py-1.5 px-3 rounded flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                  >
                    <Download className="h-3.5 w-3.5" />
                    <span>Ekspor ke PDF</span>
                  </button>
                </div>
              </div>

              {/* Rpp Simulated Document Layout */}
              <div className="p-6 border border-slate-200 rounded-2xl bg-white shadow-xs max-h-[550px] overflow-y-auto space-y-6 scrollbar-thin">
                
                {/* Header Pajangan */}
                <div className="text-center pb-4 border-b border-double border-slate-300">
                  <span className="text-[10px] font-bold text-slate-400 tracking-widest font-mono">PILOT PROJECT - KEMENTERIAN AGAMA / PPG</span>
                  <h4 className="text-base font-bold text-slate-800 mt-1 font-sans">MODUL AJAR / RENCANA PELAKSANAAN PEMBELAJARAN</h4>
                  <p className="text-xs text-emerald-700 font-semibold font-mono mt-0.5 uppercase">Mata Pelajaran: Bahasa Arab</p>
                </div>

                {/* Metadata Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-100">
                  <div>
                    <span className="text-[9px] font-bold text-slate-400 block font-mono">TEMA UTAMA</span>
                    <span className="text-xs font-semibold text-slate-700 leading-tight block">{rpp.metadata.title}</span>
                  </div>
                  <div>
                    <span className="text-[9px] font-bold text-slate-400 block font-mono">TINGKAT/KELAS</span>
                    <span className="text-xs font-semibold text-slate-700 leading-tight block">{rpp.metadata.grade}</span>
                  </div>
                  <div>
                    <span className="text-[9px] font-bold text-slate-400 block font-mono">ALOKASI WAKTU</span>
                    <span className="text-xs font-semibold text-slate-700 leading-tight block">{rpp.metadata.duration}</span>
                  </div>
                  <div>
                    <span className="text-[9px] font-bold text-slate-400 block font-mono">METODOLOGI KEBANGGAAN</span>
                    <span className="text-xs font-semibold text-slate-700 leading-tight block">{rpp.metadata.method}</span>
                  </div>
                </div>

                {/* Section: Tujuan */}
                <div>
                  <h5 className="text-xs font-bold text-slate-800 tracking-wider uppercase flex items-center gap-1.5 border-b border-slate-100 pb-1.5 mb-2 font-mono">
                    <TrendingUp className="h-3.5 w-3.5 text-emerald-600" />
                    I. Tujuan Instruksional Pembelajaran
                  </h5>
                  <ul className="list-disc pl-5 text-xs text-slate-650 space-y-1">
                    {rpp.objectives.map((obj, oIdx) => (
                      <li key={oIdx} className="leading-relaxed">{obj}</li>
                    ))}
                  </ul>
                </div>

                {/* Section: Materi Pembelajaran */}
                <div>
                  <h5 className="text-xs font-bold text-slate-800 tracking-wider uppercase flex items-center gap-1.5 border-b border-slate-100 pb-1.5 mb-2.5 font-mono">
                    <BookOpen className="h-3.5 w-3.5 text-emerald-600" />
                    II. Materi & Bahan Konstruksi Sastrawi
                  </h5>
                  <div className="bg-emerald-50/15 p-4 rounded-xl border border-emerald-100/50 space-y-3">
                    <p className="text-xs font-medium text-slate-600 leading-relaxed"><strong className="text-slate-800">Pokok Bahasan:</strong> {rpp.materials.mainPoints}</p>
                    
                    <div className="border-t border-slate-100 pt-2.5">
                      <span className="text-[10px] font-bold text-emerald-800 tracking-wider block font-mono mb-2">DIALOG MODEL & UNGKAPAN (MENGGUNAKAN HARAKAT):</span>
                      <div className="grid grid-cols-1 gap-2.5">
                        {rpp.materials.arabicExamples.map((ex, eIdx) => (
                          <div key={eIdx} className="bg-white p-3 rounded-lg border border-slate-150 flex flex-col md:flex-row items-start md:items-center justify-between gap-2">
                            <span className="text-base font-medium text-right text-emerald-950 font-sans tracking-wide md:order-last block" dir="rtl">
                              {ex.arabic}
                            </span>
                            <span className="text-[11px] text-slate-500 italic block">
                              Artinya: "{ex.meaning}"
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Section: Aktivitas */}
                <div>
                  <h5 className="text-xs font-bold text-slate-800 tracking-wider uppercase flex items-center gap-1.5 border-b border-slate-100 pb-1.5 mb-2.5 font-mono">
                    <Compass className="h-3.5 w-3.5 text-emerald-600" />
                    III. Langkah Kegiatan Pembelajaran Pendamping
                  </h5>
                  
                  <div className="relative border-l border-emerald-100 pl-4 ml-2.5 space-y-4">
                    {/* Pendahuluan */}
                    <div className="relative">
                      <span className="absolute -left-[21px] top-1 px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-850 text-[8px] font-bold">1</span>
                      <strong className="text-xs text-slate-800 block">Kegiatan Pendahuluan ({rpp.activities.preActivity.duration})</strong>
                      <ul className="list-disc pl-5 text-[11px] text-slate-550 space-y-1 mt-1 leading-relaxed">
                        {rpp.activities.preActivity.steps.map((st, sIdx) => <li key={sIdx}>{st}</li>)}
                      </ul>
                    </div>

                    {/* Inti */}
                    <div className="relative">
                      <span className="absolute -left-[21px] top-1 px-1.5 py-0.5 rounded-full bg-emerald-600 text-white text-[8px] font-bold">2</span>
                      <strong className="text-xs text-slate-800 block">Kegiatan Inti ({rpp.activities.coreActivity.duration})</strong>
                      {rpp.activities.coreActivity.description && (
                        <p className="text-[11px] text-emerald-800 font-medium bg-emerald-50 px-2 py-1 rounded mt-1 mb-1.5 italic">
                          Fokus Aktivitas Metode: {rpp.activities.coreActivity.description}
                        </p>
                      )}
                      <ul className="list-disc pl-5 text-[11px] text-slate-550 space-y-1 leading-relaxed">
                        {rpp.activities.coreActivity.steps.map((st, sIdx) => <li key={sIdx}>{st}</li>)}
                      </ul>
                    </div>

                    {/* Penutup */}
                    <div className="relative">
                      <span className="absolute -left-[21px] top-1 px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-850 text-[8px] font-bold">3</span>
                      <strong className="text-xs text-slate-800 block">Kegiatan Penutup / Tindak Lanjut ({rpp.activities.postActivity.duration})</strong>
                      <ul className="list-disc pl-5 text-[11px] text-slate-550 space-y-1 mt-1 leading-relaxed">
                        {rpp.activities.postActivity.steps.map((st, sIdx) => <li key={sIdx}>{st}</li>)}
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Section: Asesmen */}
                <div>
                  <h5 className="text-xs font-bold text-slate-800 tracking-wider uppercase flex items-center gap-1.5 border-b border-slate-100 pb-1.5 mb-2 font-mono">
                    <Grid className="h-3.5 w-3.5 text-emerald-600" />
                    IV. Penilaian / Asesmen Pembelajaran
                  </h5>
                  <p className="text-xs text-slate-650 leading-relaxed"><strong className="text-slate-800">Teknik Penilaian:</strong> {rpp.assessment.technique}</p>
                  
                  <div className="mt-2.5 overflow-hidden border border-slate-150 rounded-xl">
                    <table className="w-full text-left border-collapse text-[11px]">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-150">
                          <th className="p-2.5 font-bold text-slate-600 font-mono w-1/3">Aspek Kompetensi</th>
                          <th className="p-2.5 font-bold text-slate-600 font-mono">Kriteria Penilaian Guru (Skor Maks)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {rpp.assessment.rubrics.map((rub, rIdx) => (
                          <tr key={rIdx} className="border-b border-slate-100 last:border-0 hover:bg-slate-50/50">
                            <td className="p-2.5 font-bold text-slate-700">{rub.aspect}</td>
                            <td className="p-2.5 text-slate-550 leading-relaxed">{rub.criteria}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Section: Insights */}
                <div className="border-t-2 border-dashed border-slate-200 pt-4 mt-6">
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-150 space-y-1.5">
                    <span className="font-bold text-xs text-emerald-800 flex items-center gap-1">
                      <Heart className="h-3.5 w-3.5 text-emerald-600 fill-emerald-100" />
                      Refleksi & Wawasan Pedagogis:
                    </span>
                    <p className="text-[11px] text-slate-600 leading-relaxed whitespace-pre-wrap">{rpp.pedagogicalInsigths}</p>
                  </div>
                </div>

              </div>
              
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
