import { useState } from "react";
import { 
  Trophy, 
  Cpu, 
  Check, 
  X, 
  HelpCircle, 
  BookOpen, 
  ChevronRight, 
  RefreshCw,
  ArrowRight,
  GraduationCap
} from "lucide-react";
import { QuizSet, QuizQuestion } from "../types";
import { logUserActivity } from "../utils/activityLogger";

export default function HotsQuiz() {
  const [topic, setTopic] = useState<string>("Pedagogik");
  const [loading, setLoading] = useState<boolean>(false);
  const [quizSet, setQuizSet] = useState<QuizSet | null>(null);
  
  // Quiz running state
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [selectedKey, setSelectedKey] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [scoreCount, setScoreCount] = useState<number>(0);
  const [showDiscussion, setShowDiscussion] = useState<boolean>(false);
  
  // Results summary
  const [quizFinished, setQuizFinished] = useState<boolean>(false);
  const [userAnswersList, setUserAnswersList] = useState<Record<number, string>>({});

  const topicsList = [
    { id: "Pedagogik", name: "Kependidikan & Metodologi", desc: "Teori belajar, rpp, PTK arab & media" },
    { id: "NahwuSaraf", name: "Nahwu & Saraf (Profesional)", desc: "Kaidah I'rab, Tasrif, Bina', Harakat" },
    { id: "Balaghah", name: "Balaghah & Sastra", desc: "Ma'ani, Bayan (Tasybih/Majas), Badi'" },
    { id: "Evaluasi", name: "Asesmen & Kisi-Kisi HOTS", desc: "Penyusunan butir evaluasi maharah" }
  ];

  const handleFetchQuiz = async () => {
    setLoading(true);
    setQuizSet(null);
    setCurrentQuestionIndex(0);
    setSelectedKey(null);
    setIsAnswered(false);
    setScoreCount(0);
    setShowDiscussion(false);
    setQuizFinished(false);
    setUserAnswersList({});

    try {
      const response = await fetch("/api/gemini/quiz-generator", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic })
      });
      if (!response.ok) {
        throw new Error("Gagal mengunduh set soal.");
      }
      const data: QuizSet = await response.json();
      setQuizSet(data);
    } catch (e) {
      console.error(e);
      alert("Sistem sedang sibuk, silakan klik lagi untuk menyusun latihan alternatif.");
    } finally {
      setLoading(false);
    }
  };

  const handleSelectOption = (key: string) => {
    if (isAnswered) return;
    setSelectedKey(key);
  };

  const handleSubmitAnswer = () => {
    if (!selectedKey || !quizSet) return;
    
    setIsAnswered(true);
    const correctKey = quizSet.questions[currentQuestionIndex].correctKey;
    const isCorrect = selectedKey === correctKey;
    
    if (isCorrect) {
      setScoreCount(prev => prev + 1);
    }

    // Save user choice
    setUserAnswersList(prev => ({
      ...prev,
      [currentQuestionIndex]: selectedKey
    }));
  };

  const handleNextQuestion = () => {
    if (!quizSet) return;
    
    const nextIdx = currentQuestionIndex + 1;
    if (nextIdx < quizSet.questions.length) {
      setCurrentQuestionIndex(nextIdx);
      setSelectedKey(null);
      setIsAnswered(false);
      setShowDiscussion(false);
    } else {
      setQuizFinished(true);
      // Log user activity
      const finalScore = Math.round((scoreCount / quizSet.questions.length) * 100);
      logUserActivity({
        type: "quiz",
        title: `Uji Mandiri: ${quizSet.quizTitle}`,
        description: `Menyelesaikan ujian formatif kisi-kisi ${topic}.`,
        details: `Topik Kisi-Kisi: ${topic}\n\nSkor Akhir: ${finalScore}/100 (${scoreCount} dari ${quizSet.questions.length} Benar).`,
        score: finalScore
      });
    }
  };

  return (
    <div id="hots-quiz" className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
      
      <div className="bg-gradient-to-r from-emerald-800 to-teal-800 p-6 text-white">
         <h3 className="text-xl font-bold font-sans">Uji Kompetensi Mandiri UKMPPG Tarbiyah</h3>
         <p className="text-emerald-100/90 text-sm mt-1 max-w-3xl">
           Latih kemandirian pemecahan soal berstandar nasional (HOTS). Setiap pertanyaan dikompilasi secara real-time oleh sistem dengan menyertakan bahasan diskursus ilmiah untuk memantapkan pemahaman struktural.
         </p>
       </div>

      <div className="p-6">
        
        {/* Initial Topic Chooser Section */}
        {!quizSet && !quizFinished && (
          <div className="space-y-6">
            <h4 className="text-sm font-semibold text-slate-700">1. Pilih Kisi-Kisi Bidang Studi:</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {topicsList.map((t) => {
                const isSelected = topic === t.id;
                return (
                  <button
                    key={t.id}
                    id={`btn-topic-${t.id}`}
                    onClick={() => setTopic(t.id)}
                    className={`p-5 rounded-2xl border text-left cursor-pointer transition-all ${
                      isSelected 
                        ? "border-emerald-600 bg-emerald-50/40 text-emerald-950 ring-2 ring-emerald-600/15" 
                        : "border-slate-200 hover:border-slate-300 bg-white text-slate-700"
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <span className="text-xs font-bold font-sans tracking-tight block">{t.name}</span>
                      {isSelected && (
                        <span className="bg-emerald-600 text-white font-mono font-bold text-[8px] uppercase tracking-wider px-1.5 py-0.5 rounded">
                          FOCUS ACTIVE
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed font-sans">{t.desc}</p>
                  </button>
                );
              })}
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex items-center justify-between gap-4">
              <span className="text-xs font-semibold text-slate-500">
                Sistem akan menyusun 5 Soal Pilihan Ganda (A-E) acak berbasis data bank soal UKMPPG.
              </span>
              
              <button
                id="btn-trigger-quiz"
                disabled={loading}
                onClick={handleFetchQuiz}
                className="bg-emerald-700 hover:bg-emerald-800 disabled:bg-slate-300 text-white py-2.5 px-6 rounded-lg text-xs font-bold flex items-center gap-2 cursor-pointer shadow-sm transition-colors"
              >
                {loading ? (
                  <>
                    <Cpu className="h-3.5 w-3.5 animate-spin" />
                    <span>Mempersiapkan Lembar Soal...</span>
                  </>
                ) : (
                  <>
                    <BookOpen className="h-3.5 w-3.5" />
                    <span>Mulai Kerjakan Soal</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Current Question Running State */}
        {quizSet && !quizFinished && (
          <div className="space-y-6">
            
            {/* Quiz Indicator */}
            <div className="flex items-center justify-between bg-slate-50 p-3.5 rounded-xl border border-slate-100">
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">MATERI UJI:</span>
                <span className="text-xs font-bold text-emerald-800 ml-1.5 font-sans">{quizSet.quizTitle}</span>
              </div>
              
              <div className="text-right">
                <span className="text-xs font-bold font-mono tracking-wide text-slate-600">
                  Soal {currentQuestionIndex + 1} dari {quizSet.questions.length}
                </span>
              </div>
            </div>

            {/* Question Display */}
            {(() => {
              const q: QuizQuestion = quizSet.questions[currentQuestionIndex];
              return (
                <div className="space-y-5">
                  <div className="p-5 bg-emerald-50/10 rounded-2xl border border-emerald-100/50">
                    <span className="text-[9px] font-bold font-mono text-emerald-800 block uppercase tracking-widest mb-1.5">BUTIR PERTANYAAN:</span>
                    <p className="text-sm font-semibold text-slate-800 leading-relaxed font-sans">{q.questionText}</p>
                  </div>

                  {/* Options List A to E */}
                  <div className="grid grid-cols-1 gap-3">
                    {q.options.map((opt) => {
                      const isSelected = selectedKey === opt.key;
                      const isCorrect = opt.key === q.correctKey;
                      
                      let optBorder = "border-slate-200 hover:border-slate-300";
                      let optBg = "bg-white";
                      
                      if (isAnswered) {
                        if (isCorrect) {
                          optBorder = "border-emerald-600";
                          optBg = "bg-emerald-50/40";
                        } else if (isSelected) {
                          optBorder = "border-rose-400";
                          optBg = "bg-rose-50/20";
                        }
                      } else if (isSelected) {
                        optBorder = "border-slate-700 ring-1 ring-slate-700/10";
                        optBg = "bg-slate-50/50";
                      }

                      return (
                        <button
                          key={opt.key}
                          id={`quiz-opt-${opt.key}`}
                          disabled={isAnswered}
                          onClick={() => handleSelectOption(opt.key)}
                          className={`w-full text-left p-4 rounded-xl border transition-all flex items-start gap-3 ${optBorder} ${optBg} ${!isAnswered && 'cursor-pointer'}`}
                        >
                          <span className={`h-6 w-6 shrink-0 rounded-lg flex items-center justify-center text-xs font-bold font-mono border mt-0.5 ${
                            isSelected 
                              ? "bg-slate-800 text-white border-slate-800" 
                              : "bg-slate-50 text-slate-600 border-slate-200"
                          }`}>
                            {opt.key}
                          </span>
                          
                          <span className="text-xs font-medium text-slate-755 leading-relaxed mt-0.5">{opt.text}</span>

                          {isAnswered && isCorrect && <Check className="h-4 w-4 text-emerald-600 shrink-0 ml-auto mt-1" />}
                          {isAnswered && !isCorrect && isSelected && <X className="h-4 w-4 text-rose-500 shrink-0 ml-auto mt-1" />}
                        </button>
                      );
                    })}
                  </div>

                  {/* Operational Footer Actions */}
                  <div className="flex gap-3 justify-end pt-3">
                    {!isAnswered ? (
                      <button
                        id="btn-quiz-submit"
                        disabled={!selectedKey}
                        onClick={handleSubmitAnswer}
                        className="bg-emerald-700 hover:bg-emerald-800 disabled:bg-slate-200 disabled:text-slate-400 text-white text-xs font-bold py-2.5 px-6 rounded-lg cursor-pointer"
                      >
                        Kunci Jawaban Ujian
                      </button>
                    ) : (
                      <div className="w-full flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
                        <div className="flex items-center gap-2">
                          {selectedKey === q.correctKey ? (
                            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1.5 rounded border border-emerald-100 flex items-center gap-1">
                              <Check className="h-3.5 w-3.5" /> Jawaban Tepat! +20 Poin
                            </span>
                          ) : (
                            <span className="text-xs font-bold text-rose-700 bg-rose-50 px-2.5 py-1.5 rounded border border-rose-100 flex items-center gap-1">
                              <X className="h-3.5 w-3.5" /> Jawabannya Adalah ({q.correctKey})
                            </span>
                          )}
                          
                          <button
                            id="btn-toggle-discussion"
                            onClick={() => setShowDiscussion(!showDiscussion)}
                            className="text-xs text-slate-600 hover:text-emerald-800 font-semibold px-2 py-1.5 rounded cursor-pointer hover:bg-slate-100"
                          >
                            {showDiscussion ? "Tutup Pembahasan" : "Lihat Pembahasan Analitik"}
                          </button>
                        </div>

                        <button
                          id="btn-quiz-next"
                          onClick={handleNextQuestion}
                          className="bg-slate-800 hover:bg-slate-900 text-white font-bold py-2.5 px-5 rounded-lg text-xs cursor-pointer flex items-center justify-center gap-1 ml-auto"
                        >
                          <span>{currentQuestionIndex + 1 === quizSet.questions.length ? "Lihat Skor Evaluasi" : "Soal Berikutnya"}</span>
                          <ChevronRight className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Deeper Discussion Block */}
                  {isAnswered && showDiscussion && (
                    <div className="p-5 bg-amber-50/20 border border-amber-200/60 rounded-2xl relative space-y-1.5">
                      <span className="text-[9px] font-bold text-amber-800 tracking-wider font-mono uppercase block">DISKURUS ILMIAH SOAL:</span>
                      <p className="text-xs text-slate-655 leading-relaxed whitespace-pre-wrap">{q.discussion}</p>
                    </div>
                  )}

                </div>
              );
            })()}

          </div>
        )}

        {/* Quiz Finished Results State */}
        {quizFinished && quizSet && (
          <div className="text-center p-8 space-y-6">
            <div className="h-16 w-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto border-2 border-dashed border-emerald-500">
              <Trophy className="h-8 w-8 text-emerald-600" />
            </div>

            <div>
              <h4 className="text-lg font-bold text-slate-800 font-sans">Latihan Mandiri Selesai!</h4>
              <p className="text-xs text-slate-400 mt-1">Sertifikasi kemandirian Anda dalam pengajaran Bahasa Arab</p>
            </div>

            <div className="max-w-xs mx-auto p-4 bg-slate-50 border border-slate-100 rounded-2xl">
              <span className="text-[10px] font-bold text-slate-400 block font-mono">SKOR KELULUSAN PREDIKTIF</span>
              <div className="flex items-baseline justify-center gap-1.5 mt-1">
                <span className="text-4xl font-extrabold text-emerald-800 leading-none">
                  {Math.round((scoreCount / quizSet.questions.length) * 100)}
                </span>
                <span className="text-slate-400 text-sm">/100</span>
              </div>
              
              <div className="mt-3">
                <span className={`text-[9px] font-bold tracking-wider uppercase px-2.5 py-0.5 rounded ${
                  (scoreCount / quizSet.questions.length) >= 0.8 ? "bg-emerald-100 text-emerald-850" :
                  (scoreCount / quizSet.questions.length) >= 0.6 ? "bg-amber-100 text-amber-850" : "bg-rose-100 text-rose-850"
                }`}>
                  {(scoreCount / quizSet.questions.length) >= 0.8 ? "LULUS UKMPPG (Sangat Siap)" :
                   (scoreCount / quizSet.questions.length) >= 0.6 ? "LULUS PREDIKTIF (Butuh Pengulangan)" : "BELUM LULUS (Perlu Belajar Mandiri)"}
                </span>
              </div>
            </div>

            {/* Answer breakdown */}
            <div className="max-w-xl mx-auto space-y-3 pt-3 text-left">
              <span className="text-[10px] font-bold text-slate-400 block font-mono border-b border-slate-100 pb-1.5 uppercase">TINJAUAN JAWABAN ANDA:</span>
              <div className="space-y-2">
                {quizSet.questions.map((q, qidx) => {
                  const userAnswer = userAnswersList[qidx];
                  const isUserCorrect = userAnswer === q.correctKey;
                  return (
                    <div key={q.id} className="p-3 border border-slate-150 rounded-xl bg-white flex items-center justify-between gap-4">
                      <div className="flex items-start gap-2.5">
                        <span className={`h-5 w-5 shrink-0 rounded-full flex items-center justify-center text-[10px] font-bold border mt-0.5 ${
                          isUserCorrect ? "bg-emerald-50 border-emerald-200 text-emerald-800" : "bg-rose-50 border-rose-200 text-rose-800"
                        }`}>
                          {qidx + 1}
                        </span>
                        <div>
                          <p className="text-xs font-bold text-slate-700 line-clamp-1">{q.questionText}</p>
                          <p className="text-[10px] text-slate-400 mt-0.5">
                            Jawaban Anda: <strong className="text-slate-600 font-mono font-bold">({userAnswer})</strong> | Kunci Benar: <strong className="text-emerald-700 font-mono font-bold">({q.correctKey})</strong>
                          </p>
                        </div>
                      </div>

                      {isUserCorrect ? (
                        <Check className="h-4 w-4 text-emerald-600 shrink-0" />
                      ) : (
                        <X className="h-4 w-4 text-rose-500 shrink-0" />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Exit actions */}
            <div className="flex justify-center gap-3 pt-4">
              <button
                id="btn-quiz-exit"
                onClick={() => {
                  setQuizSet(null);
                  setQuizFinished(false);
                }}
                className="border border-slate-200 hover:border-slate-300 text-slate-600 text-xs font-bold py-2.5 px-5 rounded-lg cursor-pointer"
              >
                Ganti Kisi-Kisi
              </button>
              <button
                id="btn-quiz-restart"
                onClick={handleFetchQuiz}
                className="bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold py-2.5 px-5 rounded-lg cursor-pointer flex items-center gap-1"
              >
                <RefreshCw className="h-3 w-3" />
                <span>Kerjakan Ulang</span>
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
