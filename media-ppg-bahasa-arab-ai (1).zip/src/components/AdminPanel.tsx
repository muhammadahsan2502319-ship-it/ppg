import { useState, useEffect } from "react";
import { 
  getActivities, 
  updateActivityGrade, 
  UserActivity 
} from "../utils/activityLogger";
import { 
  FileCheck2, 
  CheckCircle, 
  Clock, 
  GraduationCap, 
  ChevronDown, 
  ChevronUp, 
  PenTool, 
  MessageSquare, 
  HelpCircle, 
  FileText, 
  Award, 
  Filter, 
  BookMarked,
  UserCheck2,
  Trash2,
  TrendingUp,
  Sparkles
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";

interface AdminPanelProps {
  onActivityGraded?: () => void;
}

export default function AdminPanel({ onActivityGraded }: AdminPanelProps) {
  const [activities, setActivities] = useState<UserActivity[]>([]);
  const [filterType, setFilterType] = useState<"all" | "kasus" | "rpp" | "chat" | "quiz">("all");
  const [expandedId, setExpandedId] = useState<string | null>(null);
  
  // Grading states
  const [selectedGrade, setSelectedGrade] = useState<string>("A");
  const [adminNotes, setAdminNotes] = useState<string>("");
  const [gradingId, setGradingId] = useState<string | null>(null);

  const loadActivities = () => {
    setActivities(getActivities());
  };

  useEffect(() => {
    loadActivities();
    
    const handleUpdate = () => {
      loadActivities();
      if (onActivityGraded) onActivityGraded();
    };
    
    window.addEventListener("ppg_activities_updated", handleUpdate);
    return () => {
      window.removeEventListener("ppg_activities_updated", handleUpdate);
    };
  }, [onActivityGraded]);

  const toggleExpand = (id: string) => {
    if (expandedId === id) {
      setExpandedId(null);
    } else {
      setExpandedId(id);
      // Preset grading states if already graded, else reset
      const act = activities.find(a => a.id === id);
      if (act) {
        setSelectedGrade(act.adminGrade || "A");
        setAdminNotes(act.adminNotes || "");
      }
    }
  };

  const handleGradeSubmit = (id: string) => {
    updateActivityGrade(id, selectedGrade, adminNotes);
    setGradingId(null);
    setExpandedId(null);
    // Trigger callback
    if (onActivityGraded) onActivityGraded();
  };

  const handleClearAll = () => {
    if (confirm("Apakah Anda yakin ingin menghapus semua log aktivitas peserta?")) {
      localStorage.setItem("ppg_activities", JSON.stringify([]));
      loadActivities();
    }
  };

  const filteredActivities = activities.filter(act => {
    if (filterType === "all") return true;
    return act.type === filterType;
  });

  const totalCount = activities.length;
  const gradedCount = activities.filter(a => !!a.adminGrade).length;
  const ungradedCount = totalCount - gradedCount;

  // Helper to map grade to numeric score
  const gradeToScore = (grade: string): number => {
    switch (grade) {
      case "A": return 95;
      case "A-": return 88;
      case "B+": return 83;
      case "B": return 78;
      case "C": return 70;
      case "D": return 55;
      default: return 70;
    }
  };

  // Generate chart data chronologically for pedagogical vs professional trends
  const getChartData = () => {
    if (activities.length === 0) return [];

    const sorted = [...activities].reverse(); // from oldest to newest
    let runningPedSum = 0;
    let runningPedCount = 0;
    let runningProfSum = 0;
    let runningProfCount = 0;

    const trendData: any[] = [];

    sorted.forEach((act, idx) => {
      let score = act.score;
      if (act.adminGrade) {
        score = gradeToScore(act.adminGrade);
      }

      if (score === undefined || score === null || score === 0) {
        score = 75; // fallback
      }

      const isProfessional = 
        act.title.toLowerCase().includes("nahwu") || 
        act.title.toLowerCase().includes("saraf") || 
        act.title.toLowerCase().includes("balaghah") || 
        act.description.toLowerCase().includes("nahwu") || 
        act.description.toLowerCase().includes("saraf") || 
        act.description.toLowerCase().includes("balaghah") ||
        act.type === "chat";

      if (isProfessional) {
        runningProfSum += score;
        runningProfCount++;
      } else {
        runningPedSum += score;
        runningPedCount++;
      }

      const pedAvg = runningPedCount > 0 ? Math.round(runningPedSum / runningPedCount) : null;
      const profAvg = runningProfCount > 0 ? Math.round(runningProfSum / runningProfCount) : null;

      trendData.push({
        label: act.timestamp.split(",")[0] || act.timestamp.substring(0, 6) || `Latihan ${idx+1}`,
        "Pedagogik": pedAvg !== null ? pedAvg : 75,
        "Profesional": profAvg !== null ? profAvg : 70,
        activityTitle: act.title
      });
    });

    return trendData;
  };

  const chartData = getChartData();

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "kasus":
        return <PenTool className="h-4 w-4 text-emerald-600" />;
      case "rpp":
        return <FileText className="h-4 w-4 text-blue-600" />;
      case "chat":
        return <MessageSquare className="h-4 w-4 text-purple-600" />;
      case "quiz":
        return <HelpCircle className="h-4 w-4 text-amber-600" />;
      default:
        return <FileCheck2 className="h-4 w-4 text-slate-600" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "kasus": return "Simulasi Kasus";
      case "rpp": return "Modul RPP";
      case "chat": return "Konsultasi";
      case "quiz": return "Uji Mandiri";
      default: return "Aktivitas";
    }
  };

  return (
    <div id="admin-panel" className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      {/* Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 p-6 text-white flex justify-between items-center">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 uppercase tracking-widest font-mono">
            <UserCheck2 className="h-4 w-4" /> PANEL EVALUASI UTAMA (ADMIN)
          </div>
          <h3 className="text-xl font-bold font-sans mt-1">Sistem Penilaian Kompetensi Peserta PPG</h3>
          <p className="text-slate-300 text-xs mt-1 max-w-2xl">
            Sebagai Penguji/Dosen Pembimbing, Anda dapat mereview seluruh jejak langkah kependidikan mahasiswa, menganalisis jawaban esai, dan memberikan umpan balik bersertifikasi resmi.
          </p>
        </div>
        <div className="hidden md:block">
          <div className="bg-emerald-600/20 border border-emerald-500/30 text-emerald-200 text-xs font-mono px-3 py-1.5 rounded-lg text-center">
            Mode Akses: <strong>Dosen Penguji</strong>
          </div>
        </div>
      </div>

      <div className="p-6">
        {/* Quick Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
            <span className="text-[10px] font-bold text-slate-400 block font-mono uppercase">TOTAL AKTIVITAS TEREKAM</span>
            <span className="text-2xl font-black text-slate-800 font-mono block mt-1">{totalCount}</span>
            <span className="text-[10px] text-slate-500 block mt-1">Semua jejak belajar murid</span>
          </div>
          <div className="bg-amber-50/50 p-4 rounded-xl border border-amber-100">
            <span className="text-[10px] font-bold text-amber-700 block font-mono uppercase">BELUM DIEVALUASI</span>
            <span className="text-2xl font-black text-amber-800 font-mono block mt-1">{ungradedCount}</span>
            <span className="text-[10px] text-amber-600 block mt-1">Butuh penilaian umpan balik</span>
          </div>
          <div className="bg-emerald-50/50 p-4 rounded-xl border border-emerald-100">
            <span className="text-[10px] font-bold text-emerald-700 block font-mono uppercase">TELAH BERGRADASI</span>
            <span className="text-2xl font-black text-emerald-800 font-mono block mt-1">{gradedCount}</span>
            <span className="text-[10px] text-emerald-600 block mt-1">Tercatat di sistem sertifikasi</span>
          </div>
        </div>

        {/* Recharts Data Visualization block */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">Grafik Tren Kompetensi Peserta</h4>
              <p className="text-[10px] sm:text-xs text-slate-500 font-medium">Tren perkembangan skor rata-rata kompetensi Pedagogik dan Profesional secara berkelanjutan.</p>
            </div>
            <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full flex items-center gap-1 font-mono">
              <TrendingUp className="h-3 w-3" /> Real-time Sync
            </span>
          </div>

          {activities.length === 0 ? (
            <div className="h-44 flex flex-col items-center justify-center text-center">
              <span className="text-2xl mb-1">📊</span>
              <p className="text-xs font-bold text-slate-700">Belum Ada Aktivitas Untuk Diplot</p>
              <p className="text-[10px] text-slate-400 mt-0.5">Grafik tren perkembangan skor pedagogik & profesional akan muncul setelah ada aktivitas yang disimpan oleh user.</p>
            </div>
          ) : (
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 10, right: 20, left: -25, bottom: 0 }}>
                  <XAxis dataKey="label" stroke="#94a3b8" fontSize={10} tickLine={false} />
                  <YAxis domain={[0, 100]} stroke="#94a3b8" fontSize={10} tickLine={false} />
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <Tooltip 
                    contentStyle={{ fontSize: 11, borderRadius: 8, borderColor: "#e2e8f0" }}
                    labelClassName="font-bold text-slate-700"
                  />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Line 
                    type="monotone" 
                    dataKey="Pedagogik" 
                    stroke="#10b981" 
                    strokeWidth={3} 
                    activeDot={{ r: 6 }} 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="Profesional" 
                    stroke="#3b82f6" 
                    strokeWidth={3} 
                    activeDot={{ r: 6 }} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        {/* Filters and Management */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 border-b border-slate-100 pb-4 mb-4">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-xs font-bold text-slate-500 mr-2 flex items-center gap-1">
              <Filter className="h-3.5 w-3.5" /> Saring:
            </span>
            {[
              { id: "all", label: "Semua" },
              { id: "kasus", label: "Simulasi Kasus" },
              { id: "rpp", label: "RPP" },
              { id: "chat", label: "Konsultasi" },
              { id: "quiz", label: "Uji Mandiri" }
            ].map(type => (
              <button
                key={type.id}
                id={`btn-filter-${type.id}`}
                onClick={() => setFilterType(type.id as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  filterType === type.id
                    ? "bg-emerald-700 text-white"
                    : "bg-slate-50 hover:bg-slate-100 text-slate-600"
                }`}
              >
                {type.label}
              </button>
            ))}
          </div>

          <button
            id="btn-admin-clear"
            onClick={handleClearAll}
            className="text-xs font-semibold text-rose-600 hover:text-rose-700 flex items-center justify-center gap-1 px-3 py-1.5 bg-rose-50 hover:bg-rose-100/60 rounded-lg border border-rose-100 cursor-pointer self-start md:self-auto transition-all"
          >
            <Trash2 className="h-3.5 w-3.5" />
            <span>Bersihkan Semua Log</span>
          </button>
        </div>

        {/* Activity List */}
        {filteredActivities.length === 0 ? (
          <div className="text-center p-12 border border-dashed border-slate-200 rounded-2xl bg-slate-50/50">
            <BookMarked className="h-10 w-10 text-slate-300 mx-auto mb-3" />
            <p className="text-sm font-bold text-slate-500">Tidak ada aktivitas yang sesuai filter</p>
            <p className="text-xs text-slate-400 mt-1">Lakukan latihan sebagai murid terlebih dahulu untuk mencatatkan aktivitas baru.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredActivities.map((act) => {
              const isExpanded = expandedId === act.id;
              const isGraded = !!act.adminGrade;

              return (
                <div 
                  key={act.id} 
                  id={`activity-card-${act.id}`}
                  className={`border rounded-xl transition-all ${
                    isExpanded 
                      ? "border-emerald-600 shadow-sm bg-white" 
                      : "border-slate-200 hover:border-slate-300 bg-white"
                  }`}
                >
                  {/* Card Header */}
                  <div 
                    onClick={() => toggleExpand(act.id)}
                    className="p-4 flex items-center justify-between gap-4 cursor-pointer select-none"
                  >
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-lg mt-0.5 ${
                        act.type === "kasus" ? "bg-emerald-50 text-emerald-800" :
                        act.type === "rpp" ? "bg-blue-50 text-blue-800" :
                        act.type === "chat" ? "bg-purple-50 text-purple-800" : "bg-amber-50 text-amber-800"
                      }`}>
                        {getActivityIcon(act.type)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                            {getTypeLabel(act.type)}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
                            <Clock className="h-2.5 w-2.5" /> {act.timestamp}
                          </span>
                          {act.userName && (
                            <span className="text-[10px] bg-indigo-50 border border-indigo-150 text-indigo-700 font-bold px-1.5 py-0.5 rounded-full flex items-center gap-0.5">
                              👤 {act.userName}
                            </span>
                          )}
                        </div>
                        <h4 className="text-xs font-extrabold text-slate-800 mt-0.5 leading-tight">{act.title}</h4>
                        <p className="text-xs text-slate-500 mt-1 leading-snug">{act.description}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      {isGraded ? (
                        <div className="flex items-center gap-1 bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded-lg border border-emerald-100">
                          <Award className="h-3.5 w-3.5 text-emerald-600" />
                          <span className="text-xs font-black font-mono">{act.adminGrade}</span>
                        </div>
                      ) : (
                        <span className="bg-amber-50 border border-amber-200 text-amber-700 text-[10px] font-bold font-mono px-2 py-0.5 rounded-full uppercase">
                          BELUM DINILAI
                        </span>
                      )}
                      
                      {isExpanded ? <ChevronUp className="h-4 w-4 text-slate-400" /> : <ChevronDown className="h-4 w-4 text-slate-400" />}
                    </div>
                  </div>

                  {/* Card Expanded Area */}
                  {isExpanded && (
                    <div className="px-4 pb-4 border-t border-slate-100 pt-4 space-y-4 bg-slate-50/40 rounded-b-xl">
                      {/* Action Details */}
                      {act.details && (
                        <div className="bg-white p-3.5 rounded-xl border border-slate-200/60">
                          <span className="text-[9px] font-black tracking-widest text-slate-400 uppercase font-mono block mb-1">DATA DETAIL AKTIVITAS SISWA:</span>
                          <p className="text-xs text-slate-700 leading-relaxed font-sans whitespace-pre-wrap">{act.details}</p>
                          {act.score !== undefined && (
                            <div className="mt-2 text-xs font-mono font-bold text-emerald-800">
                              Skor Sistem: {act.score}/100
                            </div>
                          )}
                        </div>
                      )}

                      {/* Display Current Evaluation if exist */}
                      {isGraded && (
                        <div className="bg-emerald-50/25 p-4 rounded-xl border border-emerald-100">
                          <span className="text-[9px] font-black tracking-widest text-emerald-800 uppercase font-mono block mb-1 flex items-center gap-1">
                            <CheckCircle className="h-3.5 w-3.5 text-emerald-600" /> EVALUASI DOSEN PENGUJI:
                          </span>
                          <div className="flex items-baseline gap-2 mt-1">
                            <span className="text-xs font-bold text-slate-500">Predikat Nilai:</span>
                            <span className="text-sm font-black text-emerald-950 font-mono bg-emerald-100 px-2 py-0.5 rounded">{act.adminGrade}</span>
                          </div>
                          {act.adminNotes && (
                            <div className="mt-2 text-xs text-slate-655 italic leading-relaxed">
                              &ldquo;{act.adminNotes}&rdquo;
                            </div>
                          )}
                        </div>
                      )}

                      {/* Grading Form */}
                      <div className="border-t border-slate-200/50 pt-4 mt-2">
                        <h5 className="text-xs font-extrabold text-slate-800 mb-3 flex items-center gap-1.5 font-sans">
                          <PenTool className="h-4 w-4 text-emerald-700" /> 
                          {isGraded ? "Perbarui Penilaian & Umpan Balik" : "Berikan Nilai & Rekomendasi"}
                        </h5>
                        
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-start">
                          <div>
                            <label className="text-[10px] font-bold text-slate-500 block mb-1 uppercase font-mono">PILIH PREDIKAT NILAI:</label>
                            <select
                              id={`select-grade-${act.id}`}
                              value={selectedGrade}
                              onChange={(e) => setSelectedGrade(e.target.value)}
                              className="w-full text-xs font-bold p-2.5 border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-600 bg-white"
                            >
                              <option value="A">A (Sangat Kompeten)</option>
                              <option value="A-">A- (Amat Baik)</option>
                              <option value="B+">B+ (Baik Sekali)</option>
                              <option value="B">B (Kompeten)</option>
                              <option value="C">C (Cukup Kompeten)</option>
                              <option value="D">D (Perlu Bimbingan)</option>
                            </select>
                          </div>

                          <div className="md:col-span-3">
                            <label className="text-[10px] font-bold text-slate-500 block mb-1 uppercase font-mono">UMPAN BALIK PEDAGOGIS:</label>
                            <div className="flex gap-2">
                              <input
                                id={`input-notes-${act.id}`}
                                type="text"
                                value={adminNotes}
                                onChange={(e) => setAdminNotes(e.target.value)}
                                className="flex-1 text-xs p-2.5 border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-600 bg-white"
                                placeholder="Tulis catatan, arahan teoretis atau pujian kompetensi di sini..."
                              />
                              <button
                                id={`btn-submit-grade-${act.id}`}
                                onClick={() => handleGradeSubmit(act.id)}
                                className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-4 py-2.5 rounded-lg text-xs cursor-pointer transition-colors shrink-0"
                              >
                                Simpan Nilai
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>

                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
