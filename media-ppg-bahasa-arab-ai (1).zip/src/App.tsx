/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, FormEvent } from "react";
import { 
  GraduationCap, 
  BookOpen, 
  FileText, 
  MessageSquare, 
  HelpCircle, 
  AlertTriangle, 
  Clock, 
  Award,
  BookMarked,
  ShieldCheck,
  CheckCircle,
  FileCheck2,
  ListRestart,
  Sparkles,
  ChevronRight,
  UserCheck2,
  User,
  Mail,
  Lock,
  GraduationCap as TeacherIcon,
  PanelLeft,
  PanelRight
} from "lucide-react";

import PedagogicSimulator from "./components/PedagogicSimulator";
import LessonPlanGenerator from "./components/LessonPlanGenerator";
import TutorChat from "./components/TutorChat";
import HotsQuiz from "./components/HotsQuiz";
import AdminPanel from "./components/AdminPanel";
import ProgressPanel from "./components/ProgressPanel";
import { getActivities } from "./utils/activityLogger";

export default function App() {
  const [activeTab, setActiveTab] = useState<"simulator" | "lesson" | "tutor" | "quiz" | "admin" | "progress">("simulator");
  const [hasApiKey, setHasApiKey] = useState<boolean>(true);
  const [checkingKey, setCheckingKey] = useState<boolean>(true);
  
  // Google Login State
  const [user, setUser] = useState<{ name: string; email: string; role: "user" | "admin" } | null>(() => {
    try {
      const saved = localStorage.getItem("ppg_user");
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Custom Auth Form States
  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [loginIdentifier, setLoginIdentifier] = useState<string>("");
  const [loginPassword, setLoginPassword] = useState<string>("");
  
  const [regUsername, setRegUsername] = useState<string>("");
  const [regEmail, setRegEmail] = useState<string>("");
  const [regPassword, setRegPassword] = useState<string>("");
  
  const [authError, setAuthError] = useState<string>("");
  const [authSuccess, setAuthSuccess] = useState<string>("");

  // Sidebar Visibility States for Workspace maximization
  const [showLeftSidebar, setShowLeftSidebar] = useState<boolean>(true);
  const [showRightSidebar, setShowRightSidebar] = useState<boolean>(true);

  // Stats stored in client memory (localStorage persistence)
  const [pedagogicalScore, setPedagogicalScore] = useState<number>(0);
  const [professionalScore, setProfessionalScore] = useState<number>(0);
  const [caseSolvedCount, setCaseSolvedCount] = useState<number>(0);
  const [rppGeneratedCount, setRppGeneratedCount] = useState<number>(0);

  const getWorkspaceSpan = () => {
    if (showLeftSidebar && showRightSidebar) return "lg:col-span-6";
    if (!showLeftSidebar && !showRightSidebar) return "lg:col-span-12";
    return "lg:col-span-9";
  };

  // States to track if modules have completed activity history
  const [hasSimulatorCompleted, setHasSimulatorCompleted] = useState<boolean>(false);
  const [hasLessonCompleted, setHasLessonCompleted] = useState<boolean>(false);
  const [hasTutorCompleted, setHasTutorCompleted] = useState<boolean>(false);
  const [hasQuizCompleted, setHasQuizCompleted] = useState<boolean>(false);

  // Helper to map grade to numeric score
  const gradeToScore = (grade: string): number => {
    switch (grade) {
      case "A": return 95;
      case "A-": return 88;
      case "B+": return 83;
      case "B": return 78;
      case "C": return 70;
      case "D": return 55;
      default: return 70;
    }
  };

  const calculateScoresAndStats = () => {
    const list = getActivities();
    
    // Compute module completion flags reactively
    setHasSimulatorCompleted(list.some(act => act.type === "kasus"));
    setHasLessonCompleted(list.some(act => act.type === "rpp"));
    setHasTutorCompleted(list.some(act => act.type === "chat"));
    setHasQuizCompleted(list.some(act => act.type === "quiz"));
    
    if (list.length === 0) {
      setPedagogicalScore(0);
      setProfessionalScore(0);
      setCaseSolvedCount(0);
      setRppGeneratedCount(0);
      return;
    }

    const kasusAndQuiz = list.filter(act => act.type === "kasus" || act.type === "quiz");
    const rpps = list.filter(act => act.type === "rpp");
    
    setCaseSolvedCount(kasusAndQuiz.length);
    setRppGeneratedCount(rpps.length);

    let pedSum = 0;
    let pedCount = 0;
    let profSum = 0;
    let profCount = 0;

    list.forEach(act => {
      let score = act.score;
      if (act.adminGrade) {
        score = gradeToScore(act.adminGrade);
      }

      if (score === undefined || score === null || score === 0) return;

      const isProfessional = 
        act.title.toLowerCase().includes("nahwu") || 
        act.title.toLowerCase().includes("saraf") || 
        act.title.toLowerCase().includes("balaghah") || 
        act.description.toLowerCase().includes("nahwu") || 
        act.description.toLowerCase().includes("saraf") || 
        act.description.toLowerCase().includes("balaghah") ||
        act.type === "chat";

      if (isProfessional) {
        profSum += score;
        profCount++;
      } else {
        pedSum += score;
        pedCount++;
      }
    });

    setPedagogicalScore(pedCount > 0 ? Math.round(pedSum / pedCount) : 0);
    setProfessionalScore(profCount > 0 ? Math.round(profSum / profCount) : 0);
  };

  useEffect(() => {
    calculateScoresAndStats();
    window.addEventListener("ppg_activities_updated", calculateScoresAndStats);
    return () => {
      window.removeEventListener("ppg_activities_updated", calculateScoresAndStats);
    };
  }, []);

  // Time stamp
  const [currentTime, setCurrentTime] = useState<string>("");

  useEffect(() => {
    const handleUserUpdate = () => {
      try {
        const saved = localStorage.getItem("ppg_user");
        const loadedUser = saved ? JSON.parse(saved) : null;
        setUser(loadedUser);
        if (loadedUser?.role === "admin") {
          setActiveTab("admin");
        }
      } catch {
        setUser(null);
      }
    };
    window.addEventListener("ppg_user_updated", handleUserUpdate);
    return () => window.removeEventListener("ppg_user_updated", handleUserUpdate);
  }, []);

  useEffect(() => {
    // Clock tick
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleString("id-ID", {
        weekday: "short",
        day: "numeric",
        month: "short",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
      }) + " WIB");
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    // Check API Key health from server safely on load
    const checkHealth = async () => {
      try {
        const response = await fetch("/api/health");
        const data = await response.json();
        setHasApiKey(data.hasApiKey);
      } catch (e) {
        console.error("Health check failed:", e);
        setHasApiKey(false);
      } finally {
        setCheckingKey(false);
      }
    };
    checkHealth();
  }, []);

  // Update real scores when elements trigger onScoreEarned
  const handleScoreEarned = (category: string, earnedScore: number) => {
    calculateScoresAndStats();
  };

  const handleResetScores = () => {
    if (confirm("Apakah Anda yakin ingin mengatur ulang semua progres latihan aktif Anda? Seluruh skor dan riwayat aktivitas belajar akan dikosongkan.")) {
      localStorage.setItem("ppg_activities", JSON.stringify([]));
      window.dispatchEvent(new CustomEvent("ppg_activities_updated"));
    }
  };

  const handleCustomRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    setAuthSuccess("");

    const username = regUsername.trim();
    const email = regEmail.trim();
    const password = regPassword;

    if (!username || !email || !password) {
      setAuthError("Semua kolom pendaftaran wajib diisi.");
      return;
    }

    if (!email.includes("@")) {
      setAuthError("Format Gmail/Email tidak valid.");
      return;
    }

    if (password.length < 5) {
      setAuthError("Kata sandi minimal harus 5 karakter.");
      return;
    }

    try {
      const savedUsers = localStorage.getItem("ppg_registered_users");
      const usersList = savedUsers ? JSON.parse(savedUsers) : [];

      const exists = usersList.some(
        (u: any) =>
          u.username.toLowerCase() === username.toLowerCase() ||
          u.email.toLowerCase() === email.toLowerCase()
      );

      if (exists || username.toLowerCase() === "admin" || email.toLowerCase() === "admin@ppg.id") {
        setAuthError("Username atau Email tersebut sudah terdaftar.");
        return;
      }

      const newUser = {
        username,
        email,
        password
      };

      usersList.push(newUser);
      localStorage.setItem("ppg_registered_users", JSON.stringify(usersList));

      setAuthSuccess(`Pendaftaran berhasil! Akun "${username}" telah dibuat. Silakan masuk.`);
      setAuthMode("login");
      setLoginIdentifier(email);
      setRegUsername("");
      setRegEmail("");
      setRegPassword("");
    } catch (err) {
      console.error(err);
      setAuthError("Terjadi kesalahan sistem saat mendaftarkan akun.");
    }
  };

  const handleCustomLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    setAuthSuccess("");

    const identifier = loginIdentifier.trim().toLowerCase();
    const password = loginPassword;

    if (!identifier || !password) {
      setAuthError("Harap masukkan Username/Email dan Kata Sandi.");
      return;
    }

    // Check Admin credentials
    if ((identifier === "admin" || identifier === "admin@ppg.id") && password === "admin123") {
      const adminUser = {
        name: "Dosen Penguji (Admin)",
        email: "admin@ppg.id",
        role: "admin" as const
      };
      localStorage.setItem("ppg_user", JSON.stringify(adminUser));
      setUser(adminUser);
      setActiveTab("admin");
      return;
    }

    // Check standard registered users
    try {
      const savedUsers = localStorage.getItem("ppg_registered_users");
      const usersList = savedUsers ? JSON.parse(savedUsers) : [];

      const foundUser = usersList.find(
        (u: any) =>
          (u.username.toLowerCase() === identifier || u.email.toLowerCase() === identifier) &&
          u.password === password
      );

      if (foundUser) {
        const loggedUser = {
          name: foundUser.username,
          email: foundUser.email,
          role: "user" as const
        };
        localStorage.setItem("ppg_user", JSON.stringify(loggedUser));
        setUser(loggedUser);
        setActiveTab("simulator");
      } else {
        setAuthError("Username/Email atau Kata Sandi Anda salah.");
      }
    } catch (err) {
      console.error(err);
      setAuthError("Gagal memproses masuk ke sistem.");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("ppg_user");
    setUser(null);
    setActiveTab("simulator");
  };

  // If user is not logged in, show Custom Login/Register form
  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex items-center justify-center p-4 antialiased">
        <div className="max-w-md w-full bg-white rounded-2xl border border-slate-200 shadow-lg overflow-hidden flex flex-col">
          {/* Top Banner */}
          <div className="bg-gradient-to-br from-emerald-800 to-teal-900 p-6 text-white text-center">
            <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-3 border border-white/25">
              <GraduationCap className="h-6 w-6 text-emerald-100" />
            </div>
            <h1 className="text-base font-black tracking-tight leading-tight uppercase font-sans">
              Portal Kompetensi PPG
            </h1>
            <p className="text-[11px] text-emerald-200/95 mt-1 font-medium">
              Pengembangan Model Pembelajaran Bahasa Arab LPTK Universitas Negeri Malang
            </p>
          </div>

          <div className="p-6 space-y-5">
            {/* Mode Switcher Buttons */}
            <div className="flex bg-slate-100 p-1 rounded-xl">
              <button
                type="button"
                onClick={() => {
                  setAuthMode("login");
                  setAuthError("");
                  setAuthSuccess("");
                }}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  authMode === "login"
                    ? "bg-white text-emerald-900 shadow-sm"
                    : "text-slate-500 hover:text-slate-800"
                }`}
              >
                Masuk Akun
              </button>
              <button
                type="button"
                onClick={() => {
                  setAuthMode("register");
                  setAuthError("");
                  setAuthSuccess("");
                }}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  authMode === "register"
                    ? "bg-white text-emerald-900 shadow-sm"
                    : "text-slate-500 hover:text-slate-800"
                }`}
              >
                Daftar Baru
              </button>
            </div>

            {/* Error & Success Messages */}
            {authError && (
              <div className="p-3 bg-red-50 border border-red-100 text-red-700 rounded-xl text-xs flex items-start gap-2 animate-in fade-in duration-200">
                <AlertTriangle className="h-4 w-4 shrink-0 text-red-500 mt-0.5" />
                <span>{authError}</span>
              </div>
            )}
            {authSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-xl text-xs flex items-start gap-2 animate-in fade-in duration-200">
                <CheckCircle className="h-4 w-4 shrink-0 text-emerald-600 mt-0.5" />
                <span>{authSuccess}</span>
              </div>
            )}

            {/* FORM CONTAINER */}
            {authMode === "login" ? (
              <form onSubmit={handleCustomLogin} className="space-y-4">
                <div className="text-center pb-1">
                  <h2 className="text-sm font-bold text-slate-800">Selamat Datang Kembali</h2>
                  <p className="text-[11px] text-slate-400">Masuk untuk merekam aktivitas pelatihan Anda</p>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Username / Gmail</label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                        <User className="h-4 w-4" />
                      </span>
                      <input
                        type="text"
                        required
                        placeholder="Contoh: nama@gmail.com atau username"
                        value={loginIdentifier}
                        onChange={(e) => setLoginIdentifier(e.target.value)}
                        className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Kata Sandi</label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                        <Lock className="h-4 w-4" />
                      </span>
                      <input
                        type="password"
                        required
                        placeholder="Masukkan kata sandi Anda"
                        value={loginPassword}
                        onChange={(e) => setLoginPassword(e.target.value)}
                        className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-emerald-800 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs cursor-pointer shadow-xs transition-colors flex items-center justify-center gap-1.5"
                >
                  <ShieldCheck className="h-4 w-4" />
                  <span>Masuk ke Portal</span>
                </button>
              </form>
            ) : (
              <form onSubmit={handleCustomRegister} className="space-y-4">
                <div className="text-center pb-1">
                  <h2 className="text-sm font-bold text-slate-800">Buat Akun Baru</h2>
                  <p className="text-[11px] text-slate-400">Daftarkan akun peserta Pendidikan Profesi Guru</p>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Username</label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                        <User className="h-4 w-4" />
                      </span>
                      <input
                        type="text"
                        required
                        placeholder="Masukkan username pilihan Anda"
                        value={regUsername}
                        onChange={(e) => setRegUsername(e.target.value)}
                        className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Gmail / Email</label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                        <Mail className="h-4 w-4" />
                      </span>
                      <input
                        type="email"
                        required
                        placeholder="Contoh: nama@gmail.com"
                        value={regEmail}
                        onChange={(e) => setRegEmail(e.target.value)}
                        className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Kata Sandi</label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                        <Lock className="h-4 w-4" />
                      </span>
                      <input
                        type="password"
                        required
                        placeholder="Minimal 5 karakter"
                        value={regPassword}
                        onChange={(e) => setRegPassword(e.target.value)}
                        className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-emerald-850 hover:bg-emerald-800 text-white font-bold rounded-xl text-xs cursor-pointer shadow-xs transition-colors"
                >
                  Daftar Akun Baru
                </button>
              </form>
            )}

            {/* Portal Description */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-left space-y-2">
              <div className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-900">
                <BookOpen className="h-4 w-4 text-emerald-700 shrink-0" />
                <span>Deskripsi Portal & Panduan</span>
              </div>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                Portal Kompetensi PPG ini berfungsi sebagai instrumen simulasi mandiri bagi calon guru Bahasa Arab. Media ini mengintegrasikan latihan penyusunan RPP, konsultasi tatap bahasa, serta evaluasi berbasis HOTS untuk menguji kesiapan uji kompetensi profesi guru.
              </p>
            </div>

            {/* Academic Footnote */}
            <div className="pt-3 border-t border-slate-100 text-center">
              <span className="text-[9px] text-slate-400 font-medium">
                Pilot Project Pendidikan Profesi Guru &bull; Kemenag RI
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col antialiased">
      
      {/* Top Warning Banner if API Key is missing */}
      {!checkingKey && !hasApiKey && (
        <div className="bg-amber-600 text-white py-3 px-6 text-center text-xs font-semibold flex items-center justify-center gap-2 shadow-sm shrink-0 transition-all">
          <AlertTriangle className="h-4 w-4 shrink-0 text-amber-100" />
          <span>
            PEMBERITAHUAN UTAMA: Gemini API Key (<strong>GEMINI_API_KEY</strong>) belum terpasang di Secrets. AI Generatif akan terhambat bekerja. Silakan buka panel <strong>Settings &gt; Secrets</strong> di kanan atas UI AI Studio untuk mendaftarkan API key Anda agar media pembelajaran interaktif ini terkoneksi secara penuh!
          </span>
        </div>
      )}

      {/* Elegant Header - Inspired by Professional Polish */}
      <header className="h-20 bg-white border-b border-slate-200 flex items-center justify-between px-4 sm:px-8 shrink-0 shadow-sm sticky top-0 z-40">
        <div className="flex items-center gap-4">
          {/* Emblem representing Arabic letter 'ع' */}
          <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center text-white font-bold text-xl shadow-sm hover:scale-105 transition-transform shrink-0">
            ع
          </div>
          <div>
            <h1 className="text-base sm:text-lg font-bold text-slate-800 leading-tight uppercase tracking-tight font-display">
              PPG Arabic Model
            </h1>
            <p className="text-xs text-slate-500 font-medium">Peningkatan Kompetensi Pedagogik & Profesional Calon Guru</p>
          </div>
        </div>

        {/* Right Nav Options & Timestamp */}
        <div className="flex items-center gap-4 sm:gap-6">
          <div className="hidden md:flex items-center gap-3">
            <Clock className="h-3.5 w-3.5 text-slate-400" />
            <span className="text-xs font-mono bg-slate-100 text-slate-600 px-2.5 py-1 rounded-md">{currentTime || "Menghubungkan..."}</span>
          </div>

          <div className="flex items-center gap-3 pl-4 border-l border-slate-200">
            <div className="text-right hidden sm:block">
              <p className="text-xs font-bold text-slate-800">{user.name}</p>
              <p className="text-[10px] text-slate-400 uppercase font-bold font-mono">
                {user.role === "admin" ? "Dosen Penguji" : "Mahasiswa PPG"}
              </p>
            </div>
            <button
              onClick={handleLogout}
              className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-800 text-[10px] font-bold rounded-lg cursor-pointer transition-colors border border-slate-200 uppercase"
              title="Keluar dari Portal"
            >
              Keluar
            </button>
          </div>
        </div>
      </header>

      {/* Main Professional Columns Layout */}
      <div className="flex-1 max-w-[1400px] w-full mx-auto p-4 sm:p-6 lg:p-8 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Sidebar: Curriculum Progress (Active & Interactive) */}
        <aside className={`${showLeftSidebar ? "lg:col-span-3" : "hidden"} bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col transition-all duration-300`}>
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest font-display">
              Modul Pelatihan PPG
            </h2>
            <button 
              onClick={() => setShowLeftSidebar(false)}
              className="text-slate-400 hover:text-rose-500 text-[10px] bg-slate-50 border border-slate-150 rounded px-1.5 py-0.5 font-bold cursor-pointer"
              title="Sembunyikan Jendela"
            >
              Tutup ✕
            </button>
          </div>
          
          <div className="p-3 flex flex-col gap-2">
            
            {/* Modul 1 -> Simulator */}
            <button
              id="sidebar-modul-1"
              onClick={() => setActiveTab("simulator")}
              className={`text-left p-3 rounded-xl border transition-all cursor-pointer ${
                activeTab === "simulator"
                  ? "bg-emerald-50 border-emerald-100 text-emerald-950 shadow-xs"
                  : "bg-transparent border-transparent hover:bg-slate-50 text-slate-700"
              }`}
            >
              <div className="flex justify-between items-start">
                <p className={`text-[10px] font-bold uppercase mb-1 ${
                  activeTab === "simulator" ? "text-emerald-600" : "text-slate-400"
                }`}>Modul 01 • Pedagogik</p>
                {hasSimulatorCompleted && (
                  <span className="text-[8px] bg-emerald-600 text-white font-extrabold px-1.5 py-0.2 rounded uppercase animate-pulse">Selesai ✓</span>
                )}
              </div>
              <p className="text-xs font-bold leading-tight">Simulasi Skenario Kasus Kelas</p>
              <div className="mt-2.5 h-1 w-full bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full transition-all duration-500" style={{ width: hasSimulatorCompleted ? "100%" : "30%" }}></div>
              </div>
            </button>

            {/* Modul 2 -> Lesson Generator */}
            <button
              id="sidebar-modul-2"
              onClick={() => setActiveTab("lesson")}
              className={`text-left p-3 rounded-xl border transition-all cursor-pointer ${
                activeTab === "lesson"
                  ? "bg-emerald-50 border-emerald-100 text-emerald-950 shadow-xs"
                  : "bg-transparent border-transparent hover:bg-slate-50 text-slate-700"
              }`}
            >
              <div className="flex justify-between items-start">
                <p className={`text-[10px] font-bold uppercase mb-1 ${
                  activeTab === "lesson" ? "text-emerald-600" : "text-slate-400"
                }`}>Modul 02 • Kurikulum</p>
                {hasLessonCompleted && (
                  <span className="text-[8px] bg-emerald-600 text-white font-extrabold px-1.5 py-0.2 rounded uppercase animate-pulse">Selesai ✓</span>
                )}
              </div>
              <p className="text-xs font-bold leading-tight">Penyusunan RPP & Modul Ajar</p>
              <div className="mt-2.5 h-1 w-full bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full transition-all duration-500" style={{ width: hasLessonCompleted ? "100%" : "40%" }}></div>
              </div>
            </button>

            {/* Modul 3 -> Tutor */}
            <button
              id="sidebar-modul-3"
              onClick={() => setActiveTab("tutor")}
              className={`text-left p-3 rounded-xl border transition-all cursor-pointer ${
                activeTab === "tutor"
                  ? "bg-emerald-50 border-emerald-100 text-emerald-950 shadow-xs"
                  : "bg-transparent border-transparent hover:bg-slate-50 text-slate-700"
              }`}
            >
              <div className="flex justify-between items-start">
                <p className={`text-[10px] font-bold uppercase mb-1 ${
                  activeTab === "tutor" ? "text-emerald-600" : "text-slate-400"
                }`}>Modul 03 • Bahasa Arab Murni</p>
                {hasTutorCompleted && (
                  <span className="text-[8px] bg-emerald-600 text-white font-extrabold px-1.5 py-0.2 rounded uppercase animate-pulse">Selesai ✓</span>
                )}
              </div>
              <p className="text-xs font-bold leading-tight">Asisten Al-Ustadz Nahwu & Balaghah</p>
              <div className="mt-2.5 h-1 w-full bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full transition-all duration-500" style={{ width: hasTutorCompleted ? "100%" : "20%" }}></div>
              </div>
            </button>

            {/* Modul 4 -> Quiz HOTS */}
            <button
              id="sidebar-modul-4"
              onClick={() => setActiveTab("quiz")}
              className={`text-left p-3 rounded-xl border transition-all cursor-pointer ${
                activeTab === "quiz"
                  ? "bg-emerald-50 border-emerald-100 text-emerald-950 shadow-xs"
                  : "bg-transparent border-transparent hover:bg-slate-50 text-slate-700"
              }`}
            >
              <div className="flex justify-between items-start">
                <p className={`text-[10px] font-bold uppercase mb-1 ${
                  activeTab === "quiz" ? "text-emerald-600" : "text-slate-400"
                }`}>Modul 04 • Pre-test</p>
                {hasQuizCompleted && (
                  <span className="text-[8px] bg-emerald-600 text-white font-extrabold px-1.5 py-0.2 rounded uppercase animate-pulse">Selesai ✓</span>
                )}
              </div>
              <p className="text-xs font-bold leading-tight">Uji Mandiri HOTS & Pre-test</p>
              <div className="mt-2.5 h-1 w-full bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full transition-all duration-500" style={{ width: hasQuizCompleted ? "100%" : "10%" }}></div>
              </div>
            </button>

            {/* Modul 5 -> Progress */}
            <button
              id="sidebar-modul-progress"
              onClick={() => setActiveTab("progress")}
              className={`text-left p-3 rounded-xl border transition-all cursor-pointer ${
                activeTab === "progress"
                  ? "bg-indigo-50 border-indigo-100 text-indigo-950 shadow-xs font-bold"
                  : "bg-transparent border-transparent hover:bg-slate-50 text-slate-700"
              }`}
            >
              <p className={`text-[10px] font-bold uppercase mb-1 ${
                activeTab === "progress" ? "text-indigo-600" : "text-slate-400"
              }`}>Modul 05 • Statistik</p>
              <p className="text-xs font-bold leading-tight">Progres Belajar & Pencapaian</p>
              <div className="mt-2.5 h-1 w-full bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-indigo-500 rounded-full transition-all duration-500" style={{ width: activeTab === "progress" ? "100%" : "60%" }}></div>
              </div>
            </button>

            {/* Admin Modul -> Evaluasi Penilaian (conditional render) */}
            {user?.role === "admin" && (
              <button
                id="sidebar-modul-admin"
                onClick={() => setActiveTab("admin")}
                className={`text-left p-3 rounded-xl border transition-all cursor-pointer ${
                  activeTab === "admin"
                    ? "bg-amber-950 border-amber-800 text-white shadow-xs font-bold"
                    : "bg-amber-50 hover:bg-amber-100/80 border-amber-200 text-amber-900"
                }`}
              >
                <p className="text-[10px] font-bold uppercase mb-1 text-amber-600">PANEL EVALUASI</p>
                <p className="text-xs font-bold leading-tight">Evaluasi & Penilaian Admin</p>
                <div className="mt-2.5 h-1 w-full bg-slate-100/20 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-500 rounded-full" style={{ width: "100%" }}></div>
                </div>
              </button>
            )}

          </div>

          <div className="p-4 bg-slate-50 rounded-b-2xl border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-slate-600">
            <span>Progress Pembelajaran</span>
            <span className="text-emerald-700 font-bold">
              {activeTab === "simulator" ? "20%" : activeTab === "lesson" ? "40%" : activeTab === "tutor" ? "60%" : activeTab === "quiz" ? "80%" : "100%"}
            </span>
          </div>
        </aside>

        {/* Central Workstation Container */}
        <section className={`${getWorkspaceSpan()} bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col overflow-hidden transition-all duration-300`}>
          
          {/* Header of workspace */}
          <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-700 uppercase tracking-widest font-display">
                <Sparkles className="h-3 w-3" /> Workspace Pelatihan PPG
              </div>
              <h2 className="text-lg font-bold text-slate-800 tracking-tight mt-0.5">
                {activeTab === "simulator" && "Simulasi Kasus Kelas Pedagogi"}
                {activeTab === "lesson" && "Modul Ajar & Rencana RPP"}
                {activeTab === "tutor" && "Al-Ustadz Konsultasi Bahasa"}
                {activeTab === "quiz" && "Uji Mandiri HOTS & Pre-test"}
                {activeTab === "admin" && "Panel Evaluasi Penilaian Admin"}
                {activeTab === "progress" && "Progres Belajar & Pencapaian"}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                {activeTab === "simulator" && "Menyelesaikan problematika riil pembelajaran Bahasa Arab di tingkat sekolah."}
                {activeTab === "lesson" && "Penyusunan RPP Kurikulum Merdeka otomatis dengan tuntunan subjek Bahasa Arab."}
                {activeTab === "tutor" && "Konsultasi interaktif seputar Ilmu Nahwu, Saraf, Balaghah, dan kefasihan kalam."}
                {activeTab === "quiz" && "Uji formatif berjenjang memprediksi kesiapan ujian kompetensi PPG nasional."}
                {activeTab === "admin" && "Dosen Penguji mengevaluasi, menilai kompetensi kependidikan, dan mencatatkan sertifikasi."}
                {activeTab === "progress" && "Pantau grafik statistik, akumulasi jam latihan, streak harian, dan medali sertifikasi PPG Anda."}
              </p>
            </div>
            
            {/* Quick action or banner stat -> collapsible window controls */}
            <div className="flex flex-wrap items-center gap-2 select-none">
              <button
                onClick={() => setShowLeftSidebar(!showLeftSidebar)}
                className={`px-2.5 py-1.5 text-[10px] font-bold rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer ${
                  showLeftSidebar 
                    ? "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200" 
                    : "bg-emerald-600 border-emerald-500 text-white hover:bg-emerald-700"
                }`}
                title="Tampilkan/Sembunyikan Modul Pelatihan PPG (Kiri)"
              >
                <PanelLeft className="h-3.5 w-3.5" />
                <span>{showLeftSidebar ? "Sembunyikan Modul" : "Tampilkan Modul"}</span>
              </button>

              <button
                onClick={() => setShowRightSidebar(!showRightSidebar)}
                className={`px-2.5 py-1.5 text-[10px] font-bold rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer ${
                  showRightSidebar 
                    ? "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200" 
                    : "bg-blue-600 border-blue-500 text-white hover:bg-blue-700"
                }`}
                title="Tampilkan/Sembunyikan Indikator Kompetensi (Kanan)"
              >
                <PanelRight className="h-3.5 w-3.5" />
                <span>{showRightSidebar ? "Sembunyikan Indikator" : "Tampilkan Indikator"}</span>
              </button>

              {(!showLeftSidebar && !showRightSidebar) && (
                <span className="text-[9px] bg-indigo-50 border border-indigo-100 text-indigo-800 font-extrabold px-2 py-1 rounded-md animate-pulse">
                  WORKSPACE MAKSIMAL (100% WIDED)
                </span>
              )}
            </div>
          </div>

          {/* Navigation Tab Bar integrated as a workspace utility tool */}
          <div className="bg-slate-50/70 border-b border-slate-100 px-2 flex gap-1 items-center overflow-x-auto scrollbar-none">
            <button
              id="tab-btn-simulator"
              type="button"
              onClick={() => setActiveTab("simulator")}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold border-b-2 cursor-pointer transition-all shrink-0 ${
                activeTab === "simulator"
                  ? "border-emerald-600 text-emerald-800 bg-white shadow-3xs"
                  : "border-transparent text-slate-500 hover:text-slate-800"
              }`}
            >
              <ShieldCheck className="h-3.5 w-3.5" />
              <span>Simulasi Kasus</span>
            </button>

            <button
              id="tab-btn-lesson"
              type="button"
              onClick={() => setActiveTab("lesson")}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold border-b-2 cursor-pointer transition-all shrink-0 ${
                activeTab === "lesson"
                  ? "border-emerald-600 text-emerald-800 bg-white shadow-3xs"
                  : "border-transparent text-slate-500 hover:text-slate-800"
              }`}
            >
              <FileText className="h-3.5 w-3.5" />
              <span>Penyusun RPP</span>
            </button>

            <button
              id="tab-btn-tutor"
              type="button"
              onClick={() => setActiveTab("tutor")}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold border-b-2 cursor-pointer transition-all shrink-0 ${
                activeTab === "tutor"
                  ? "border-emerald-600 text-emerald-800 bg-white shadow-3xs"
                  : "border-transparent text-slate-500 hover:text-slate-800"
              }`}
            >
              <MessageSquare className="h-3.5 w-3.5" />
              <span>Al-Ustadz</span>
            </button>

            <button
              id="tab-btn-quiz"
              type="button"
              onClick={() => setActiveTab("quiz")}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold border-b-2 cursor-pointer transition-all shrink-0 ${
                activeTab === "quiz"
                  ? "border-emerald-600 text-emerald-800 bg-white shadow-3xs"
                  : "border-transparent text-slate-500 hover:text-slate-800"
              }`}
            >
              <HelpCircle className="h-3.5 w-3.5" />
              <span>Uji Mandiri</span>
            </button>

            <button
              id="tab-btn-progress"
              type="button"
              onClick={() => setActiveTab("progress")}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold border-b-2 cursor-pointer transition-all shrink-0 ${
                activeTab === "progress"
                  ? "border-emerald-600 text-emerald-800 bg-white shadow-3xs"
                  : "border-transparent text-slate-500 hover:text-slate-800"
              }`}
            >
              <Award className="h-3.5 w-3.5" />
              <span>Progres Belajar</span>
            </button>

            {user?.role === "admin" && (
              <button
                id="tab-btn-admin"
                type="button"
                onClick={() => setActiveTab("admin")}
                className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold border-b-2 cursor-pointer transition-all shrink-0 ${
                  activeTab === "admin"
                    ? "border-amber-600 text-amber-800 bg-white shadow-3xs"
                    : "border-transparent text-slate-500 hover:text-slate-800"
                }`}
              >
                <UserCheck2 className="h-3.5 w-3.5 text-amber-600 animate-pulse" />
                <span>Evaluasi Admin</span>
              </button>
            )}
          </div>

          {/* Active Workstation Board */}
          <div className="p-4 sm:p-6 bg-white min-h-[500px]">
            {activeTab === "simulator" && (
              <PedagogicSimulator onScoreEarned={handleScoreEarned} />
            )}
            {activeTab === "lesson" && (
              <LessonPlanGenerator />
            )}
            {activeTab === "tutor" && (
              <TutorChat />
            )}
            {activeTab === "quiz" && (
              <HotsQuiz />
            )}
            {activeTab === "admin" && (
              <AdminPanel />
            )}
            {activeTab === "progress" && (
              <ProgressPanel />
            )}
          </div>

        </section>

        {/* Right Sidebar: Competency Score Cards */}
        <aside className={`${showRightSidebar ? "lg:col-span-3" : "hidden"} flex flex-col gap-6 transition-all duration-300`}>
          
          {/* Competency indicators mapped directly to component states */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-2">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest font-display">
                Indikator Kompetensi
              </h3>
              <button 
                onClick={() => setShowRightSidebar(false)}
                className="text-slate-400 hover:text-rose-500 text-[10px] bg-slate-50 border border-slate-150 rounded px-1.5 py-0.5 font-bold cursor-pointer"
                title="Sembunyikan Jendela"
              >
                Tutup ✕
              </button>
            </div>
            
            <div className="space-y-6">
              {/* Pedagogic competence mapping state pedagogicalScore */}
              <div>
                <div className="flex justify-between items-end mb-2">
                  <p className="text-xs font-bold text-slate-700">Skor Pedagogik</p>
                  <p className="text-lg font-black text-emerald-600 font-mono">
                    {pedagogicalScore}
                    <span className="text-[10px] text-slate-400 font-normal">/100</span>
                  </p>
                </div>
                <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-emerald-500 rounded-full transition-all duration-700" 
                    style={{ width: `${pedagogicalScore}%` }}
                  />
                </div>
                <span className="text-[9px] text-slate-400 block mt-1">Estimasi Kesiapan Pengelolaan Kelas</span>
              </div>

              {/* Professional competence mapping state professionalScore */}
              <div>
                <div className="flex justify-between items-end mb-2">
                  <p className="text-xs font-bold text-slate-700">Skor Profesional</p>
                  <p className="text-lg font-black text-blue-600 font-mono">
                    {professionalScore}
                    <span className="text-[10px] text-slate-400 font-normal">/100</span>
                  </p>
                </div>
                <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-blue-500 rounded-full transition-all duration-700" 
                    style={{ width: `${professionalScore}%` }}
                  />
                </div>
                <span className="text-[9px] text-slate-400 block mt-1">Penguasaan Ilmu Nahwu & Balaghah</span>
              </div>
            </div>

            {/* Utility stats summary to connect simulated results */}
            <div className="mt-5 pt-4 border-t border-slate-100 grid grid-cols-2 gap-2 text-center text-xs">
              <div className="p-2 bg-slate-50 rounded-lg">
                <span className="block text-[10px] text-slate-400 font-bold uppercase font-mono">KASUS</span>
                <span className="font-extrabold text-slate-800 font-mono">{caseSolvedCount}</span>
              </div>
              <div className="p-2 bg-slate-50 rounded-lg">
                <span className="block text-[10px] text-slate-400 font-bold uppercase font-mono">RPP</span>
                <span className="font-extrabold text-slate-800 font-mono">{rppGeneratedCount}</span>
              </div>
            </div>

            <div className="mt-4">
              <button
                id="btn-sidebar-reset"
                onClick={handleResetScores}
                className="w-full text-center text-xs text-rose-700 hover:text-rose-800 font-semibold flex items-center justify-center gap-1.5 bg-rose-50 hover:bg-rose-100/80 px-2 py-1.5 rounded-lg transition-all border border-rose-100 cursor-pointer"
              >
                <ListRestart className="h-3.5 w-3.5" />
                <span>Atur Ulang Latihan</span>
              </button>
            </div>
          </div>

          {/* Strategic Narrative - Inspired by Professional Polish */}
          <div className="bg-emerald-950 rounded-2xl p-5 text-white flex flex-col gap-4 shadow-md relative overflow-hidden">
            <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 h-32 w-32 rounded-full bg-white/5 blur-xl pointer-events-none" />
            
            <div>
              <p className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest font-display mb-1">Rangkuman Strategis</p>
              <p className="text-xs leading-relaxed opacity-90">
                Integrasi asisten cerdas dalam pembelajaran bahasa Arab meningkatkan efisiensi penyusunan materi sebesar 70% dan akurasi evaluasi formatif mahasiswa PPG.
              </p>
            </div>

            <div className="pt-3 border-t border-white/10 mt-auto">
              <div className="p-2.5 bg-white/10 rounded-xl border border-white/10 flex justify-between items-center text-xs">
                <div>
                  <p className="text-[9px] font-medium opacity-60">Sertifikasi Target</p>
                  <p className="font-bold">Sertifikasi Level 1</p>
                </div>
                <span className="text-[9px] bg-emerald-800 text-emerald-200 font-bold px-2 py-0.5 rounded">
                  AKTIF
                </span>
              </div>
            </div>
          </div>

        </aside>

      </div>

      {/* Footer Academic Citation */}
      <footer className="bg-slate-100 text-slate-500 py-6 border-t border-slate-200 text-center text-[10px] sm:text-xs">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="font-mono tracking-wide">
            Sistem Pengembangan Model Pembelajaran Bahasa Arab &copy; 2026 PPG LPTK
          </p>
          <div className="flex items-center gap-4 text-[10px] font-semibold text-slate-400">
            <span>Status Sistem: <span className="text-emerald-600 font-bold">Aktif</span></span>
            <span>Engine: <span className="text-blue-600 font-bold">Gemini-3.5-Flash</span></span>
          </div>
        </div>
      </footer>

    </div>
  );
}
