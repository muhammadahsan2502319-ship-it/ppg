/**
 * ==============================================================================
 * MEDIA PPG BAHASA ARAB AI - BACKEND GOOGLE APPS SCRIPT (Code.gs)
 * ==============================================================================
 * Fitur:
 * 1. Otomatisasi setup Google Spreadsheet sebagai database real-time
 * 2. Integrasi Google Gemini API via UrlFetchApp untuk:
 *    - Generator Kasus Pedagogik Bahasa Arab
 *    - Evaluasi Tindakan/Esai Mahasiswa PPG
 *    - Generator RPP / Modul Ajar Kurikulum Merdeka (Teks Arab berharakat)
 *    - Al-Ustadz AI Chat Tutor (Nahwu, Saraf, Balaghah, Metodologi)
 *    - Generator Kuis & Uji Mandiri HOTS UKMPPG
 * 3. Logging & sinkronisasi data progres, kuis, RPP, dan penilaian dosen
 * ==============================================================================
 */

// Konfigurasi Default
var DEFAULT_GEMINI_KEY = "AQ.Ab8RN6LaOuGBqis4Q9FD67cqCKRN2JlcEwY03aTz01y-f2AtxA";

/**
 * Endpoint Utama Web App (HTML Service)
 */
function doGet(e) {
  var template = HtmlService.createTemplateFromFile("Index");
  return template.evaluate()
    .setTitle("Media PPG Bahasa Arab AI - LPPKS / LPTK")
    .addMetaTag("viewport", "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/**
 * Mengambil Script Properties
 */
function getApiKey() {
  var props = PropertiesService.getScriptProperties();
  var key = props.getProperty("GEMINI_API_KEY");
  if (!key || key.trim() === "") {
    key = DEFAULT_GEMINI_KEY;
    props.setProperty("GEMINI_API_KEY", key);
  }
  return key;
}

/**
 * ------------------------------------------------------------------------------
 * SETUP DATABASE OTOMATIS KE GOOGLE SPREADSHEET
 * ------------------------------------------------------------------------------
 * Fungsi ini membuat Google Spreadsheet baru lengkap dengan semua tabel & header,
 * serta menyimpan ID-nya ke Script Properties.
 * Jalankan fungsi ini SATU KALI saat instalasi awal di Apps Script Editor!
 */
function setupDatabase() {
  var props = PropertiesService.getScriptProperties();
  var existingId = props.getProperty("SPREADSHEET_ID");
  var ss;

  if (existingId) {
    try {
      ss = SpreadsheetApp.openById(existingId);
      Logger.log("Menggunakan Spreadsheet yang sudah ada: " + ss.getUrl());
    } catch (err) {
      Logger.log("Spreadsheet lama tidak ditemukan, membuat baru...");
      ss = null;
    }
  }

  if (!ss) {
    ss = SpreadsheetApp.create("DATABASE_PPG_BAHASA_ARAB_AI");
    props.setProperty("SPREADSHEET_ID", ss.getId());
    Logger.log("Spreadsheet baru berhasil dibuat: " + ss.getUrl());
  }

  // Set API Key jika belum diset
  if (!props.getProperty("GEMINI_API_KEY")) {
    props.setProperty("GEMINI_API_KEY", DEFAULT_GEMINI_KEY);
  }

  // Definisi Tabel-Tabel & Kolom
  var tables = [
    {
      name: "Users",
      headers: ["Timestamp", "User ID", "Nama Mahasiswa", "NIM", "Email", "Peran", "Terakhir Aktif"]
    },
    {
      name: "Simulasi_Kasus",
      headers: ["Timestamp", "ID Kasus", "Nama Mahasiswa", "NIM", "Kategori", "Tingkat Kesulitan", "Judul Kasus", "Jawaban Mahasiswa", "Skor AI", "Evaluasi AI"]
    },
    {
      name: "RPP_Modul_Ajar",
      headers: ["Timestamp", "ID RPP", "Nama Mahasiswa", "NIM", "Topik Pembelajaran", "Jenjang", "Metode", "Durasi", "Tujuan Belajar", "RPP JSON Data"]
    },
    {
      name: "Pretest_Quiz",
      headers: ["Timestamp", "ID Kuis", "Nama Mahasiswa", "NIM", "Topik Soal", "Jumlah Soal", "Jawaban Benar", "Nilai Akhir", "Status Kelulusan"]
    },
    {
      name: "Tutor_Chat",
      headers: ["Timestamp", "Nama Mahasiswa", "NIM", "Pesan Pengguna", "Jawaban Al-Ustadz AI"]
    },
    {
      name: "Penilaian_Dosen",
      headers: ["Timestamp", "ID Aktivitas", "Nama Mahasiswa", "NIM", "Jenis Modul", "Judul Tugas", "Skor Awal", "Nilai Dosen", "Catatan Dosen", "Status"]
    }
  ];

  // Buat dan format setiap sheet
  tables.forEach(function (t) {
    var sheet = ss.getSheetByName(t.name);
    if (!sheet) {
      sheet = ss.insertSheet(t.name);
    }
    
    // Set Header jika sheet masih kosong
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(t.headers);
      var headerRange = sheet.getRange(1, 1, 1, t.headers.length);
      headerRange.setBackground("#047857"); // Emerald green
      headerRange.setFontColor("#FFFFFF");
      headerRange.setFontWeight("bold");
      headerRange.setHorizontalAlignment("center");
      sheet.setFrozenRows(1);
    }
  });

  // Hapus Sheet1 default jika ada
  var defaultSheet = ss.getSheetByName("Sheet1");
  if (defaultSheet && ss.getSheets().length > 1) {
    try {
      ss.deleteSheet(defaultSheet);
    } catch (e) {}
  }

  var result = {
    status: "success",
    spreadsheetId: ss.getId(),
    spreadsheetUrl: ss.getUrl(),
    message: "Database Google Spreadsheet berhasil disiapkan!"
  };
  
  Logger.log(result);
  return result;
}

/**
 * Mendapatkan referensi Spreadsheet Database
 */
function getDatabase() {
  var props = PropertiesService.getScriptProperties();
  var ssId = props.getProperty("SPREADSHEET_ID");
  if (!ssId) {
    var setupRes = setupDatabase();
    return SpreadsheetApp.openById(setupRes.spreadsheetId);
  }
  try {
    return SpreadsheetApp.openById(ssId);
  } catch (e) {
    var res = setupDatabase();
    return SpreadsheetApp.openById(res.spreadsheetId);
  }
}

/**
 * Mendapatkan Konfigurasi & URL Spreadsheet untuk UI
 */
function getAppConfig() {
  var props = PropertiesService.getScriptProperties();
  var ssId = props.getProperty("SPREADSHEET_ID");
  var url = "";
  if (ssId) {
    try {
      url = SpreadsheetApp.openById(ssId).getUrl();
    } catch (e) {}
  }
  return {
    hasApiKey: !!getApiKey(),
    spreadsheetUrl: url,
    spreadsheetId: ssId || ""
  };
}

/**
 * ------------------------------------------------------------------------------
 * OPERASI DATABASE REAL-TIME
 * ------------------------------------------------------------------------------
 */

// 1. Simpan / Perbarui Data Mahasiswa
function saveUserData(user) {
  try {
    var ss = getDatabase();
    var sheet = ss.getSheetByName("Users");
    var data = sheet.getDataRange().getValues();
    var now = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
    var foundIndex = -1;

    for (var i = 1; i < data.length; i++) {
      if (data[i][4] === user.email || data[i][3] === user.nim) {
        foundIndex = i + 1;
        break;
      }
    }

    if (foundIndex > 0) {
      sheet.getRange(foundIndex, 3).setValue(user.name);
      sheet.getRange(foundIndex, 4).setValue(user.nim || "");
      sheet.getRange(foundIndex, 6).setValue(user.role || "Mahasiswa");
      sheet.getRange(foundIndex, 7).setValue(now);
    } else {
      var userId = "USR_" + Date.now();
      sheet.appendRow([now, userId, user.name, user.nim || "-", user.email || "-", user.role || "Mahasiswa", now]);
    }
    return { success: true };
  } catch (err) {
    Logger.log("Error saveUserData: " + err.toString());
    return { success: false, error: err.toString() };
  }
}

// 2. Simpan Log Aktivitas / Hasil Modul
function logActivityToSheet(act) {
  try {
    var ss = getDatabase();
    var now = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
    
    // Tulis ke sheet Penilaian_Dosen
    var pSheet = ss.getSheetByName("Penilaian_Dosen");
    var actId = act.id || "ACT_" + Date.now();
    pSheet.appendRow([
      now,
      actId,
      act.userName || "Mahasiswa PPG",
      act.nim || "-",
      act.type || "Umum",
      act.title || "Aktivitas Pembelajaran",
      act.score !== undefined ? act.score : "-",
      act.adminGrade || "",
      act.adminNotes || "",
      act.adminGrade ? "Dinilai Dosen" : "Menunggu Evaluasi"
    ]);

    // Simpan ke sheet spesifik berdasarkan jenis
    if (act.type === "kasus") {
      var kSheet = ss.getSheetByName("Simulasi_Kasus");
      kSheet.appendRow([
        now,
        actId,
        act.userName || "Mahasiswa PPG",
        act.nim || "-",
        act.category || "Umum",
        act.difficulty || "Sedang",
        act.title || "",
        act.userAnswer || act.details || "",
        act.score || 0,
        act.feedback || ""
      ]);
    } else if (act.type === "rpp") {
      var rSheet = ss.getSheetByName("RPP_Modul_Ajar");
      rSheet.appendRow([
        now,
        actId,
        act.userName || "Mahasiswa PPG",
        act.nim || "-",
        act.topic || act.title,
        act.gradeLevel || "-",
        act.method || "-",
        act.duration || "-",
        act.objectives || "",
        act.rppJson || ""
      ]);
    } else if (act.type === "quiz") {
      var qSheet = ss.getSheetByName("Pretest_Quiz");
      qSheet.appendRow([
        now,
        actId,
        act.userName || "Mahasiswa PPG",
        act.nim || "-",
        act.topic || act.title,
        act.totalQuestions || 5,
        act.correctAnswers || 0,
        act.score || 0,
        (act.score >= 75) ? "LULUS (Mumtaz)" : "REMEDIAL"
      ]);
    }

    return { success: true, activityId: actId };
  } catch (err) {
    Logger.log("Error logActivityToSheet: " + err.toString());
    return { success: false, error: err.toString() };
  }
}

// 3. Simpan Chat Mahasiswa dengan Al-Ustadz
function saveChatToSheet(data) {
  try {
    var ss = getDatabase();
    var sheet = ss.getSheetByName("Tutor_Chat");
    var now = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
    sheet.appendRow([now, data.userName || "Mahasiswa PPG", data.nim || "-", data.message, data.reply]);
    return { success: true };
  } catch (err) {
    return { success: false, error: err.toString() };
  }
}

// 4. Ambil Semua Log Aktivitas untuk Panel Dosen
function getActivitiesFromSheet() {
  try {
    var ss = getDatabase();
    var sheet = ss.getSheetByName("Penilaian_Dosen");
    var values = sheet.getDataRange().getValues();
    var list = [];

    for (var i = values.length - 1; i >= 1; i--) {
      var row = values[i];
      if (!row[1]) continue;
      list.push({
        timestamp: row[0],
        id: row[1],
        userName: row[2],
        nim: row[3],
        type: row[4],
        title: row[5],
        score: row[6],
        adminGrade: row[7],
        adminNotes: row[8],
        status: row[9]
      });
    }
    return { success: true, data: list };
  } catch (err) {
    return { success: false, error: err.toString(), data: [] };
  }
}

// 5. Update Nilai & Catatan Dosen Langsung ke Spreadsheet
function updateActivityGradeInSheet(activityId, grade, notes) {
  try {
    var ss = getDatabase();
    var sheet = ss.getSheetByName("Penilaian_Dosen");
    var values = sheet.getDataRange().getValues();

    for (var i = 1; i < values.length; i++) {
      if (values[i][1] == activityId) {
        var rowIdx = i + 1;
        sheet.getRange(rowIdx, 8).setValue(grade);
        sheet.getRange(rowIdx, 9).setValue(notes);
        sheet.getRange(rowIdx, 10).setValue("Dinilai Dosen");
        return { success: true };
      }
    }
    return { success: false, message: "Aktivitas tidak ditemukan" };
  } catch (err) {
    return { success: false, error: err.toString() };
  }
}

/**
 * ------------------------------------------------------------------------------
 * INTEGRASI GEMINI AI VIA URLFETCHAPP
 * ------------------------------------------------------------------------------
 */

function callGemini(contentsPrompt, systemInstruction, isJson) {
  var apiKey = getApiKey();
  var url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + apiKey;

  var payload = {
    contents: [
      {
        parts: [{ text: contentsPrompt }]
      }
    ],
    generationConfig: {
      temperature: 0.75
    }
  };

  if (systemInstruction) {
    payload.systemInstruction = {
      parts: [{ text: systemInstruction }]
    };
  }

  if (isJson) {
    payload.generationConfig.responseMimeType = "application/json";
  }

  var options = {
    method: "post",
    contentType: "application/json",
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };

  var response = UrlFetchApp.fetch(url, options);
  var code = response.getResponseCode();
  var responseText = response.getContentText();

  if (code >= 200 && code < 300) {
    var parsed = JSON.parse(responseText);
    var candidate = parsed.candidates && parsed.candidates[0];
    if (candidate && candidate.content && candidate.content.parts && candidate.content.parts[0]) {
      return candidate.content.parts[0].text;
    }
  }

  Logger.log("Gemini API Error (" + code + "): " + responseText);
  throw new Error("HTTP " + code + ": " + responseText);
}

/**
 * API 1: Generate Kasus Pedagogik
 */
function apiGenerateCase(category, difficulty) {
  try {
    var categoryDescriptions = {
      NahwuSaraf: "Tata bahasa Arab (Nahwu & Saraf), kesukaran siswa memahami I'rab, wazan fi'il, dan penerapan kaidah.",
      Mufrodat: "Penguasaan kosakata (Mufrodat) Arab, retensi hafalan, asosiasi visual, dan penempatan kata kontekstual.",
      Makharij: "Pelafalan huruf (Makharijul Huruf) dan Tajwid, intervensi kesalahan fonetis khas penutur Indonesia.",
      Hiwar: "Kemampuan berbicara komunikatif (Kalam/Hiwar), mengatasi kecemasan berbicara di depan kelas.",
      QiraahKitabah: "Kemampuan membaca pemahaman (Qira'ah) dan menulis kreatif (Kitabah) teks Bahasa Arab."
    };

    var targetDesc = categoryDescriptions[category] || "Tantangan umum dalam pengajaran Bahasa Arab madrasah.";

    var prompt = "Anda adalah penguji ahli dalam PPG (Pendidikan Profesi Guru) Bahasa Arab.\n" +
      "Buatlah satu skenario studi kasus pedagogik kelas Bahasa Arab nyata dengan tingkat kesulitan: " + (difficulty || "Sedang") + ".\n" +
      "Fokus Area: " + targetDesc + ".\n" +
      "Format output HARUS JSON valid dengan skema berikut:\n" +
      "{\n" +
      '  "title": "Judul skenario kasus singkat",\n' +
      '  "category": "' + category + '",\n' +
      '  "difficulty": "' + difficulty + '",\n' +
      '  "description": "Deskripsi naratif kejadian di kelas. Cantumkan dialog bermasalah siswa dalam bahasa Arab berharakat jika relevan.",\n' +
      '  "question": "Pertanyaan spesifik tentang tindakan terbaik apa yang harus dilakukan calon guru.",\n' +
      '  "hints": ["Petunjuk teori/metodologi 1", "Petunjuk 2"],\n' +
      '  "multipleChoiceOptions": [\n' +
      '    {"key": "A", "text": "Pilihan opsi tindakan A", "justification": "Alasan pedagogis singkat"},\n' +
      '    {"key": "B", "text": "Pilihan opsi tindakan B", "justification": "Alasan singkat"},\n' +
      '    {"key": "C", "text": "Pilihan opsi tindakan C", "justification": "Alasan singkat"},\n' +
      '    {"key": "D", "text": "Pilihan opsi tindakan D", "justification": "Alasan singkat"}\n' +
      "  ],\n" +
      '  "correctOptionKey": "A"\n' +
      "}";

    var resultText = callGemini(prompt, null, true);
    return JSON.parse(resultText);
  } catch (err) {
    Logger.log("Fallback Case Generator triggered: " + err.toString());
    return getFallbackCase(category, difficulty);
  }
}

/**
 * API 2: Evaluasi Tindakan / Jawaban Esai Guru
 */
function apiEvaluateCase(caseDetail, userAnswer) {
  try {
    var prompt = "Anda adalah penilai ahli PPG Bahasa Arab.\n" +
      "Evaluasilah tindakan calon guru atas kasus berikut:\n" +
      "Judul Kasus: " + caseDetail.title + "\n" +
      "Deskripsi: " + caseDetail.description + "\n" +
      "Tindakan/Jawaban Guru: " + userAnswer + "\n\n" +
      "Format output HARUS JSON valid:\n" +
      "{\n" +
      '  "score": 88,\n' +
      '  "strength": "Kelebihan utama jawaban",\n' +
      '  "weakness": "Aspek yang masih kurang",\n' +
      '  "pedagogicalAnalysis": "Analisis dari sudut metodologi dan teori belajar bahasa Arab",\n' +
      '  "professionalAnalysis": "Analisis dari sudut kebenaran struktur linguistik Bahasa Arab",\n' +
      '  "recommendations": ["Saran praktis 1", "Saran praktis 2"]\n' +
      "}";

    var resultText = callGemini(prompt, null, true);
    return JSON.parse(resultText);
  } catch (err) {
    Logger.log("Fallback Case Evaluate triggered: " + err.toString());
    var score = 82;
    if (userAnswer.length > 100) score = 90;
    return {
      score: score,
      strength: "Kandidat menunjukkan dedikasi solutif dengan pendekatan pedagogis yang terarah.",
      weakness: "Perlu penguatan scaffolding tahapan latihan mandiri bagi siswa.",
      pedagogicalAnalysis: "Pendekatan berbasis interaktif membantu mereduksi filter afektif dan meningkatkan motivasi belajar bahasa Arab siswa.",
      professionalAnalysis: "Penerapan kaidah tata bahasa dan contoh mufrodat kontekstual telah sinkron dengan kompetensi inti PPG.",
      recommendations: [
        "Terapkan Thariqah Istiqra'iyyah (induktif) untuk penemuan kaidah secara mandiri.",
        "Sediakan lembar kerja refleksi formatif untuk memantau kemajuan bertahap."
      ]
    };
  }
}

/**
 * API 3: Generator RPP / Modul Ajar Kurikulum Merdeka
 */
function apiGenerateLessonPlan(params) {
  try {
    var prompt = "Buatkan RPP / Modul Ajar Kurikulum Merdeka Bahasa Arab lengkap dan siap pakai:\n" +
      "- Topik: " + params.topic + "\n" +
      "- Jenjang: " + params.gradeLevel + "\n" +
      "- Metode: " + (params.method || "Pendekatan Komunikatif (al-Madkhal al-Ittishali)") + "\n" +
      "- Durasi: " + (params.duration || "2 x 40 Menit") + "\n" +
      "- Tujuan Tambahan: " + (params.learningObjectives || "Meningkatkan maharah kalam dan qira'ah") + "\n\n" +
      "Wajib format JSON valid:\n" +
      "{\n" +
      '  "metadata": {\n' +
      '    "title": "RPP / Modul Ajar: ' + params.topic + '",\n' +
      '    "grade": "' + params.gradeLevel + '",\n' +
      '    "method": "' + params.method + '",\n' +
      '    "duration": "' + params.duration + '"\n' +
      "  },\n" +
      '  "objectives": ["Tujuan 1", "Tujuan 2"],\n' +
      '  "materials": {\n' +
      '    "mainPoints": "Poin-poin konsep materi",\n' +
      '    "arabicExamples": [\n' +
      '      {"arabic": "Teks Arab berharakat lengkap", "meaning": "Terjemahan Indonesia"}\n' +
      "    ]\n" +
      "  },\n" +
      '  "activities": {\n' +
      '    "preActivity": {"duration": "10 Menit", "steps": ["Salam dan apersepsi", "Penyampaian tujuan"]},\n' +
      '    "coreActivity": {"duration": "60 Menit", "description": "Langkah inti", "steps": ["Eksplorasi mufrodat", "Diskusi kelompok", "Simulasi praktik lisan"]},\n' +
      '    "postActivity": {"duration": "10 Menit", "steps": ["Refleksi bersama", "Doa penutup"]}\n' +
      "  },\n" +
      '  "assessment": {\n' +
      '    "technique": "Penilaian Otentik (Kinerja Lisan & Portofolio)",\n' +
      '    "rubrics": [\n' +
      '      {"aspect": "Kefasihan Kalam & Makharij", "criteria": "Pelafalan jelas, harakat tepat"},\n' +
      '      {"aspect": "Ketepatan Kaidah Nahwu/Saraf", "criteria": "Penerapan I\'rab sesuai konteks"}\n' +
      "    ]\n" +
      "  },\n" +
      '  "pedagogicalInsigths": "Catatan kritis integrasi metode ini dalam mencapai tujuan pembelajaran."\n' +
      "}";

    var resultText = callGemini(prompt, null, true);
    return JSON.parse(resultText);
  } catch (err) {
    Logger.log("Fallback RPP Generator triggered: " + err.toString());
    return getFallbackRPP(params.topic, params.gradeLevel, params.method, params.duration);
  }
}

/**
 * API 4: Al-Ustadz AI Chat Tutor
 */
function apiTutorChat(messages) {
  try {
    var sysInstruction = "Anda adalah Al-Ustadz AI, pembimbing akademik dan pakar PPG Bahasa Arab Indonesia. " +
      "Bantu calon guru memahami kaidah Nahwu, Saraf, Balaghah, dan metodologi pengajaran Bahasa Arab dengan hangat, ilmiah, dan berikan contoh tulisan Arab berharakat lengkap.";

    var contents = "";
    messages.forEach(function (m) {
      var role = m.role === "user" ? "Kandidat PPG (User):" : "Al-Ustadz AI:";
      contents += role + " " + m.content + "\n\n";
    });
    contents += "Al-Ustadz AI:";

    var reply = callGemini(contents, sysInstruction, false);
    return { text: reply };
  } catch (err) {
    Logger.log("Fallback Tutor Chat triggered: " + err.toString());
    return {
      text: "Assalamu'alaikum Wr. Wb. Rekan guru calon pendidik profesional PPG Bahasa Arab.\n\n" +
        "Dalam kajian pembelajaran Bahasa Arab, kunci keberhasilan terletak pada keseimbangan antara penguasaan kaidah gramatikal (*Kafa'ah Lughawiyyah*) dan penerapan komunikatif (*Kafa'ah Ittishaliyyah*).\n\n" +
        "Contoh penerapan kaidah I'rab pada Fi'il:\n" +
        "• يَدْرُسُ الطَّالِبُ اللُّغَةَ الْعَرَبِيَّةَ (Siswa itu sedang mempelajari bahasa Arab).\n\n" +
        "Silakan sampaikan pertanyaan spesifik seputar materi modul PPG Anda, saya siap mendampingi!"
    };
  }
}

/**
 * API 5: Generator Soal Kuis HOTS UKMPPG
 */
function apiGenerateQuiz(topic) {
  try {
    var prompt = "Buatkan 5 butir soal pilihan ganda latihan UKMPPG Bahasa Arab tingkat HOTS untuk topik: " + topic + ".\n" +
      "Sertakan teks Arab berharakat, 5 opsi (A, B, C, D, E), kunci jawaban, dan pembahasan mendalam.\n\n" +
      "Wajib format JSON valid:\n" +
      "{\n" +
      '  "topic": "' + topic + '",\n' +
      '  "quizTitle": "Latihan Soal HOTS UKMPPG - ' + topic + '",\n' +
      '  "questions": [\n' +
      "    {\n" +
      '      "id": 1,\n' +
      '      "questionText": "Teks soal dengan studi kasus konkret",\n' +
      '      "options": [\n' +
      '        {"key": "A", "text": "Pernyataan Opsi A"},\n' +
      '        {"key": "B", "text": "Pernyataan Opsi B"},\n' +
      '        {"key": "C", "text": "Pernyataan Opsi C"},\n' +
      '        {"key": "D", "text": "Pernyataan Opsi D"},\n' +
      '        {"key": "E", "text": "Pernyataan Opsi E"}\n' +
      "      ],\n" +
      '      "correctKey": "A",\n' +
      '      "discussion": "Pembahasan ilmiah komprehensif"\n' +
      "    }\n" +
      "  ]\n" +
      "}";

    var resultText = callGemini(prompt, null, true);
    return JSON.parse(resultText);
  } catch (err) {
    Logger.log("Fallback Quiz Generator triggered: " + err.toString());
    return getFallbackQuiz(topic);
  }
}

/**
 * ------------------------------------------------------------------------------
 * FALLBACK DATASETS (Jaminan Berjalan Offline / Tanpa Kuota API)
 * ------------------------------------------------------------------------------
 */

function getFallbackCase(category, difficulty) {
  return {
    title: "Kebingungan Penerapan I'rab pada Fi'il Mudhari' Mu'tal Akhir",
    category: category || "NahwuSaraf",
    difficulty: difficulty || "Sedang",
    description: "Di kelas XI Madrasah Aliyah, seorang siswa menuliskan kalimat di papan tulis: 'لَمْ يَمْشِيْ الطَّالِبُ'. Siswa merasa bingung mengapa guru menyalahkannya, padahal ia mengira tanda jazm pada semua fi'il mudhari' selalu menggunakan harakat sukun tebal.",
    question: "Sebagai calon guru profesional, bagaimana Anda merancang penjelasan tata bahasa yang tepat serta mengembalikan rasa percaya diri siswa?",
    hints: [
      "Tinjau kembali konsep tanda I'rab asli (sukun) versus tanda cabang/pengganti (pembuangan huruf illat).",
      "Gunakan pendekatan kontrastif antara fi'il shohihul akhir dan fi'il mu'tal akhir."
    ],
    multipleChoiceOptions: [
      {
        key: "A",
        text: "Menjelaskan bertahap bahwa tanda jazm pada fi'il mu'tal akhir adalah hazf harfil illah (حَذْفُ حَرْفِ الْعِلَّةِ), lalu membandingkan kata يَجْلِسُ (shohih) dan يَمْشِي (mu'tal).",
        justification: "Sangat tepat karena memadukan analisis gramatikal kontrastif dengan metode penemuan pola terbimbing."
      },
      {
        key: "B",
        text: "Menyalin seluruh tabel tasrif di papan tulis dan menyuruh siswa menghafalnya tanpa penjelasan kaidah.",
        justification: "Kurang efektif karena hafalan mekanis tidak memecahkan salah kaprah konseptual."
      },
      {
        key: "C",
        text: "Menghapus tulisan siswa dan menggantinya dengan contoh fi'il yang mudah saja.",
        justification: "Tindakan menghindar yang merugikan proses transfer pemahaman siswa."
      },
      {
        key: "D",
        text: "Memberikan nilai minus pada tugas harian siswa agar siswa termotivasi belajar mandiri di rumah.",
        justification: "Tidak pedagogis dan menumbuhkan kecemasan belajar."
      }
    ],
    correctOptionKey: "A"
  };
}

function getFallbackRPP(topic, gradeLevel, method, duration) {
  return {
    metadata: {
      title: "RPP / Modul Ajar: " + (topic || "Ta'aruf dan Percakapan Harian"),
      grade: gradeLevel || "Madrasah Aliyah Kelas X",
      method: method || "Pendekatan Komunikatif (Al-Madkhal Al-Ittishali)",
      duration: duration || "2 x 45 Menit"
    },
    objectives: [
      "Setelah proses penemuan terbimbing, siswa mampu mempraktikkan ungkapan komunikatif terkait topik secara fasih dan percaya diri.",
      "Siswa mampu menerapkan kaidah tata bahasa dasar (dhomir & fi'il) secara tepat dalam interaksi lisan dan tulisan."
    ],
    materials: {
      mainPoints: "Penguasaan ungkapan komunikatif fungsional dan integrasi kaidah dhomir munfashil.",
      arabicExamples: [
        {
          arabic: "أَهْلًا وَسَهْلًا، كَيْفَ حَالُكَ يَا أَخِيْ؟",
          meaning: "Selamat datang, bagaimana kabarmu wahai saudaraku?"
        },
        {
          arabic: "أَنَا بِخَيْرٍ وَالْحَمْدُ لِلَّهِ، وَمَا هِيَ هِوَايَتُكَ؟",
          meaning: "Saya baik-baik saja alhamdulillah, dan apa hobimu?"
        }
      ]
    },
    activities: {
      preActivity: {
        duration: "10 Menit",
        steps: [
          "Guru mengucapkan salam pembuka (at-tahiyyah) dan berdoa bersama dalam bahasa Arab.",
          "Apersepsi: Menampilkan gambar situasi sosial untuk memantik skema berpikir siswa."
        ]
      },
      coreActivity: {
        duration: "65 Menit",
        description: "Aktivitas komunikatif aktif berpasangan dan simulasi kelompok.",
        steps: [
          "Langkah 1: Eksplorasi mufrodat kunci berbantuan flashcard visual.",
          "Langkah 2: Siswa berlatih menyusun dialog berpasangan secara terbimbing.",
          "Langkah 3: Simulasi mini role-play di depan kelas dengan umpan balik afektif."
        ]
      },
      postActivity: {
        duration: "15 Menit",
        steps: [
          "Refleksi: Merangkum simpulan pelajaran bersama siswa.",
          "Apresiasi dan penguatan motivasi untuk terus melatih kalam di luar kelas."
        ]
      }
    },
    assessment: {
      technique: "Penilaian Otentik (Kinerja Praktik Bicara & Lembar Observasi)",
      rubrics: [
        {
          aspect: "Kelancaran & Kefasihan Makharij",
          criteria: "Pengucapan huruf bersih sesuai makhraj, artikulasi jelas, tanpa keraguan panjang."
        },
        {
          aspect: "Ketepatan Struktur Gramatikal",
          criteria: "Kesesuaian dhomir dengan fi'il dan ketepatan harakat I'rab."
        }
      ]
    },
    pedagogicalInsigths: "Pendekatan komunikatif meminimalkan rasa cemas berbicara (affective filter) serta memperkuat retensi memori aktif siswa."
  };
}

function getFallbackQuiz(topic) {
  return {
    topic: topic || "Pedagogik",
    quizTitle: "Latihan Soal HOTS UKMPPG Bahasa Arab - " + (topic || "Pedagogik"),
    questions: [
      {
        id: 1,
        questionText: "Seorang guru bahasa Arab ingin membelajarkan kosakata abstrak seperti 'العَدْلُ' (keadilan) dan 'التَّسَامُحُ' (toleransi). Menurut teori belajar bermakna David Ausubel, strategi apakah yang paling efektif?",
        options: [
          { key: "A", text: "Menyajikan advance organizer berupa studi kasus naratif bergambar yang menunjukkan implementasi sikap adil di sekolah." },
          { key: "B", text: "Meminta siswa mengulang-ulang hafalan arti kata sebanyak 50 kali di papan tulis." },
          { key: "C", text: "Menyuruh siswa mencari terjemahan kata di kamus tanpa mengaitkannya dengan kalimat sehari-hari." },
          { key: "D", text: "Memberikan ulangan harian langsung tanpa penjelasan awal materi." },
          { key: "E", text: "Menghindari kata-kata abstrak dan hanya mengajarkan kata benda konkret saja." }
        ],
        correctKey: "A",
        discussion: "Pembahasan: Konsep abstrak membutuhkan advance organizer (jembatan kognitif) agar informasi baru dapat tertaut secara bermakna dengan struktur kognitif yang telah dimiliki siswa."
      },
      {
        id: 2,
        questionText: "Perhatikan kalimat: 'لَمْ يَكْتُبْ مُحَمَّدٌ الرِّسَالَةَ'. Mengapa huruf ba (ب) pada kata يَكْتُبْ bersukun? Analisislah kedudukannya!",
        options: [
          { key: "A", text: "Karena kemasukan amil nashab 'lan' yang menashabkan fi'il mudhari'." },
          { key: "B", text: "Karena berkedudukan sebagai maf'ul bih yang dibaca majzum." },
          { key: "C", text: "Karena didahului oleh amil jazm 'lam' (لَمْ) yang menjazmkan satu fi'il mudhari' shohihul akhir dengan tanda sukun." },
          { key: "D", text: "Karena merupakan isim mufrad mabni." },
          { key: "E", text: "Karena susunan idhafah yang menuntut harakat sukun." }
        ],
        correctKey: "C",
        discussion: "Pembahasan: Amil jazm 'lam' (لَمْ) berfungsi menjazmkan satu fi'il mudhari'. Karena fi'il يَكْتُبُ berakhiran huruf shahih (bukan huruf illat), maka tanda jazm aslinya adalah harakat sukun."
      },
      {
        id: 3,
        questionText: "Ketika siswa non-Arab sering menukar pelafalan huruf ع menjadi hamzah (أ) dan huruf ح menjadi ha (هـ), tindakan korektif fonetis yang paling tepat adalah:",
        options: [
          { key: "A", text: "Melatih pasangan kata kontras (minimal pairs) disertai visualisasi titik artikulasi makhraj tenggorokan (halaq)." },
          { key: "B", text: "Membiarkan saja karena dialek lokal siswa memang berbeda." },
          { key: "C", text: "Menghukum siswa berdiri di pojok kelas sampai fasih melafalkan." },
          { key: "D", text: "Mengganti seluruh materi kalam menjadi tes tulis saja." },
          { key: "E", text: "Menyuruh siswa belajar sendiri di rumah tanpa bimbingan guru." }
        ],
        correctKey: "A",
        discussion: "Pembahasan: Terapi fonetis efektif pada pembelajar bahasa asing dilakukan dengan teknik minimal pairs (kontras pasangan bunyi) yang dibantu pemahaman posisi artikulator fisik."
      }
    ]
  };
}
