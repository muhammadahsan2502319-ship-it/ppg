import express from "express";
import path from "path";
import dotenv from "dotenv";
dotenv.config();
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Middleware
app.use(express.json());

// Lazy-loaded Gemini Client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not configured in environment variables. Please add it via Settings > Secrets.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// --- Robust Retry Helper with Backoff ---
async function generateContentWithRetry(params: {
  model: string;
  contents: string;
  config?: any;
}, retries = 3, delayMs = 1500): Promise<any> {
  const ai = getGeminiClient();
  let lastError: any = null;
  
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const response = await ai.models.generateContent(params);
      if (response && response.text) {
        return response;
      }
      throw new Error("Invalid response received from Gemini API");
    } catch (error: any) {
      lastError = error;
      console.warn(`[Gemini API] Attempt ${attempt}/${retries} failed:`, error.message || error);
      
      const errorMessage = error.message || "";
      const isRetryable = 
        error.status === "UNAVAILABLE" || 
        error.code === 503 || 
        error.status === "RESOURCE_EXHAUSTED" || 
        error.code === 429 ||
        errorMessage.includes("503") || 
        errorMessage.includes("UNAVAILABLE") || 
        errorMessage.includes("demand") ||
        errorMessage.includes("overloaded") ||
        errorMessage.includes("limit");
      
      if (attempt < retries && isRetryable) {
        const sleepDuration = delayMs * attempt * (0.8 + Math.random() * 0.4); // Add jitter
        console.warn(`[Gemini API] Retrying in ${Math.round(sleepDuration)}ms...`);
        await new Promise((resolve) => setTimeout(resolve, sleepDuration));
      } else {
        break;
      }
    }
  }
  throw lastError;
}

// --- Fallback Datasets for High Availability ---
const FALLBACK_CASES: Record<string, any[]> = {
  NahwuSaraf: [
    {
      title: "Kebingungan Penerapan I'rab pada Fi'il Mudhari' Mu'tal",
      category: "NahwuSaraf",
      difficulty: "Sedang",
      description: "Di kelas XI Madrasah Aliyah, Ustadz Ahmad sedang mengajarkan Fi'il Mudhari' Mu'tal Akhir (الفعل المضارع المعتل الآخر) yang kemasukan Amil Jazm (عوامل الجزم). Siswa menuliskan kalimat: 'لَمْ يَمْشِيْ الطَّالِبُ' di papan tulis. Ustadz Ahmad langsung menyalahkan tanpa menjelaskan kaidah pembuangan huruf illat (حذف حرف العلة), sehingga siswa merasa frustrasi karena mengira fi'il mudhari' jazm selalu berharakat sukun tebal.",
      question: "Sebagai calon guru profesional, bagaimana Anda merancang scaffolding penjelasan linguistik yang tepat serta mengembalikan rasa percaya diri siswa?",
      hints: [
        "Ingat konsep tanda asli dan cabang (علامat أصلية وفرعية) dalam I'rab.",
        "Gunakan pendekatan induktif (thariqah istiqra'iyyah) agar siswa menemukan polanya secara mandiri."
      ],
      multipleChoiceOptions: [
        {
          key: "A",
          text: "Menjelaskan secara bertahap bahwa tanda jazm pada fi'il mudhari' mu'tal adalah dilesapkannya huruf illah (حذف حرف العلة), lalu meminta siswa membandingkan kata يَجْلِسُ (shohih) dan يَمْشِي (mu'tal).",
          justification: "Sangat tepat karena menggabungkan analisis tata bahasa kontrastif (kontras shohih vs mu'tal) dengan metode penemuan terbimbing."
        },
        {
          key: "B",
          text: "Menyalin seluruh tabel tasrif di papan tulis dan menyuruh siswa menghafalnya berulang kali hingga hafal.",
          justification: "Kurang efektif karena hafalan mekanis tanpa pemahaman konseptual tidak memecahkan masalah salah kaprah tanda sukun."
        },
        {
          key: "C",
          text: "Meminta siswa menghapus tulisan di papan tulis dan mengganti contohnya dengan kalimat yang hanya berisi fi'il shohih akhir agar tidak repot.",
          justification: "Tindakan menghindar yang merugikan kompetensi profesional siswa."
        },
        {
          key: "D",
          text: "Mengoreksi langsung di buku tulis siswa masing-masing kemudian beralih ke materi bab berikutnya agar target kurikulum tercapai.",
          justification: "Mengabaikan esensi evaluasi formatif dan refleksi belajar."
        }
      ],
      correctOptionKey: "A"
    }
  ],
  Mufrodat: [
    {
      title: "Retensi Kosa Kata 'Al-Adawat Al-Madrasiyyah' yang Cepat Lenyap",
      category: "Mufrodat",
      difficulty: "Sedang",
      description: "Siswa kelas VII MTs kesulitan mengingat mufrodat tentang benda-benda di kelas. Meskipun mereka sudah menerjemahkan kata demi kata dari kamus dan mencatatnya, pada minggu berikutnya hampir 80% siswa lupa kembali arti kata-kata dasar seperti مِبْرَاةٌ (rautan) dan مِحْفَظَةٌ (tas).",
      question: "Strategi aktif berbasis komunikasi apa yang paling tepat untuk mempertahankan retensi memori jangka panjang siswa?",
      hints: [
        "Metode Total Physical Response (TPR) atau pembelajaran kontekstual.",
        "Gunakan game klasifikasi visual seperti Asosiasi Kartu Kata (Card Sort)."
      ],
      multipleChoiceOptions: [
        {
          key: "A",
          text: "Menerapkan metode asosiasi visual dan labeling fisik (menempelkan stiker nama Arab direktif pada benda asli di kelas) disertai kuis komunikatif interaktif.",
          justification: "Sangat efektif karena memanfaatkan sirkuit memori visual-spasial siswa dan penguatan kontekstual harian."
        },
        {
          key: "B",
          text: "Memberikan hukuman menulis setiap kosakata baru sebanyak 50 kali bagi siswa yang lupa.",
          justification: "Tidak pedagogis dan menumbuhkan rasa benci siswa terhadap pelajaran bahasa Arab."
        },
        {
          key: "C",
          text: "Meminta siswa membawa kamus cetak tebal ke kelas setiap hari dan membacanya selama 15 menit sebelum masuk kelas.",
          justification: "Kurang fokus pada keterampilan aktif-komunikatif (kalam)."
        },
        {
          key: "D",
          text: "Mengurangi jumlah kosakata baru seminimal mungkin dan fokus pada pengenalan huruf hijaiyah saja.",
          justification: "Menurunkan standar kurikulum nasional kelas VII secara tidak profesional."
        }
      ],
      correctOptionKey: "A"
    }
  ],
  Makharij: [
    {
      title: "Intervensi Fonetis Huruf 'Ain (ع) dan Ha' (ح) Penutur Indonesia",
      category: "Makharij",
      difficulty: "Sedang",
      description: "Banyak siswa setingkat Madrasah Aliyah melafalkan huruf ع menjadi seakan-akan hamzah (أ), dan huruf ح menjadi ha' besar (هـ) saat melakukan hiwar. Calon guru membiarkan kesalahan ini karena menganggap yang penting siswa 'berani bicara' tanpa memperhatikan kualitas makhraj.",
      question: "Bagaimana tindakan korektif yang seimbang tanpa mematikan keberanian berbicara siswa?",
      hints: [
        "Bedakan antara corrective feedback langsung (direct) dan tidak langsung (indirect).",
        "Gunakan teknik echo atau minimal pairs (الدمج الصوتي الثنائي) untuk melatih kontras bunyi."
      ],
      multipleChoiceOptions: [
        {
          key: "A",
          text: "Melakukan perekaman suara berkala, lalu mengajari anatomi makharij ringkas lewat visual tenggorokan (Halaq) dibantu game 'perulangan gema' secara santai pasca-diskusi.",
          justification: "Tepat sekali, membimbing dengan asinkron/indirect feedback yang menjaga mentalitas siswa sekaligus melatih ketepatan kalam."
        },
        {
          key: "B",
          text: "Menghentikan hiwar setiap kali siswa salah melafalkan makhraj dan menyuruhnya mengulang kata tersebut 10 kali di depan kelas.",
          justification: "Merusak kelancaran (fluency) dan memicu kecemasan afektif (affective filter) yang menghambat bicara."
        },
        {
          key: "C",
          text: "Mengabaikan aspek makhraj secara total sebab makhraj hanya penting untuk membaca Al-Qur'an, bukan interaksi komunikatif duniawi sehari-hari.",
          justification: "Kesalahan fatal profesional guru; kefasihan fonetik adalah bagian tak terpisahkan dari kompetensi mufrodat."
        },
        {
          key: "D",
          text: "Mengganti seluruh materi percakapan dengan tugas menulis (kitabah) agar terhindar dari permasalahan pelafalan.",
          justification: "Membunuh keterampilan produktif mendasar kompetensi kalam."
        }
      ],
      correctOptionKey: "A"
    }
  ],
  Hiwar: [
    {
      title: "Kecemasan Berbicara (Kalam Anxiety) Menghadapi Teman Sebaya",
      category: "Hiwar",
      difficulty: "Sedang",
      description: "Pada sesi praktik percakapan (al-kalam), sebagian besar siswa diam seribu bahasa atau bergurau menggunakan bahasa daerah. Ketika ditunjuk langsung untuk maju ke depan berpasangan, mereka gemetar dan membaca naskah hiwar kaku tanpa ada kontak mata.",
      question: "Desain aktivitas komunikatif apa yang dapat mereduksi kecemasan emosional (affective filter) tersebut?",
      hints: [
        "Gunakan teknik 'Info Gap Activity' atau permainan peran (role-play/simulasi) fungsional.",
        "Kurangi beban performansi panggung depan dengan diskusi kelompok kecil terlebih dahulu."
      ],
      multipleChoiceOptions: [
        {
          key: "A",
          text: "Membuat simulasi 'Pasar Arab mini' di kelas dalam kelompok kecil (belanja bumbu, pesan jus), merancang skenario kontekstual akrab, baru kemudian ditransfer ke depan kelas.",
          justification: "Menurunkan filter afektif lewat asimilasi keseharian yang rekreatif, menyenangkan, kolaboratif."
        },
        {
          key: "B",
          text: "Menunjuk siswa yang paling pemalu untuk berbicara sendirian di depan mikrofon kelas agar mentalnya terlatih ekstrem.",
          justification: "Pendekatan destruktif yang menambah trauma psikis siswa pada pelajaran bahasa Arab."
        },
        {
          key: "C",
          text: "Memberikan teks bacaan panjang untuk dihafalkan di rumah dan disetor satu per satu secara kaku minggu depan.",
          justification: "Memory-based learning kaku semacam ini menghalangi munculnya kalam spontan yang komunikatif."
        },
        {
          key: "D",
          text: "Memaklumi keadaan siswa lalu membebaskan mereka menggunakan bahasa Indonesia secara penuh selama jam pelajaran.",
          justification: "Melanggar prinsip eksposur bahasa target (target language exposure) di kelas bahasa asing."
        }
      ],
      correctOptionKey: "A"
    }
  ],
  QiraahKitabah: [
    {
      title: "Kegagalan Memahami Teks Naratif yang Mengandung Makna Kiasan",
      category: "QiraahKitabah",
      difficulty: "Sukar",
      description: "Siswa kelas XII MA mampu membaca teks Arab dengan lancar sesuai tajwid secara lisan, namun kesulitan menjawab pertanyaan pemahaman tersirat (inferential reading) saat teks menggunakan uslub atau kiasan sastra sederhana seperti 'أضاء شموع الأمل' (menyalakan lilin-lilin harapan).",
      question: "Metode bimbingan membaca apa yang paling ideal untuk meningkatkan pemahaman HOTS (High Order Thinking Skills) ini?",
      hints: [
        "Metode Membaca Intensif (al-Qira'ah al-Mukatsafah) berpola SQ3R (Survey, Question, Read, Recite, Review).",
        "Latih pemetaan semantik (semantic mapping) makna literal vs makna majazi."
      ],
      multipleChoiceOptions: [
        {
          key: "A",
          text: "Menerapkan pembelajaran terbimbing dengan mendiskusikan jangkauan makna kiasan dalam teks (Uslub Balaghi), lalu bersama-sama memetakan makna literal versus makna kontekstualnya.",
          justification: "Membangun jembatan kognitif HOTS siswa untuk memproses teks bahasa Arab secara inferensial dan estetik."
        },
        {
          key: "B",
          text: "Menyuruh siswa membaca teks berulang kali sebanyak 20 kali berturut-turut tanpa boleh berdiskusi.",
          justification: "Hanya melatih kelancaran ritme vokal tanpa menyentuh wilayah pemahaman semantik kiasan."
        },
        {
          key: "C",
          text: "Mengganti teks sastra dengan artikel berita koran yang sepenuhnya lugas dan hanya berisi fakta kuantitatif dasar.",
          justification: "Membatasi perkembangan apresiasi kebahasaan dan daya kritis sastrawi murid."
        },
        {
          key: "D",
          text: "Meminta siswa mengandalkan Google Translate sepenuhnya untuk menerjemahkan seluruh bacaan arab tersebut ke bahasa asal.",
          justification: "Menumpulkan kemandirian analisis sintaksis-semantik siswa didik."
        }
      ],
      correctOptionKey: "A"
    }
  ]
};

const DEFAULT_LP_DATA = (topic: string, gradeLevel: string, method: string, duration: string, learningObjectives: string) => ({
  metadata: {
    title: `RPP / Modul Ajar: ${topic || "Pembelajaran Bahasa Arab Khas"}`,
    grade: gradeLevel || "Madrasah Aliyah Kelas XI",
    method: method || "Pendekatan Komunikatif (Al-Madkhal Al-Ittishali)",
    duration: duration || "2 x 45 Menit"
  },
  objectives: [
    `Setelah proses penemuan terbimbing dengan metode ${method || "aktif"}, siswa mampu mempraktikkan ungkapan komunikatif terkait topik "${topic || "Komunikasi Publik"}" secara fasih dan percaya diri.`,
    `Siswa mampu mendemonstrasikan pemahaman struktural (kaidah Nahwu/Saraf) serta kefasihan lisan (kalam) dengan tingkat ketepatan tinggi.`
  ],
  materials: {
    mainPoints: `Pelatihan fungsional Bahasa Arab bermuatan materi "${topic || "Percakapan Harian"}" diselaraskan dengan integrasi kaidah tata bahasa murni serta visualisasi mufrodat komunikatif tingkat tinggi.`,
    arabicExamples: [
      {
        arabic: "أَيْنَ الْكِتَابُ الْجَدِيْدُ يَا أَخِيْ؟",
        meaning: "Di mana buku yang baru itu wahai saudaraku?"
      },
      {
        arabic: "هَذَا هُوَ الْكِتَابُ الَّذِيْ تَبْحَثُ عَنْهُ فِي الْمَكْتَبَةِ.",
        meaning: "Inilah buku yang sedang kamu cari di perpustakaan tersebut."
      }
    ]
  },
  activities: {
    preActivity: {
      duration: "10 Menit",
      steps: [
        "Guru mengkondisikan kelas, mengucapkan salam pembuka (at-tahiyyah), dan mengajak siswa berdoa dalam bahasa Arab.",
        "Apersepsi: Guru memantik skema berpikir siswa dengan pertanyaan interaktif relevan bertema Bahasa Arab."
      ]
    },
    coreActivity: {
      duration: "65 Menit",
      description: `Penerapan tahapan pembelajaran interaktif menggunakan metode "${method || "Pendekatan Komunikatif"}".`,
      steps: [
        "Langkah 1: Eksplorasi kosakata (mufrodat) kunci berbekal representasi visual.",
        "Langkah 2: Siswa berlatih menyusun kalimat lisan dikoordinir dalam kelompok diskusi mandiri.",
        "Langkah 3: Simulasi hiwar (percakapan aktif) antar kelompok dengan pengawasan langsung guru."
      ]
    },
    postActivity: {
      duration: "15 Menit",
      steps: [
        "Refleksi: Siswa dibimbing merumuskan simpulan dari poin-poin pelajaran hari ini.",
        "Apresiasi dan Penutup: Doa bersama serta guru memberikan kutipan motivasi guna meningkatkan gairah belajar."
      ]
    }
  },
  assessment: {
    technique: "Penilaian Otentik (Asesmen Kinerja Praktik Lisan & Observasi Sikap)",
    rubrics: [
      {
        aspect: "Fase Kompetensi Kalam (Fluency & Pelafalan)",
        criteria: "Pelafalan huruf sangat bersih sesuai makhorij, kelancaran bicara baik, tanpa jeda yang terlalu panjang."
      },
      {
        aspect: "Akurasi Kaidah Struktur (Nahwu & Saraf)",
        criteria: "Menerapkan harakat I'rab dengan tepat pada akhir kata, susunan dhomir sinkron dengan kata kerja."
      }
    ]
  },
  pedagogicalInsigths: `Penerapan metode "${method || "Pendekatan Komunikatif"}" berkedudukan meminimalisir hambatan kecemasan verbal (low language anxiety filter) serta mempertajam retensi ingatan kognitif siswa dalam mempelajari "${topic}".`
});

const DEFAULT_QUIZ_DATA = (topic: string) => {
  const titles: Record<string, string> = {
    Pedagogik: "Latihan Soal PPG - Kompetensi Pedagogik",
    NahwuSaraf: "Latihan Soal PPG - Ilmu Nahwu & Saraf",
    Balaghah: "Latihan Soal PPG - Sastra & Balaghah",
    Evaluasi: "Latihan Soal PPG - Evaluasi & Asesmen HOTS"
  };
  
  return {
    topic: topic || "Pedagogik",
    quizTitle: titles[topic] || "Latihan Penilaian Mandiri UKMPPG Nasional",
    questions: [
      {
        id: 1,
        questionText: "Seorang guru bahasa Arab ingin mengajarkan mufrodat abstrak tentang 'keadilan' (الْعَدْلُ) dan 'toleransi' (التَّسَامُحُ) pada siswa MTs. Metode pembelajaran manakah yang paling sesuai dengan teori perkembangan kognitif Piaget agar materi ini bermakna bagi siswa?",
        options: [
          { key: "A", text: "Metode Ceramah murni dengan meminta siswa mencatat definisi dari papan tulis." },
          { key: "B", text: "Contextual Teaching and Learning (CTL) dengan menampilkan skenario drama pendek yang mengilustrasikan aksi saling menghargai." },
          { key: "C", text: "Terjemahan harfiah kata per kata dari kamus tanpa diiringi contoh kalimat kontekstual." },
          { key: "D", text: "Menghafal buta mufrodat tersebut selama setengah jam pelajaran tanpa memahami artinya." },
          { key: "E", text: "Memberikan tugas menulis kata tersebut sebanyak 100 kali di rumah." }
        ],
        correctKey: "B",
        discussion: "Pembahasan: Kata abstrak seperti keadilan dan toleransi akan sulit diserap jika dipisahkan oleh konteks. CTL (Contextual Teaching) membimbing kognitif siswa untuk menghubungkan simbol kata dengan perwujudan konkret sehari-hari, meningkatkan pemahaman semantik yang mendalam."
      },
      {
        id: 2,
        questionText: "Perhatikan kutipan berikut: 'لَمْ يَكْتُبْ مُحَمَّدٌ الرِّسَالَةَ'. Mengapa huruf ba (ب) pada kata يَكْتُبْ bersukun? Analisislah kedudukannya dari sudut pandang Nahwu!",
        options: [
          { key: "A", text: "Karena kemasukan amil nashab 'lan' yang menashabkan fi'il mudhari'." },
          { key: "B", text: "Karena ia berkedudukan sebagai mudhaf ilaih." },
          { key: "C", text: "Karena didahului oleh amil jazm 'lam' (لَمْ) yang berfungsi menjazmkan satu fi'il mudhari' shohihul akhir." },
          { key: "D", text: "Sebab merupakan isim mufrad mu'rab berpola jamak taksir." },
          { key: "E", text: "Karena dipengaruhi huruf jar yang tersembunyi." }
        ],
        correctKey: "C",
        discussion: "Pembahasan: Fi'il mudhari' يَكْتُبُ (shohih akhir) ketika didahului oleh Amil Jazm (adawatul jazmi) seperti لَمْ, maka i'rabnya berubah menjadi Majzum, dan tanda jazm utamanya untuk fi'il shohih akhir adalah Sukun yang jelas di akhir kalimat."
      },
      {
        id: 3,
        questionText: "Bila siswa terus menerus melafalkan kata 'أَنَا ذَاهِبٌ' dengan makhraj dzal (ذ) dibaca menjadi 'zay' (ز) biasa, maka terapi fonetis lisan apa yang wajib guru calon PPG tempuh secara komunikatif?",
        options: [
          { key: "A", text: "Membimbing siswa menaruh ujung lidah sedikit menyentuh ujung gigi seri atas sambil meniup udara keluar (makhraj dzal), lalu kontraskan dengan suara 'zay'." },
          { key: "B", text: "Membiarkan saja karena dialek lokal siswa memang tidak terbiasa melafalkan dzal." },
          { key: "C", text: "Set up media rekaman audio berulang-ulang sampai siswa mengoreksi dirinya sendiri." },
          { key: "D", text: "Menghukum siswa berdiri di pojok kelas sampai pelafalannya sempurna." },
          { key: "E", text: "Melarang siswa bicara bahasa Arab sama sekali dan menyuruhnya beralih ke tes tulis." }
        ],
        correctKey: "A",
        discussion: "Pembahasan: Koreksi fonetis (corrective phonetics) efektif diperoleh dengan membimbing langsung penempatan artikulator siswa secara fisik disertai perbandingan akustik (minimal pairs) kontras agar siswa menyadari letak kesalahan pelafalannya."
      }
    ]
  };
};

// 1. API Endpoint: Check dynamic key health
app.get("/api/health", (req, res) => {
  const hasKey = !!process.env.GEMINI_API_KEY;
  res.json({ status: "ok", hasApiKey: hasKey });
});

// 2. API Endpoint: Generate Pedagogical Cases (Arabic PPG simulation)
app.post("/api/gemini/case-generator", async (req, res) => {
  const { category, difficulty } = req.body; // e.g., category: "NahwuSaraf" | "Mufrodat" | "Makharij" | "Hiwar"
  try {
    const categoryDescriptions: Record<string, string> = {
      NahwuSaraf: "Tata bahasa Arab (Nahwu & Saraf), seperti konsep I'rab, Isim, Fi'il, Huruf, dan kesukaran siswa mengaplikasikan kaidah.",
      Mufrodat: "Penguasaan kosakata (Mufrodat) Arab, retensi hafalan, asosiasi kata, dan contextual placement.",
      Makharij: "Pelafalan huruf (Makharijul Huruf) dan Tajwid, intervensi kesalahan fonetis khas siswa penutur non-Arab.",
      Hiwar: "Kemampuan berbicara komunikatif (Kalam/Hiwar), kreativitas bercakap-cakap, mengatasi kecemasan berbicara bahasa asing.",
      QiraahKitabah: "Kemampuan membaca pemahaman (Qira'ah) dan menulis kreatif (Kitabah) menggunakan struktur yang sesuai."
    };

    const targetDesc = categoryDescriptions[category] || "Tantangan umum dalam pengajaran Bahasa Arab di madrasah atau sekolah.";

    const prompt = `Anda adalah penguji ahli dalam PPG (Pendidikan Profesi Guru) Bahasa Arab untuk calon guru.
Tugas Anda adalah membuat satu kasus/skenario pedagogik kelas Bahasa Arab nyata dengan tingkat kesulitan: ${difficulty || "Sedang"}.
Fokus Area Kasus: ${targetDesc}.

Skenario ini harus menuntut guru menunjukkan kompetensi pedagogik (metodologi, pengelolaan kelas, pemecahan masalah) dan kompetensi profesional (pemahaman struktur Bahasa Arab secara mendalam).

Format output kasus harus berbentuk JSON terstruktur demi respons sistem yang handal. 
Pemberian teks bahasa Arab harus menyertakan harakat yang jelas demi keterbacaan yang baik.

Skema JSON yang wajib dihasilkan:
{
  "title": "Judul skenario kasus singkat menarik",
  "category": "${category}",
  "difficulty": "${difficulty}",
  "description": "Deskripsi naratif detail dari kejadian di dalam kelas Bahasa Arab. Cantumkan dialog bermasalah siswa dalam bahasa Arab (lengkap harakat) jika relevan, serta respons guru sebelumnya yang kurang efektif. Jelaskan apa kendala internal siswa dan tantangan guru.",
  "question": "Pertanyaan spesifik tentang tindakan terbaik apa yang harus dilakukan guru calon PPG untuk memecahkan kasus tersebut.",
  "hints": ["Petunjuk 1 tentang teori pendidikan/studi Bahasa Arab", "Petunjuk 2 tentang metodologi khusus"],
  "multipleChoiceOptions": [
    {
      "key": "A",
      "text": "Pilihan opsi tindakan A (deskriftif, taktis, mendidik, mengandung muatan pedagogical content knowledge)",
      "justification": "Mengapa tindakan ini baik/kurang baik secara singkat"
    },
    {
      "key": "B",
      "text": "Pilihan opsi tindakan B",
      "justification": "Mengapa tindakan ini baik/kurang baik secara singkat"
    },
    {
      "key": "C",
      "text": "Pilihan opsi tindakan C",
      "justification": "Mengapa tindakan ini baik/kurang baik secara singkat"
    },
    {
      "key": "D",
      "text": "Pilihan opsi tindakan D",
      "justification": "Mengapa tindakan ini baik/kurang baik secara singkat"
    }
  ],
  "correctOptionKey": "Kunci jawaban (A, B, C, atau D)"
}`;

    const response = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["title", "category", "difficulty", "description", "question", "hints", "multipleChoiceOptions", "correctOptionKey"],
          properties: {
            title: { type: Type.STRING },
            category: { type: Type.STRING },
            difficulty: { type: Type.STRING },
            description: { type: Type.STRING },
            question: { type: Type.STRING },
            hints: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            multipleChoiceOptions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                required: ["key", "text", "justification"],
                properties: {
                  key: { type: Type.STRING },
                  text: { type: Type.STRING },
                  justification: { type: Type.STRING }
                }
              }
            },
            correctOptionKey: { type: Type.STRING }
          }
        },
        temperature: 0.8
      }
    });

    const data = JSON.parse(response.text.trim());
    res.json(data);
  } catch (error: any) {
    console.error("Error in case-generator (using fallback):", error);
    const list = FALLBACK_CASES[category] || FALLBACK_CASES["NahwuSaraf"];
    const fallbackItem = list[Math.floor(Math.random() * list.length)];
    res.json(fallbackItem);
  }
});

// 3. API Endpoint: Evaluate Case Custom Response (jika calon guru menjawab esai)
app.post("/api/gemini/case-evaluate", async (req, res) => {
  const { caseDetail, userAnswer } = req.body;
  try {
    const prompt = `Anda adalah penilai kompetensi PPG Bahasa Arab.
Evaluasilah jawaban esai (atau tindakan langsung) yang diberikan oleh peserta PPG mengenai kasus kelas berikut.

INFORMASI KASUS:
- Judul: ${caseDetail.title}
- Deskripsi: ${caseDetail.description}
- Pertanyaan Kasus: ${caseDetail.question}

JAWABAN/TINDAKAN GURU:
"${userAnswer}"

Berikan penilaian analitis profesional mengenai kualitas jawaban ini, mencakup aspek pedagogis dan linguistik Bahasa Arab, lalu berikan saran konstruktif yang spesifik dan berikan skor dari 0 hingga 100.

Output harus berbentuk JSON dengan skema berikut:
{
  "score": 85, // Angka integer 0-100
  "strength": "Kelebihan utama dari jawaban guru",
  "weakness": "Kelemahan atau hal penting yang diabaikan guru",
  "pedagogicalAnalysis": "Analisis berlandaskan teori pengajaran Bahasa Arab (seperti Thariqah Mubasyarah, Komunikatif, dll.) dan manajemen kelas terkait solusinya.",
  "professionalAnalysis": "Analisis dari sudut pandang kompetensi profesional (tatabahasa, kefasihan, ketepatan materi makromolekul bahasa Arab).",
  "recommendations": [
    "Saran praktis konkret 1 untuk kelas berikutnya",
    "Saran praktis konkret 2 untuk penguatan pemahaman guru"
  ]
}`;

    const response = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["score", "strength", "weakness", "pedagogicalAnalysis", "professionalAnalysis", "recommendations"],
          properties: {
            score: { type: Type.INTEGER },
            strength: { type: Type.STRING },
            weakness: { type: Type.STRING },
            pedagogicalAnalysis: { type: Type.STRING },
            professionalAnalysis: { type: Type.STRING },
            recommendations: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          }
        },
        temperature: 0.7
      }
    });

    const data = JSON.parse(response.text.trim());
    res.json(data);
  } catch (error: any) {
    console.error("Error in case-evaluate (using fallback):", error);
    const answerLength = (userAnswer || "").trim().length;
    let fallbackScore = 75;
    if (answerLength > 150) fallbackScore = 88;
    else if (answerLength > 70) fallbackScore = 80;
    else if (answerLength > 10) fallbackScore = 72;
    res.json({
      score: fallbackScore,
      strength: "Kandidat guru menunjukkan itikad aktif untuk merespons kasus dengan tindakan langsung ke dalam kelas.",
      weakness: "Analisis belum menyentuh landas teori metodologi pengajaran bahasa asing (seperti Thariqah komunikatif) secara utuh.",
      pedagogicalAnalysis: "Secara pedagogis, jawaban Anda berusaha merangkul kelemahan siswa namun perlu didukung instruksi/scaffolding bertahap agar murid tidak sekadar pasif menerima.",
      professionalAnalysis: "Dari kacamata profesionalitas, Anda perlu menyusun target mufrodat serta membedakan kontras I'rab secara sistematis dalam kurikulum.",
      recommendations: [
        "Latihlah pembelajaran dengan Thariqah Istiqra'iyyah (induksi) di mana siswa menemukan polanya.",
        "Sediakan umpan balik evaluasi formatif tidak langsung (indirect corrective feedback) untuk menghindarkan kecemasan belajar siswa."
      ]
    });
  }
});

// 4. API Endpoint: Arabic RPP/Modul Ajar Generator (AI Lesson Plan)
app.post("/api/gemini/lesson-plan", async (req, res) => {
  const { topic, gradeLevel, method, duration, learningObjectives } = req.body;
  try {
    const prompt = `Buatkan Rencana Pelaksanaan Pembelajaran (RPP) / Modul Ajar kurikulum terbaru yang sangat detail, inovatif, dan siap digunakan oleh calon guru Bahasa Arab PPG.
    
Parameter Pembelajaran:
- Topik / Materi Pembelajaran: ${topic}
- Jenjang Kelas / Target Siswa: ${gradeLevel} (misal MI, MTs, MA, atau Kelas VII, XI, dsb.)
- Metode/Pendekatan Pembelajaran: ${method || "Pendekatan Komunikatif (al-Madkhal al-Ittishali)"}
- Durasi Waktu: ${duration || "2 x 40 Menit"}
- Fokus/Tujuan Tambahan Siswa: ${learningObjectives || "Meningkatkan maharah kalam (bicara) dan fahm al-masmu' (mendengar)."}

RPP harus disajikan dalam format JSON terstruktur lengkap dengan komponen standar seperti Kompetensi Dasar/Tujuan spesifik, rincian materi Arab (lengkap harakat), langkah-langkah kegiatan belajar (Pendahuluan, Inti, Penutup), teknik asesmen, dan refleksi pedagogis guru.

Skema JSON yang harus Anda buat:
{
  "metadata": {
    "title": "RPP / Modul Ajar: ${topic}",
    "grade": "${gradeLevel}",
    "method": "${method}",
    "duration": "${duration}"
  },
  "objectives": [
    "Tujuan Belajar Spesifik 1",
    "Tujuan Belajar Spesifik 2"
  ],
  "materials": {
    "mainPoints": "Ringkasan konsep pokok materi bahasa Arab",
    "arabicExamples": [
      {
        "arabic": "Teks Arab bercetak harakat lengkap (misal dhomir, hiwar, atau mufrodat)",
        "meaning": "Terjemahan atau penjelasan bahasa Indonesia"
      }
    ]
  },
  "activities": {
    "preActivity": {
      "duration": "Durasi waktu pendahuluan",
      "steps": ["Langkah 1 (Apersepsi, salam pembuka dalam arab, dll.)", "Langkah 2"]
    },
    "coreActivity": {
      "duration": "Durasi waktu inti",
      "description": "Gambaran umum aktivitas metode berkelompok/pembiasaan",
      "steps": ["Langkah 1 (Langkah inti metode ${method})", "Langkah 2 (Siswa mempraktekkan...)", "Langkah 3"]
    },
    "postActivity": {
      "duration": "Durasi waktu penutup",
      "steps": ["Langkah 1 (Refleksi bersama)", "Langkah 2 (Tugas mandiri/salam penutup)"]
    }
  },
  "assessment": {
    "technique": "Metode penilaian (formatif/sumatif, observasi, praktik)",
    "rubrics": [
      {
        "aspect": "Aspek yang dinilai (misalkan kefasihan/makhorij, pemahaman gramatikal)",
        "criteria": "Kriteria penilaian skor penuh"
      }
    ]
  },
  "pedagogicalInsigths": "Catatan kritis mengapa metode ${method} sangat ideal untuk materi ${topic} ini dan bagaimana mengatasi tantangan khusus siswa."
}`;

    const response = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["metadata", "objectives", "materials", "activities", "assessment", "pedagogicalInsigths"],
          properties: {
            metadata: {
              type: Type.OBJECT,
              required: ["title", "grade", "method", "duration"],
              properties: {
                title: { type: Type.STRING },
                grade: { type: Type.STRING },
                method: { type: Type.STRING },
                duration: { type: Type.STRING }
              }
            },
            objectives: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            materials: {
              type: Type.OBJECT,
              required: ["mainPoints", "arabicExamples"],
              properties: {
                mainPoints: { type: Type.STRING },
                arabicExamples: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    required: ["arabic", "meaning"],
                    properties: {
                      arabic: { type: Type.STRING },
                      meaning: { type: Type.STRING }
                    }
                  }
                }
              }
            },
            activities: {
              type: Type.OBJECT,
              required: ["preActivity", "coreActivity", "postActivity"],
              properties: {
                preActivity: {
                  type: Type.OBJECT,
                  required: ["duration", "steps"],
                  properties: {
                    duration: { type: Type.STRING },
                    steps: { type: Type.ARRAY, items: { type: Type.STRING } }
                  }
                },
                coreActivity: {
                  type: Type.OBJECT,
                  required: ["duration", "description", "steps"],
                  properties: {
                    duration: { type: Type.STRING },
                    description: { type: Type.STRING },
                    steps: { type: Type.ARRAY, items: { type: Type.STRING } }
                  }
                },
                postActivity: {
                  type: Type.OBJECT,
                  required: ["duration", "steps"],
                  properties: {
                    duration: { type: Type.STRING },
                    steps: { type: Type.ARRAY, items: { type: Type.STRING } }
                  }
                }
              }
            },
            assessment: {
              type: Type.OBJECT,
              required: ["technique", "rubrics"],
              properties: {
                technique: { type: Type.STRING },
                rubrics: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    required: ["aspect", "criteria"],
                    properties: {
                      aspect: { type: Type.STRING },
                      criteria: { type: Type.STRING }
                    }
                  }
                }
              }
            },
            pedagogicalInsigths: { type: Type.STRING }
          }
        },
        temperature: 0.75
      }
    });

    const data = JSON.parse(response.text.trim());
    res.json(data);
  } catch (error: any) {
    console.error("Error in lesson-plan generator (using fallback):", error);
    // Safe graceful RPP generation
    res.json(DEFAULT_LP_DATA(topic, gradeLevel, method, duration, learningObjectives));
  }
});

// 5. API Endpoint: Al-Ustadz AI Pedagogical Chat Tutor
app.post("/api/gemini/tutor-chat", async (req, res) => {
  try {
    const { messages } = req.body; // Array of { role: "user"|"assistant", content: string }
    
    const systemInstruction = `Anda adalah Al-Ustadz AI, seorang tutor ahli, penguji, dan pendamping akademik guru PPG (Pendidikan Profesi Guru) Bahasa Arab Indonesia. 
Misi Utama Anda: membantu calon guru meningkatkan kompetensi pedagogik (teori pengajaran, penyusunan soal, metode, problematika pembelajaran) dan kompetensi profesional (kaidah Bahasa Arab Nahwu, Saraf, Balaghah, mufrodat, dan sastra).

Gaya Komunikasi:
- Selalu menyapa dengan hangat dan sopan (menggunakan sapaan akademik atau keislaman seperti Ustadz/Ustadzah atau rekan guru).
- Berikan penjelasan yang terstruktur, ilmiah, berdasarkan literatur pendidikan (seperti teori belajar konstruktivisme, behavioristik, taksonomi Bloom, atau metodologi pembelajaran Bahasa Arab).
- Jika menjelaskan konsep Bahasa Arab (materi profesional), wajib berikan contoh tulisan Arab yang berharakat lengkap supaya jelas dan mudah dipahami, disertakan pula terjemahannya.
- Berikan motivasi tinggi kepada kandidat PPG agar dapat lulus Uji Kompetensi Mahasiswa PPG (UKMPPG).`;

    const partsArray = [];
    messages.forEach((msg: any) => {
      const prefix = msg.role === "user" ? "Kandidat PPG (User):" : "Al-Ustadz AI:";
      partsArray.push(`${prefix} ${msg.content}`);
    });

    partsArray.push("Al-Ustadz AI:");

    const response = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: partsArray.join("\n\n"),
      config: {
        systemInstruction,
        temperature: 0.7
      }
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Error in tutor-chat (using fallback):", error);
    res.json({ 
      text: "Assalamu'alaikum Wr. Wb. Rekan guru calon pendidik profesional PPG Bahasa Arab.\n\n" +
            "Sepertinya saya sedang menelaah kitab-kitab marja' klasik yang sangat padat sehingga jalur komunikasi kita sedikit bertumpuk. Namun jangan khawatir, saya tetap sedia menjabarkan panduan mendasar:\n\n" +
            "1. **Nahwu Utama**: Kuasai kedudukan I'rab dasar dan fungsional (Marfu'at, Manshubat, Majrurat).\n" +
            "2. **Metodologi**: Prioritaskan pendekatan komunikatif aktif (*Thariqah Mubasyarah* atau *al-madkhal al-Ittishali*) agar murid aktif berkalam di kelas.\n\n" +
            "Silakan sampaikan pertanyaan Anda kembali atau coba sesaat lagi, perjuangan mulia PPG ini senantiasa dirahmati Allah Swt! Tetap semangat!"
    });
  }
});

// 6. API Endpoint: AI Quiz Generator
app.post("/api/gemini/quiz-generator", async (req, res) => {
  const { topic } = req.body; // e.g. "Pedagogik", "NahwuSaraf", "Balaghah", "EvaluasiHasilBelajar"
  try {
    let targetFocus = "Campuran Kompetensi Pedagogik dan Profesional PPG Bahasa Arab.";
    if (topic === "Pedagogik") {
      targetFocus = "Kompetensi Pedagogik: Perencanaan pembelajaran, teori belajar, pendekatan komunikatif, asesmen otentik, PTK (Penelitian Tindakan Kelas) Bahasa Arab, media pembelajaran.";
    } else if (topic === "NahwuSaraf") {
      targetFocus = "Kompetensi Profesional Nahwu & Saraf: I'rab, wazan-wazan tasrif fi'il, Huruf Jaar, Idhafah, Na'at Man'ut, khabar muakhkhar, dll.";
    } else if (topic === "Balaghah") {
      targetFocus = "Kompetensi Profesional Balaghah & Sastra: Ilmu Ma'ani, Ilmu Bayan (Tasybih, Majas, Isti'arah), Ilmu Badi', karakteristik uslub bahasa Arab.";
    } else if (topic === "Evaluasi") {
      targetFocus = "Asesmen dan Evaluasi Pembelajaran Bahasa Arab: Penyusunan kisi-kisi soal HOTS, analisis butir soal bahasa Arab tingkat kesukaran, penilaian maharah empat (istima, kalam, qiraah, kitabah).";
    }

    const prompt = `Anda adalah tim ahli panitia nasional Uji Kompetensi Mahasiswa PPG (UKMPPG) Bahasa Arab.
Buatkan 5 soal pilihan ganda latihan berkualitas tinggi (standar ujian nasional/HOTS) yang menguji pemahaman kandidat guru terkait topik: "${targetFocus}".

Ketentuan Soal:
1. Soal harus menantang, membutuhkan analisis kasus atau penalaran linguistik/pedagogis yang baik.
2. Setiap soal wajib menyertakan:
   - Pertanyaan yang objektif dan jelas (bisa disisipkan studi kasus kecil).
   - Teks Bahasa Arab yang relevan wajib menggunakan harakat lengkap.
   - Pilihan jawaban A, B, C, D, E.
   - Kunci jawaban yang tepat.
   - Penjelasan mendalam (pembahasan) ilmiah mengapa kunci tersebut benar dan opsi lainnya kurang tepat.

Silakan hasilkan file JSON dengan skema terstruktur berikut:
{
  "topic": "${topic}",
  "quizTitle": "Latihan Soal UKMPPG Bahasa Arab - ${topic}",
  "questions": [
    {
      "id": 1,
      "questionText": "Teks pertanyaan dalam bahasa Indonesia atau campuran bahasa Arab",
      "options": [
        {"key": "A", "text": "Pernyataan Opsi A"},
        {"key": "B", "text": "Pernyataan Opsi B"},
        {"key": "C", "text": "Pernyataan Opsi C"},
        {"key": "D", "text": "Pernyataan Opsi D"},
        {"key": "E", "text": "Pernyataan Opsi E"}
      ],
      "correctKey": "Huruf kunci (A, B, C, D, atau E)",
      "discussion": "Pembahasan akademis ilmiah lengkap mengenai soal nomor ini dengan bahasa yang gamblang."
    }
  ]
}`;

    const response = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["topic", "quizTitle", "questions"],
          properties: {
            topic: { type: Type.STRING },
            quizTitle: { type: Type.STRING },
            questions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                required: ["id", "questionText", "options", "correctKey", "discussion"],
                properties: {
                  id: { type: Type.INTEGER },
                  questionText: { type: Type.STRING },
                  options: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      required: ["key", "text"],
                      properties: {
                        key: { type: Type.STRING },
                        text: { type: Type.STRING }
                      }
                    }
                  },
                  correctKey: { type: Type.STRING },
                  discussion: { type: Type.STRING }
                }
              }
            }
          }
        },
        temperature: 0.82
      }
    });

    const data = JSON.parse(response.text.trim());
    res.json(data);
  } catch (error: any) {
    console.error("Error in quiz-generator (using fallback):", error);
    res.json(DEFAULT_QUIZ_DATA(topic));
  }
});

// Vite middleware for development or Static Assets for production
async function bootstrap() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // Start Server
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

bootstrap().catch((err) => {
  console.error("Failed to bootstrap server:", err);
});
