# Media PPG Bahasa Arab AI (Sistem Simulasi & Asisten Cerdas Guru)

Aplikasi Media Pembelajaran & Simulasi Kompetensi Uji Mahasiswa Pendidikan Profesi Guru (PPG) Bahasa Arab berbasis AI Generatif (Google Gemini).

---

## 🚀 Panduan Cepat Menjalankan di Komputer Lokal (Localhost)

Aplikasi ini dapat dijalankan langsung di komputer Anda (Windows / Mac / Linux) menggunakan Node.js:

### 1. Prasyarat
- Pastikan telah terinstall **Node.js** (Versi 18, 20, atau 22 ke atas).

### 2. Instalasi Dependensi
Buka Terminal / Command Prompt di folder project, lalu jalankan:
```bash
npm install
```

### 3. Konfigurasi API Key Gemini
Buat file `.env` di direktori utama (root folder), lalu isi dengan:
```env
GEMINI_API_KEY=AQ.Ab8RN6LaOuGBqis4Q9FD67cqCKRN2JlcEwY03aTz01y-f2AtxA
PORT=3000
NODE_ENV=development
```

### 4. Menjalankan Aplikasi
- **Mode Pengembangan (Development):**
  ```bash
  npm run dev
  ```
  Buka browser di: `http://localhost:3000`

- **Mode Produksi (Production Build & Start):**
  ```bash
  npm run build
  npm start
  ```

---

## 🌐 Panduan Deploy ke Hosting DirectAdmin (`m-ahsanuddin.net:2222`)

Terdapat 2 metode termudah untuk mengonlinekan aplikasi ini di subdomain hosting Anda:

### METODE 1: Menggunakan Fitur "Setup Node.js App" di DirectAdmin (Direkomendasikan)

1. **Buat Subdomain di DirectAdmin**:
   - Login ke `https://m-ahsanuddin.net:2222/`
   - Masuk ke menu **Subdomain Management** -> Buat subdomain baru (misalnya: `ppg-arab.m-ahsanuddin.net`).

2. **Buka Menu Setup Node.js App**:
   - Di dashboard DirectAdmin, cari dan buka **Setup Node.js App** (atau *NodeJS Selector*).
   - Klik **Create Application**.
   - **Node.js Version**: Pilih versi terbaru (Node.js 18.x, 20.x, atau 22.x).
   - **Application Mode**: Pilih `Production`.
   - **Application Root**: Arahkan ke folder subdomain Anda (misal: `domains/m-ahsanuddin.net/public_html/ppg-arab` atau folder aplikasi).
   - **Application URL**: Pilih subdomain `ppg-arab.m-ahsanuddin.net`.
   - **Application Startup File**: Ketik `dist/server.cjs` (atau `app.js`).
   - **Environment Variables**:
     - Tambahkan variabel:
       - Name: `GEMINI_API_KEY`
       - Value: `AQ.Ab8RN6LaOuGBqis4Q9FD67cqCKRN2JlcEwY03aTz01y-f2AtxA`
       - Name: `NODE_ENV`
       - Value: `production`
   - Klik **CREATE**.

3. **Upload File & Build**:
   - Upload file project ke folder root aplikasi melalui File Manager atau FTP / Git.
   - Di halaman Node.js App di DirectAdmin, klik **Run NPM Install**, lalu jalankan script build atau jalankan di Terminal SSH:
     ```bash
     npm run build
     ```
   - Klik **Restart Application**.
   - Buka subdomain Anda di browser!

---

### METODE 2: Build di Komputer Lokal Lalu Upload ke Hosting

1. Di komputer lokal Anda, jalankan perintah build:
   ```bash
   npm install
   npm run build
   ```
2. Anda akan mendapatkan folder `dist/` (berisi file frontend dan `server.cjs`).
3. Upload seluruh file (`dist/`, `package.json`, `package-lock.json`, `.env`) ke hosting.
4. Di DirectAdmin Node.js App, atur startup file ke `dist/server.cjs` dan restart app.

---

## 🛠️ Fitur Utama Aplikasi

1. **Modul 01 - Simulasi Kasus Pedagogik**: Studi kasus kelas Bahasa Arab interaktif berbasis HOTS.
2. **Modul 02 - Generator RPP & Modul Ajar**: Pembuatan RPP Kurikulum Merdeka otomatis dengan struktur lengkap dan teks berharakat.
3. **Modul 03 - Al-Ustadz AI Chat Tutor**: Asisten cerdas Nahwu, Saraf, Balaghah, dan metodologi kependidikan.
4. **Modul 04 - Pre-Test & Latihan Soal HOTS**: Bank soal komprehensif persiapan UKMPPG dengan timer & pembahasan ilmiah.
5. **Modul 05 - Dashboard & Sertifikat Digital**: Pelacakan kompetensi pedagogik & profesional serta gamifikasi sertifikat predikat Mumtaz (dapat dicetak & diunduh).
6. **Panel Dosen / Administrator**: Pengelolaan feedback dosen, rekapitulasi nilai, dan verifikasi kelulusan.
